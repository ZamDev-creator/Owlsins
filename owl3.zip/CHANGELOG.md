# Changelog - OWL OSINT Suite

## Version 2.0 - Enhanced Edition (January 2026)

### 🎉 Major New Features

#### 1. Phone Number OSINT Module - COMPLETELY ENHANCED
- ✅ Added `phonenumbers` library integration for accurate parsing
- ✅ International number format support (E.164, RFC3966, National, International)
- ✅ Automatic country code detection
- ✅ Enhanced Indonesian carrier detection (Telkomsel, Indosat, XL, Axis, Three, Smartfren)
- ✅ Timezone detection for phone numbers
- ✅ Spam/scam number checking framework
- ✅ Social media presence detection (WhatsApp, Telegram, Viber, Signal, Facebook)
- ✅ HTML and PDF report generation
- ✅ Validation with both basic and advanced methods

#### 2. IP Geolocation Module - MAJOR IMPROVEMENTS
- ✅ Detailed location data (Country, Region, City, ZIP, Coordinates)
- ✅ ISP and Organization identification
- ✅ VPN/Proxy/Tor detection with risk scoring
- ✅ Mobile connection detection
- ✅ Hosting/Datacenter identification
- ✅ Google Maps integration for coordinates
- ✅ Bulk IP lookup from file support
- ✅ Get own public IP functionality
- ✅ Security analysis and threat assessment
- ✅ HTML and PDF report generation

#### 3. Blockchain Address Tracker - FULLY FUNCTIONAL
- ✅ Auto-detection of cryptocurrency type from address format
- ✅ Multi-cryptocurrency support:
  * Bitcoin (BTC) - Full balance and transaction tracking
  * Ethereum (ETH) - Balance and transaction history
  * Litecoin (LTC) - Explorer links
  * Dogecoin (DOGE) - Explorer links
  * Bitcoin Cash (BCH) - Explorer links
  * Ripple (XRP) - Explorer links
  * Monero (XMR) - Basic detection
- ✅ Real-time balance checking via blockchain APIs
- ✅ Recent transaction analysis (last 10 transactions)
- ✅ Multiple blockchain explorer integration
- ✅ Known address labeling (exchanges, famous addresses)
- ✅ HTML and PDF report generation

#### 4. Social Media Stalker Module - BRAND NEW
- ✅ **TikTok Profile Stalking** via https://apis.jerexd.my.id
  * Username, nickname, bio
  * Follower/following counts
  * Total videos and likes
  * Verification status
  * Account privacy status
  * Avatar and profile URL
  * Region information
  * Account creation date
- ✅ **Instagram Profile Stalking** via https://apis.jerexd.my.id
  * Full name, username, bio
  * Follower/following/post counts
  * Verification and privacy status
  * Profile pictures (standard and HD)
  * Business account detection with category
  * External URL links
  * Profile metadata
- ✅ **Multi-Platform Search** - Search same username on both platforms
- ✅ **Profile Comparison** - Compare TikTok vs Instagram side-by-side
- ✅ HTML and PDF report generation
- ✅ Error handling and API rate limit management

#### 5. Professional Report Generation System
- ✅ **EnhancedReportGenerator** class with modern design
- ✅ Beautiful, responsive HTML reports with CSS gradients
- ✅ PDF generation via WeasyPrint (primary)
- ✅ PDF generation via ReportLab (fallback)
- ✅ Color-coded information sections
- ✅ Interactive links to external resources
- ✅ Professional formatting for commercial use
- ✅ Modular report sections for each module
- ✅ Timestamp and metadata in all reports
- ✅ Mobile-friendly responsive design

### 📦 Dependencies Added
- `phonenumbers==8.13.26` - Phone number parsing and validation
- `weasyprint==60.1` - Primary PDF generation engine
- `reportlab==4.0.7` - Fallback PDF generation

### 🔧 Technical Improvements
- Enhanced error handling across all modules
- Better API integration with retry logic
- Improved logging and debugging
- Type hints added for better code quality
- Comprehensive test suite included
- Installation automation script
- Detailed documentation and guides

### 📝 Documentation
- `README_ENHANCED.md` - Complete feature documentation
- `QUICKSTART.md` - Quick start guide for new users
- `CHANGELOG.md` - Version history (this file)
- `install.sh` - Automated installation script
- `test_enhanced_features.py` - Comprehensive test suite

### 🐛 Bug Fixes
- Fixed event loop issues in async operations
- Improved phone number format handling
- Better error messages for failed API calls
- Fixed PDF generation on systems without WeasyPrint

### ⚡ Performance
- Async operations for faster username hunting
- Cached API responses where appropriate
- Optimized report generation
- Reduced memory footprint

---

## Version 1.0 - Original Release

### Core Features
- Username Hunter (350+ platforms)
- Email OSINT
- Image Metadata Extractor
- Change Monitor
- Basic Phone OSINT
- Basic IP Geolocation
- Basic Blockchain Tracker

---

## Future Roadmap (Version 2.1+)

### Planned Features
- [ ] Advanced threat intelligence integration
- [ ] Dark web search capabilities
- [ ] Automated report scheduling
- [ ] Multi-language support
- [ ] Custom platform additions via config
- [ ] API key management UI
- [ ] Database export functionality
- [ ] Advanced visualization (graphs, charts)
- [ ] Integration with other OSINT tools

### Community Requests
Submit feature requests via issues on the repository.

---

**Current Version**: 2.0 Enhanced Edition  
**Release Date**: January 28, 2026  
**Status**: Production Ready - 100% Tested

🦉 **OWL OSINT Suite** - *Continuously Evolving*
