#!/usr/bin/env python3
"""
Test suite for heuristic detection system
Tests platform detection patterns and accuracy
"""

from utils.heuristics import PlatformHeuristics, ContentAnalyzer

def test_github_detection():
    """Test GitHub profile detection"""
    heuristics = PlatformHeuristics()
    
    # Test positive case - valid profile HTML
    html_valid = '''
    <html>
        <meta property="og:type" content="profile">
        <div class="user-profile-nav">
            <span class="p-nickname">testuser</span>
        </div>
        <span>followers</span>
        <span>repositories</span>
    </html>
    '''
    
    result = heuristics.detect_profile('github', html_valid, 200)
    assert result.exists == True, "Should detect valid GitHub profile"
    assert result.confidence > 0.7, "Should have high confidence"
    print(f"✓ GitHub valid profile: confidence={result.confidence:.2f}, method={result.method}")
    
    # Test negative case - 404 page
    html_404 = '''
    <html>
        <h1>404 Not Found</h1>
        <p>This is not the web page you are looking for</p>
    </html>
    '''
    
    result = heuristics.detect_profile('github', html_404, 404)
    assert result.exists == False, "Should not detect 404 as valid profile"
    print(f"✓ GitHub 404 page: exists={result.exists}, method={result.method}")


def test_instagram_detection():
    """Test Instagram profile detection"""
    heuristics = PlatformHeuristics()
    
    # Test positive case
    html_valid = '''
    <html>
        <script>
            {"username":"testuser","full_name":"Test User","edge_followed_by":{"count":1000}}
        </script>
        <meta property="og:image" content="profile_pic_url">
    </html>
    '''
    
    result = heuristics.detect_profile('instagram', html_valid, 200)
    assert result.exists == True, "Should detect valid Instagram profile"
    print(f"✓ Instagram valid profile: confidence={result.confidence:.2f}")
    
    # Test negative case
    html_404 = '''
    <html>
        <p>Sorry, this page isn't available.</p>
        <p>The link you followed may be broken</p>
    </html>
    '''
    
    result = heuristics.detect_profile('instagram', html_404, 404)
    assert result.exists == False, "Should not detect 404"
    print(f"✓ Instagram 404 page: exists={result.exists}")


def test_content_analyzer():
    """Test content analysis functions"""
    analyzer = ContentAnalyzer()
    
    # Test email extraction
    text = "Contact me at test@example.com or admin@site.org for more info"
    emails = analyzer.extract_emails(text)
    assert len(emails) >= 2, "Should find at least 2 emails"
    assert "test@example.com" in emails, "Should find test@example.com"
    print(f"✓ Email extraction: found {len(emails)} emails")
    
    # Test URL extraction
    text = "Visit my site at https://example.com and check out https://github.com/user"
    urls = analyzer.extract_urls(text)
    assert len(urls) >= 2, "Should find at least 2 URLs"
    print(f"✓ URL extraction: found {len(urls)} URLs")
    
    # Test username extraction
    text = "Follow me @testuser on Twitter and @another_user on Instagram"
    usernames = analyzer.extract_usernames(text)
    assert len(usernames) >= 2, "Should find at least 2 usernames"
    print(f"✓ Username extraction: found {len(usernames)} usernames: {usernames}")


def test_profile_completeness():
    """Test profile completeness calculation"""
    heuristics = PlatformHeuristics()
    
    activity_signals = {
        'has_avatar': True,
        'has_bio': True,
        'has_posts': True,
        'has_followers': True,
        'is_verified': True,
    }
    
    completeness, missing = heuristics.calculate_profile_completeness(activity_signals)
    assert completeness == 1.0, "Complete profile should score 1.0"
    assert len(missing) == 0, "Should have no missing elements"
    print(f"✓ Complete profile: {completeness:.0%}")
    
    # Test incomplete profile
    activity_signals_incomplete = {
        'has_avatar': True,
        'has_bio': False,
        'has_posts': True,
        'has_followers': False,
        'is_verified': False,
    }
    
    completeness, missing = heuristics.calculate_profile_completeness(activity_signals_incomplete)
    assert completeness < 1.0, "Incomplete profile should score < 1.0"
    assert len(missing) > 0, "Should have missing elements"
    print(f"✓ Incomplete profile: {completeness:.0%}, missing: {missing}")


def run_all_tests():
    """Run all tests"""
    print("="*60)
    print("RUNNING HEURISTICS TEST SUITE")
    print("="*60 + "\n")
    
    tests = [
        ("GitHub Detection", test_github_detection),
        ("Instagram Detection", test_instagram_detection),
        ("Content Analyzer", test_content_analyzer),
        ("Profile Completeness", test_profile_completeness),
    ]
    
    passed = 0
    failed = 0
    
    for name, test_func in tests:
        print(f"\nTest: {name}")
        print("-" * 40)
        try:
            test_func()
            passed += 1
            print(f"✅ {name} PASSED\n")
        except AssertionError as e:
            failed += 1
            print(f"❌ {name} FAILED: {e}\n")
        except Exception as e:
            failed += 1
            print(f"❌ {name} ERROR: {e}\n")
    
    print("="*60)
    print(f"RESULTS: {passed} passed, {failed} failed")
    print("="*60)
    
    return failed == 0


if __name__ == "__main__":
    success = run_all_tests()
    exit(0 if success else 1)

