#!/usr/bin/env python3
"""
Username Hunter Module - ULTRA THOROUGH VERSION
BENAR-BENAR mencari satu per satu dengan verifikasi mendalam
Tidak ada fallback asal-asalan!
"""

import asyncio
import aiohttp
import json
import time
from typing import Dict, List, Optional
from pathlib import Path
from tqdm import tqdm

from config import REQUEST_TIMEOUT, USER_AGENT, DATA_DIR
from utils.logger import setup_logger
from utils.database import Database
from utils.heuristics import PlatformHeuristics, ContentAnalyzer
from core.entity import Entity, Evidence, EvidenceType
from core.confidence_scoring import ConfidenceScorer

logger = setup_logger(__name__)


class UsernameHunter:
    """ULTRA THOROUGH username hunter - REAL verification"""
    
    def __init__(self, entity_manager=None, scorer=None):
        """Initialize with optional entity manager"""
        self.platforms = self._load_platforms()
        self.db = Database()
        self.heuristics = PlatformHeuristics()
        self.analyzer = ContentAnalyzer()
        self.entity_manager = entity_manager
        self.scorer = scorer or ConfidenceScorer()
        
        # Import social stalker for deep verification
        try:
            from modules.social_stalker import SocialMediaStalker
            self.stalker = SocialMediaStalker()
            self.has_stalker = True
            logger.info("✅ Social stalker loaded - deep verification enabled")
        except Exception as e:
            logger.warning(f"⚠️ Social stalker not available: {e}")
            self.has_stalker = False
        
        # Priority platforms for deep check
        self.priority_platforms = ['tiktok', 'instagram', 'github', 'twitter', 'linkedin', 'youtube']
        
    def _load_platforms(self):
        """Load platform configurations"""
        platforms_file = DATA_DIR / "platforms.json"
        
        if platforms_file.exists():
            with open(platforms_file) as f:
                data = json.load(f)
                
                if isinstance(data, list):
                    platforms = {}
                    for item in data:
                        key = item['name'].lower().replace('/', '_').replace(' ', '_')
                        platforms[key] = {
                            'url': item['url'],
                            'name': item['name']
                        }
                    return platforms
                elif isinstance(data, dict):
                    return data
        
        # Fallback
        return {
            'github': {'url': 'https://github.com/{}', 'name': 'GitHub'},
            'instagram': {'url': 'https://www.instagram.com/{}/', 'name': 'Instagram'},
            'twitter': {'url': 'https://twitter.com/{}', 'name': 'Twitter'},
            'tiktok': {'url': 'https://www.tiktok.com/@{}', 'name': 'TikTok'},
            'linkedin': {'url': 'https://www.linkedin.com/in/{}', 'name': 'LinkedIn'},
            'youtube': {'url': 'https://www.youtube.com/@{}', 'name': 'YouTube'},
            'reddit': {'url': 'https://www.reddit.com/user/{}', 'name': 'Reddit'},
        }
    
    async def check_username_thorough(self, session: aiohttp.ClientSession, 
                                     username: str, platform: str, 
                                     config: Dict) -> Dict:
        """
        THOROUGH CHECK - tidak asal lewat!
        Benar-benar analisis halaman
        """
        url = config['url'].format(username)
        platform_name = config['name']
        platform_key = platform.lower()
        
        logger.info(f"🔍 Checking {platform_name}: {url}")
        
        try:
            # SSL handling
            ssl_verify = True
            if any(domain in url for domain in ['blogspot.com', 'wordpress.com', 'tumblr.com']):
                ssl_verify = False
            
            # Multiple attempts for important platforms
            max_attempts = 3 if platform_key in self.priority_platforms else 1
            html = None
            status_code = 0
            
            for attempt in range(max_attempts):
                try:
                    async with session.get(url, timeout=REQUEST_TIMEOUT, ssl=ssl_verify) as response:
                        status_code = response.status
                        html = await response.text()
                        
                        if status_code == 200 and html and len(html) > 100:
                            break  # Got good response
                        
                        if attempt < max_attempts - 1:
                            await asyncio.sleep(1)  # Wait before retry
                            
                except Exception as e:
                    logger.warning(f"Attempt {attempt+1} failed for {platform_name}: {e}")
                    if attempt == max_attempts - 1:
                        raise
            
            # DEEP ANALYSIS - tidak cuma heuristic
            detection = self.heuristics.detect_profile(platform_key, html, status_code)
            
            # MANUAL VERIFICATION for priority platforms
            manual_verification = None
            if platform_key in self.priority_platforms and detection.exists:
                manual_verification = await self._manual_verify_platform(
                    platform_key, username, html, status_code
                )
            
            # Extract profile data dengan detail
            profile_data = self._extract_profile_data_deep(html, platform_name, platform_key)
            
            # Calculate REAL confidence
            real_confidence = self._calculate_ultra_confidence(
                detection, profile_data, manual_verification, 
                html, status_code, platform_key
            )
            
            # Determine if really exists
            # FIXED: High confidence means exists, regardless of detection flag
            really_exists = detection.exists
            
            # Override if manual verification says otherwise
            if manual_verification:
                really_exists = manual_verification['exists']
                if manual_verification['confidence'] > real_confidence:
                    real_confidence = manual_verification['confidence']
            
            # CRITICAL FIX: If confidence is high enough, profile EXISTS
            # Don't rely solely on detection.exists which can be wrong
            if real_confidence >= 0.45:
                really_exists = True
                logger.info(f"  💡 Confidence {real_confidence:.0%} >= 45%, marking as EXISTS")
            
            # For TikTok/Instagram specifically, even lower threshold
            if platform_key in ['tiktok', 'instagram'] and real_confidence >= 0.40:
                really_exists = True
                logger.info(f"  💡 {platform_name} confidence {real_confidence:.0%} >= 40%, marking as EXISTS")
            
            result = {
                'platform': platform_name,
                'url': url,
                'exists': really_exists,
                'confidence': real_confidence,
                'method': detection.method,
                'signals': detection.signals,
                'completeness': detection.completeness,
                'profile_data': profile_data,
                'manual_verification': manual_verification,
                'activity_signals': {
                    'has_avatar': profile_data.get('has_avatar', False),
                    'has_bio': profile_data.get('has_bio', False),
                    'is_verified': profile_data.get('is_verified', False),
                    'follower_count': profile_data.get('followers', 0),
                    'post_count': profile_data.get('posts', 0),
                }
            }
            
            # Extract additional info
            if really_exists and html:
                result['extracted_emails'] = self.analyzer.extract_emails(html[:10000])[:5]
                result['extracted_usernames'] = self.analyzer.extract_usernames(html[:10000])[:10]
            
            logger.info(f"✅ {platform_name}: exists={really_exists}, confidence={real_confidence:.0%}")
            
            return result
            
        except asyncio.TimeoutError:
            logger.warning(f"⏱️ Timeout checking {platform_name}")
            return {
                'platform': platform_name,
                'url': url,
                'exists': False,
                'confidence': 0.0,
                'method': 'timeout',
                'error': 'Timeout',
            }
        except Exception as e:
            logger.error(f"❌ Error checking {platform_name}: {e}")
            return {
                'platform': platform_name,
                'url': url,
                'exists': False,
                'confidence': 0.0,
                'method': 'error',
                'error': str(e),
            }
    
    async def _manual_verify_platform(self, platform: str, username: str, 
                                     html: str, status_code: int) -> Dict:
        """
        MANUAL VERIFICATION - cek betulan ada atau tidak
        Untuk platform prioritas
        """
        verification = {
            'exists': False,
            'confidence': 0.0,
            'method': 'manual_check',
            'details': []
        }
        
        if not html or status_code != 200:
            verification['details'].append('No valid response')
            return verification
        
        html_lower = html.lower()
        
        # Platform-specific deep checks
        if platform == 'tiktok':
            # TikTok specific indicators
            indicators = [
                '"uniqueid"' in html_lower,
                '"nickname"' in html_lower,
                'followercount' in html_lower,
                'videocount' in html_lower,
                '__universal_data_for_rehydration__' in html_lower,
            ]
            
            count = sum(indicators)
            if count >= 2:  # FIXED: 2/5 is enough (was 3/5)
                verification['exists'] = True
                verification['confidence'] = 0.75 + (count * 0.05)  # 75-95%
                verification['details'].append(f'Found {count}/5 TikTok indicators')
            elif count >= 1:
                verification['exists'] = True  # Even 1 indicator is something
                verification['confidence'] = 0.50
                verification['details'].append(f'Found {count}/5 TikTok indicators (weak)')
        
        elif platform == 'instagram':
            indicators = [
                '"username"' in html_lower and username.lower() in html_lower,
                'edge_followed_by' in html_lower,
                'profile_pic_url' in html_lower,
                'biography' in html_lower,
                'is_private' in html_lower or 'is_verified' in html_lower,
            ]
            
            count = sum(indicators)
            if count >= 2:  # FIXED: 2/5 is enough
                verification['exists'] = True
                verification['confidence'] = 0.80 + (count * 0.04)  # 80-96%
                verification['details'].append(f'Found {count}/5 Instagram indicators')
            elif count >= 1:
                verification['exists'] = True
                verification['confidence'] = 0.55
                verification['details'].append(f'Found {count}/5 Instagram indicators (weak)')
        
        elif platform == 'github':
            indicators = [
                'data-hovercard-type="user"' in html,
                'user-profile' in html_lower,
                'followers' in html_lower,
                'repositories' in html_lower,
                'contribution' in html_lower,
            ]
            
            if sum(indicators) >= 3:
                verification['exists'] = True
                verification['confidence'] = 0.95
                verification['details'].append(f'Found {sum(indicators)}/5 GitHub indicators')
        
        elif platform == 'twitter':
            indicators = [
                'profile' in html_lower,
                'tweet' in html_lower,
                'follower' in html_lower,
                'following' in html_lower,
                username.lower() in html_lower,
            ]
            
            # Twitter is tricky due to login walls
            if sum(indicators) >= 2:
                verification['exists'] = True
                verification['confidence'] = 0.70
                verification['details'].append(f'Found {sum(indicators)}/5 Twitter indicators (limited)')
        
        elif platform == 'linkedin':
            indicators = [
                'profile-view' in html_lower,
                'pv-top-card' in html_lower,
                'experience' in html_lower,
                'connection' in html_lower,
            ]
            
            if sum(indicators) >= 2:
                verification['exists'] = True
                verification['confidence'] = 0.75
                verification['details'].append(f'Found {sum(indicators)}/4 LinkedIn indicators')
        
        elif platform == 'youtube':
            indicators = [
                'channelid' in html_lower,
                'subscriber' in html_lower,
                'ytinitialdata' in html_lower,
                'video' in html_lower,
            ]
            
            if sum(indicators) >= 3:
                verification['exists'] = True
                verification['confidence'] = 0.88
                verification['details'].append(f'Found {sum(indicators)}/4 YouTube indicators')
        
        return verification
    
    def _calculate_ultra_confidence(self, detection, profile_data, manual_verification,
                                    html, status_code, platform):
        """
        ULTRA CONFIDENCE CALCULATION
        Tidak ada lagi confidence asal-asalan
        """
        confidence = 0.0
        
        # Start from detection base
        if detection.method == 'heuristic_positive':
            confidence = 0.70
        elif detection.method == 'heuristic_weak':
            confidence = 0.50
        elif detection.method == 'status_code':
            confidence = 0.30
        elif detection.method == 'fallback':
            confidence = 0.15  # Very low for fallback
        
        # Manual verification overrides
        if manual_verification and manual_verification['exists']:
            confidence = max(confidence, manual_verification['confidence'])
        
        # Profile data boosts
        if profile_data.get('has_avatar'):
            confidence += 0.12
        if profile_data.get('has_bio'):
            confidence += 0.10
        if profile_data.get('is_verified'):
            confidence += 0.18
        
        followers = profile_data.get('followers', 0)
        if followers > 10000:
            confidence += 0.15
        elif followers > 1000:
            confidence += 0.12
        elif followers > 100:
            confidence += 0.08
        elif followers > 0:
            confidence += 0.05
        
        posts = profile_data.get('posts', 0)
        if posts > 100:
            confidence += 0.10
        elif posts > 10:
            confidence += 0.06
        elif posts > 0:
            confidence += 0.03
        
        # HTML depth matters
        if html:
            if len(html) > 50000:
                confidence += 0.08  # Very rich content
            elif len(html) > 20000:
                confidence += 0.05
            elif len(html) > 5000:
                confidence += 0.02
        
        # Cap at 98%
        return min(confidence, 0.98)
    
    def _extract_profile_data_deep(self, html: str, platform_name: str, platform_key: str) -> Dict:
        """DEEP profile data extraction - tidak shallow"""
        profile_data = {
            'has_avatar': False,
            'has_bio': False,
            'is_verified': False,
            'followers': 0,
            'following': 0,
            'posts': 0,
            'name': None,
            'bio_text': None,
        }
        
        if not html:
            return profile_data
        
        html_lower = html.lower()
        
        # Avatar detection - more thorough
        avatar_patterns = [
            'profile_image', 'profile-image', 'profileimage',
            'avatar', 'user-avatar', 'useravatar',
            'profilepic', 'profile-pic', 'profile_pic',
            'user-photo', 'userphoto', 'profile-img',
            'profile_photo', 'profile-photo'
        ]
        profile_data['has_avatar'] = any(p in html_lower for p in avatar_patterns)
        
        # Bio detection - more thorough
        bio_patterns = [
            'biography', '"bio":', 'bio":', '"description":', 'description":',
            'about', 'user-bio', 'profile-bio', '"signature":', 'user-description'
        ]
        profile_data['has_bio'] = any(p in html_lower for p in bio_patterns)
        
        # Verified detection
        verified_patterns = [
            'is_verified":true', '"verified":true', 'verified badge',
            'official', 'checkmark', 'badge-verified'
        ]
        profile_data['is_verified'] = any(p in html_lower for p in verified_patterns)
        
        # Extract numbers - improved patterns
        import re
        
        # Followers
        follower_patterns = [
            r'"followercount"\s*:\s*(\d+)',
            r'"followers"\s*:\s*(\d+)',
            r'(\d+(?:,\d+)*(?:\.\d+)?[kmb]?)\s*followers',
            r'followers["\s:]+(\d+(?:,\d+)*)',
        ]
        
        for pattern in follower_patterns:
            match = re.search(pattern, html_lower)
            if match:
                try:
                    num_str = match.group(1).replace(',', '')
                    if 'k' in num_str:
                        profile_data['followers'] = int(float(num_str.replace('k', '')) * 1000)
                    elif 'm' in num_str:
                        profile_data['followers'] = int(float(num_str.replace('m', '')) * 1000000)
                    else:
                        profile_data['followers'] = int(num_str)
                    break
                except:
                    pass
        
        # Posts/Videos
        post_patterns = [
            r'"videocount"\s*:\s*(\d+)',
            r'"postcount"\s*:\s*(\d+)',
            r'(\d+(?:,\d+)*)\s*(?:posts|videos|tweets)',
        ]
        
        for pattern in post_patterns:
            match = re.search(pattern, html_lower)
            if match:
                try:
                    profile_data['posts'] = int(match.group(1).replace(',', ''))
                    break
                except:
                    pass
        
        return profile_data
    
    async def search_username_async(self, username: str, 
                                   platforms_to_check: Optional[List[str]] = None) -> List[Dict]:
        """
        THOROUGH ASYNC SEARCH - satu per satu dengan teliti
        """
        if platforms_to_check:
            platforms = {k: v for k, v in self.platforms.items() if k in platforms_to_check}
        else:
            platforms = self.platforms
        
        if not isinstance(platforms, dict):
            logger.error(f"Platforms is not a dict")
            platforms = self._load_platforms()
        
        headers = {'User-Agent': USER_AGENT}
        connector = aiohttp.TCPConnector(ssl=False)
        
        # Sort platforms - priority first
        priority_items = [(k, v) for k, v in platforms.items() if k in self.priority_platforms]
        other_items = [(k, v) for k, v in platforms.items() if k not in self.priority_platforms]
        sorted_platforms = priority_items + other_items
        
        results = []
        
        async with aiohttp.ClientSession(headers=headers, connector=connector) as session:
            # Check with progress bar
            pbar = tqdm(total=len(sorted_platforms), desc="Checking platforms", unit="platform")
            
            for platform, config in sorted_platforms:
                result = await self.check_username_thorough(session, username, platform, config)
                results.append(result)
                
                # Small delay between requests - be polite
                await asyncio.sleep(0.5)
                pbar.update(1)
            
            pbar.close()
        
        return results
    
    def _deep_stalk_if_found(self, username: str, results: List[Dict]) -> Dict:
        """
        AUTO DEEP-STALK untuk TikTok/Instagram
        STRATEGY BARU: Selalu coba API untuk TikTok/IG, abaikan HTML detection
        Karena kedua platform ini pakai anti-scraping + require login
        """
        if not self.has_stalker:
            logger.warning("  ⚠️ Social stalker not available, skipping deep analysis")
            return {}
        
        deep_results = {}
        
        # Strategy: Check ALL results for TikTok/Instagram
        # Don't rely on HTML detection, go straight to API
        for result in results:
            platform = result['platform'].lower()
            
            # For TikTok: Try API regardless of HTML confidence
            if 'tiktok' in platform:
                logger.info(f"🎯 Trying TikTok API for @{username}")
                print(f"\n  🔎 Checking TikTok via API...")
                try:
                    deep_data = self.stalker.stalk_tiktok(username)
                    if deep_data.get('success') and deep_data.get('data'):
                        # API SUCCESS - profile exists!
                        deep_results['tiktok'] = deep_data
                        result['deep_stalk'] = deep_data
                        result['confidence'] = 0.90  # API verified = 90%
                        result['exists'] = True
                        result['method'] = 'api_verified'
                        logger.info("✅ TikTok API SUCCESS - profile found!")
                        print("  ✅ TikTok profile DITEMUKAN via API!")
                    else:
                        # API failed - profile not found
                        result['exists'] = False
                        result['confidence'] = 0.0
                        logger.info("  ❌ TikTok API: Profile not found")
                        print("  ❌ TikTok profile TIDAK DITEMUKAN")
                except Exception as e:
                    logger.error(f"  ❌ TikTok API error: {e}")
                    result['exists'] = False
            
            # For Instagram: ALWAYS try API regardless of HTML
            elif 'instagram' in platform:
                logger.info(f"🎯 Trying Instagram API for @{username}")
                print(f"\n  🔎 Checking Instagram via API...")
                try:
                    deep_data = self.stalker.stalk_instagram(username)
                    if deep_data.get('success') and deep_data.get('data'):
                        # API SUCCESS - profile exists!
                        deep_results['instagram'] = deep_data
                        result['deep_stalk'] = deep_data
                        result['confidence'] = 0.92  # API verified = 92%
                        result['exists'] = True
                        result['method'] = 'api_verified'
                        logger.info("✅ Instagram API SUCCESS - profile found!")
                        print("  ✅ Instagram profile DITEMUKAN via API!")
                    else:
                        # API failed - profile not found
                        result['exists'] = False
                        result['confidence'] = 0.0
                        logger.info("  ❌ Instagram API: Profile not found")
                        print("  ❌ Instagram profile TIDAK DITEMUKAN")
                except Exception as e:
                    logger.error(f"  ❌ Instagram API error: {e}")
                    result['exists'] = False
        
        return deep_results
    
    def search_username(self, username: str, 
                       platforms_to_check: Optional[List[str]] = None,
                       create_entity: bool = False) -> Dict:
        """
        MAIN SEARCH FUNCTION - ULTRA THOROUGH
        """
        logger.info(f"🔍 Starting THOROUGH search for: {username}")
        print(f"\n⚠️  Mode: THOROUGH VERIFICATION (akan lebih lama tapi akurat)")
        print(f"📋 Akan mengecek {len(self.platforms)} platform satu per satu\n")
        
        # Run async search
        loop = asyncio.get_event_loop()
        results = loop.run_until_complete(
            self.search_username_async(username, platforms_to_check)
        )
        
        # Filter results
        found = [r for r in results if r.get('exists')]
        not_found = [r for r in results if not r.get('exists')]
        
        # AUTO DEEP-STALK
        print(f"\n🎯 Checking for platforms that need deep analysis...")
        deep_stalk_results = self._deep_stalk_if_found(username, found)
        
        # Calculate confidence
        if found:
            weighted_sum = sum(r['confidence'] ** 2 for r in found)
            max_weight = len(found)
            avg_confidence = (weighted_sum / max_weight) ** 0.5 if max_weight > 0 else 0.0
        else:
            avg_confidence = 0.0
        
        summary = {
            'username': username,
            'total_platforms_checked': len(results),
            'found_on': len(found),
            'not_found_on': len(not_found),
            'average_confidence': avg_confidence,
            'results': results,
            'found_results': found,
            'deep_stalk_results': deep_stalk_results,
        }
        
        # Create entity
        if create_entity and self.entity_manager:
            entity = self._create_entity_from_results(username, found, deep_stalk_results)
            summary['entity'] = entity
            
            try:
                entity_id = self.db.save_entity(entity)
                logger.info(f"Saved entity to database with ID: {entity_id}")
            except Exception as e:
                logger.error(f"Failed to save entity: {e}")
        
        # Save to database
        try:
            for result in results:
                self.db.save_username_result(
                    username, 
                    result['platform'],
                    result.get('exists', False),
                    result.get('url', '')
                )
        except Exception as e:
            logger.error(f"Failed to save to database: {e}")
        
        return summary
    
    def _create_entity_from_results(self, username: str, results: List[Dict], 
                                    deep_stalk_results: Dict = None) -> Entity:
        """Create entity with all evidence"""
        entity = self.entity_manager.get_or_create_entity(username, entity_type='person')
        entity.add_identifier('username', username)
        
        platforms_data = {}
        
        for result in results:
            platform = result['platform']
            confidence = result['confidence']
            method = result['method']
            
            weight_map = {
                'api_verified': 0.65,
                'manual_check': 0.55,
                'heuristic_positive': 0.45,
                'heuristic_weak': 0.30,
                'status_code': 0.25,
                'fallback': 0.12,
            }
            weight = weight_map.get(method, 0.15)
            
            profile_data = result.get('profile_data', {})
            activity_signals = result.get('activity_signals', {})
            
            score = self.scorer.score_username_finding(
                found=True,
                has_profile=bool(profile_data),
                has_avatar=activity_signals.get('has_avatar', False),
                has_bio=activity_signals.get('has_bio', False),
                is_verified=activity_signals.get('is_verified', False),
                reliability=confidence,
            )
            
            completeness = result.get('completeness', 0.3)
            platforms_data[platform.lower()] = {
                'url': result['url'],
                'confidence': confidence,
                'method': method,
                'completeness': completeness,
                'profile_data': profile_data,
                'activity_signals': activity_signals,
            }
            
            if deep_stalk_results and platform.lower() in deep_stalk_results:
                platforms_data[platform.lower()]['deep_analysis'] = deep_stalk_results[platform.lower()]
                weight += 0.20
            
            evidence = Evidence(
                source='username_hunter',
                evidence_type=EvidenceType.USERNAME,
                signal=f'profile_found_{platform.lower().replace(" ", "_")}',
                value={
                    'platform': platform,
                    'url': result['url'],
                    'confidence': confidence,
                    'method': method,
                    'completeness': completeness,
                    'profile_data': profile_data,
                },
                weight=weight,
                reliability=confidence,
                metadata={
                    'detection_method': method,
                    'signals': result.get('signals', []),
                    'has_avatar': activity_signals.get('has_avatar', False),
                    'has_bio': activity_signals.get('has_bio', False),
                    'is_verified': activity_signals.get('is_verified', False),
                }
            )
            entity.add_evidence(evidence)
            
            if 'extracted_emails' in result:
                for email in result['extracted_emails']:
                    entity.add_identifier('email', email)
            
            if 'extracted_usernames' in result:
                for uname in result['extracted_usernames']:
                    if uname != username:
                        entity.add_identifier('username', uname)
        
        entity.attributes['platforms'] = platforms_data
        entity._recalculate_confidence()
        
        logger.info(f"Created entity for {username} with {len(entity.evidence)} pieces of evidence")
        
        return entity
    
    def get_history(self, username: str) -> List[Dict]:
        """Get search history for a username"""
        return self.db.get_username_history(username)
