#!/usr/bin/env python3
"""
Social Media Stalking Module - API Version with Intelligence Analysis
Using external API from apis.jerexd.my.id for reliable data extraction
Enhanced with content pattern analysis and timeline reconstruction
"""

import requests
import time
import random
from typing import Dict, Optional, List
from datetime import datetime
from collections import Counter
from utils.logger import setup_logger

logger = setup_logger(__name__)


class SocialMediaStalker:
    """Professional social media scraper with intelligence analysis"""
    
    def __init__(self):
        self.session = requests.Session()
        self.api_base = "https://apis.jerexd.my.id"
        
        self.base_headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'Accept': 'application/json',
        }
        
        self.last_request = 0
        self.min_delay = 1
    
    def _wait(self):
        """Rate limiting with random jitter"""
        elapsed = time.time() - self.last_request
        if elapsed < self.min_delay:
            wait = self.min_delay - elapsed + random.uniform(0.3, 0.8)
            time.sleep(wait)
        self.last_request = time.time()
    
    def stalk_tiktok(self, username: str) -> Dict:
        """
        TikTok profile scraper using jerexd API
        """
        result = {
            'platform': 'tiktok',
            'username': username,
            'success': False
        }
        
        try:
            clean = username.replace('@', '').strip()
            logger.info(f"TikTok scraping via API: @{clean}")
            print(f"  🔍 Fetching TikTok data from API...")
            
            self._wait()
            
            # Call the API
            api_url = f"{self.api_base}/stalk/tiktok"
            params = {'username': clean}
            
            resp = self.session.get(
                api_url, 
                params=params, 
                headers=self.base_headers, 
                timeout=30
            )
            
            if resp.status_code != 200:
                result['error'] = f'API returned HTTP {resp.status_code}'
                logger.error(f"TikTok API error: {resp.status_code}")
                return result
            
            data = resp.json()
            
            # Check if API call was successful
            if not data.get('status'):
                result['error'] = 'API returned unsuccessful status'
                logger.error(f"TikTok API unsuccessful")
                return result
            
            # Extract profile data from API response
            api_result = data.get('result', {})
            
            if not api_result.get('status'):
                result['error'] = 'Profile not found or API returned no data'
                logger.error(f"TikTok profile not found")
                return result
            
            profile_data = api_result.get('profile', {})
            
            if not profile_data:
                result['error'] = 'No profile data in API response'
                return result
            
            # Map API response to our format
            result['success'] = True
            result['profile'] = {
                'username': clean,
                'nickname': clean,  # API doesn't provide nickname separately
                'bio': 'N/A',  # API doesn't provide bio
                'verified': False,  # API doesn't provide verification status
                'private': False,  # API doesn't provide private status
                'followers': profile_data.get('followers', 'N/A'),
                'following': profile_data.get('following', 'N/A'),
                'total_likes': profile_data.get('likes', 'N/A'),
                'total_videos': len(api_result.get('videos', [])) if api_result.get('videos') else 'N/A',
                'avatar': profile_data.get('avatar', ''),
                'profile_url': f'https://www.tiktok.com/@{clean}',
            }
            
            logger.info(f"✅ TikTok API success")
            print(f"  ✅ Successfully fetched from API!")
            return result
        
        except requests.Timeout:
            result['error'] = 'Request timeout - API took too long to respond'
            logger.error(f"Timeout on TikTok API")
        except requests.ConnectionError:
            result['error'] = 'Connection error - unable to reach API'
            logger.error(f"Connection error to TikTok API")
        except requests.exceptions.JSONDecodeError:
            result['error'] = 'Invalid JSON response from API'
            logger.error(f"JSON decode error from TikTok API")
        except Exception as e:
            result['error'] = f'Error: {str(e)}'
            logger.error(f"TikTok API error: {e}", exc_info=True)
        
        return result
    
    def stalk_instagram(self, username: str) -> Dict:
        """
        Instagram profile scraper using jerexd API
        """
        result = {
            'platform': 'instagram',
            'username': username,
            'success': False
        }
        
        try:
            clean = username.replace('@', '').strip()
            logger.info(f"Instagram scraping via API: @{clean}")
            print(f"  🔍 Fetching Instagram data from API...")
            
            self._wait()
            
            # Call the API
            api_url = f"{self.api_base}/stalk/instagram"
            params = {'username': clean}
            
            resp = self.session.get(
                api_url, 
                params=params, 
                headers=self.base_headers, 
                timeout=30
            )
            
            if resp.status_code != 200:
                result['error'] = f'API returned HTTP {resp.status_code}'
                logger.error(f"Instagram API error: {resp.status_code}")
                return result
            
            data = resp.json()
            
            # Check if API call was successful
            if not data.get('status'):
                result['error'] = 'API returned unsuccessful status'
                logger.error(f"Instagram API unsuccessful")
                return result
            
            # Extract profile data from API response
            profile_data = data.get('result', {})
            
            if not profile_data or not profile_data.get('username'):
                result['error'] = 'Profile not found or API returned no data'
                logger.error(f"Instagram profile not found")
                return result
            
            # Map API response to our format
            result['success'] = True
            result['profile'] = {
                'username': profile_data.get('username', clean),
                'full_name': profile_data.get('fullname', 'N/A'),
                'bio': profile_data.get('bio', 'No bio'),
                'verified': False,  # API doesn't provide verification status
                'private': profile_data.get('is_private', False),
                'followers': profile_data.get('followers_count', 'N/A'),
                'following': profile_data.get('following_count', 'N/A'),
                'posts': profile_data.get('posts_count', 'N/A'),
                'profile_pic': profile_data.get('profile_pic', ''),
                'profile_pic_hd': profile_data.get('profile_pic', ''),
                'external_url': '',
                'profile_url': f'https://www.instagram.com/{clean}/',
            }
            
            # Add note about the method used
            method_used = data.get('method_used', 'unknown')
            result['profile']['api_method'] = method_used
            
            logger.info(f"✅ Instagram API success (method: {method_used})")
            print(f"  ✅ Successfully fetched from API!")
            return result
        
        except requests.Timeout:
            result['error'] = 'Request timeout - API took too long to respond'
            logger.error(f"Timeout on Instagram API")
        except requests.ConnectionError:
            result['error'] = 'Connection error - unable to reach API'
            logger.error(f"Connection error to Instagram API")
        except requests.exceptions.JSONDecodeError:
            result['error'] = 'Invalid JSON response from API'
            logger.error(f"JSON decode error from Instagram API")
        except Exception as e:
            result['error'] = f'Error: {str(e)}'
            logger.error(f"Instagram API error: {e}", exc_info=True)
        
        return result
    
    def stalk_multi_platform(self, username: str) -> Dict:
        """Search both platforms"""
        result = {'username': username, 'platforms': {}}
        
        print(f"  🔍 Checking TikTok...")
        result['platforms']['tiktok'] = self.stalk_tiktok(username)
        
        print(f"  🔍 Checking Instagram...")
        result['platforms']['instagram'] = self.stalk_instagram(username)
        
        result['found_on'] = sum(1 for p in result['platforms'].values() if p.get('success'))
        result['total_checked'] = 2
        
        return result
    
    def compare_profiles(self, tt_user: str, ig_user: str) -> Dict:
        """Compare profiles"""
        result = {
            'comparison': {},
            'tiktok': self.stalk_tiktok(tt_user),
            'instagram': self.stalk_instagram(ig_user)
        }
        
        if result['tiktok'].get('success') and result['instagram'].get('success'):
            tt = result['tiktok']['profile']
            ig = result['instagram']['profile']
            
            def to_int(v):
                if not v or v == 'N/A':
                    return 0
                v = str(v).replace(',', '')
                try:
                    if 'K' in v:
                        return int(float(v.replace('K', '')) * 1000)
                    if 'M' in v:
                        return int(float(v.replace('M', '')) * 1000000)
                    if 'B' in v:
                        return int(float(v.replace('B', '')) * 1000000000)
                    return int(float(v))
                except:
                    return 0
            
            result['comparison'] = {
                'total_followers': {
                    'tiktok': to_int(tt.get('followers')),
                    'instagram': to_int(ig.get('followers')),
                    'difference': abs(to_int(tt.get('followers')) - to_int(ig.get('followers')))
                },
                'total_posts': {
                    'tiktok': to_int(tt.get('total_videos')),
                    'instagram': to_int(ig.get('posts')),
                    'difference': abs(to_int(tt.get('total_videos')) - to_int(ig.get('posts')))
                },
                'verified': {
                    'tiktok': tt.get('verified', False),
                    'instagram': ig.get('verified', False),
                    'both_verified': tt.get('verified') and ig.get('verified')
                }
            }
        
        return result
    
    def get_profile_summary(self, data: Dict) -> str:
        """Format for display"""
        if not data.get('success'):
            return f"❌ Error: {data.get('error', 'Unknown error')}"
        
        p = data['profile']
        platform = data['platform'].upper()
        
        def fmt(v):
            if not v or v == 'N/A':
                return 'N/A'
            try:
                if isinstance(v, str) and any(x in v for x in ['K', 'M', 'B']):
                    return v
                num = int(v)
                if num >= 1000000000:
                    return f"{num/1000000000:.1f}B"
                elif num >= 1000000:
                    return f"{num/1000000:.1f}M"
                elif num >= 1000:
                    return f"{num/1000:.1f}K"
                return f"{num:,}"
            except:
                return str(v)
        
        summary = f"""
✅ {platform} Profile Found
━━━━━━━━━━━━━━━━━━━━━━━━
👤 Username: @{p['username']}
📝 Name: {p.get('nickname') or p.get('full_name', 'N/A')}
📄 Bio: {p.get('bio', 'No bio')[:100]}
✓ Verified: {'Yes ✓' if p.get('verified') else 'No'}
🔒 Private: {'Yes 🔒' if p.get('private') else 'No'}

📊 Statistics:
  👥 Followers: {fmt(p.get('followers'))} 
  👤 Following: {fmt(p.get('following'))}
  📸 Posts/Videos: {fmt(p.get('total_videos') or p.get('posts'))}"""
        
        if p.get('total_likes') and p.get('total_likes') != 'N/A':
            summary += f"\n  ❤️ Total Likes: {fmt(p['total_likes'])}"
        
        summary += f"\n\n🔗 Profile: {p['profile_url']}"
        
        # Add API method info for Instagram
        if platform == 'INSTAGRAM' and p.get('api_method'):
            summary += f"\n\n💡 Data source: {p['api_method']}"
        
        if p.get('note'):
            summary += f"\n\n{p['note']}"
        
        summary += f"\n\n🌐 Powered by: apis.jerexd.my.id"
        
        return summary + "\n"
    
    def analyze_posting_frequency(self, profile_data: Dict) -> Dict:
        """Analyze posting frequency and activity patterns"""
        analysis = {
            'frequency_score': 0.0,
            'activity_level': 'unknown',
            'insights': []
        }
        
        try:
            # Try multiple keys for post count
            total_posts = (
                profile_data.get('total_videos') or 
                profile_data.get('posts') or 
                profile_data.get('video_count') or
                0
            )
            
            # Handle string format numbers
            if isinstance(total_posts, str):
                total_posts = total_posts.strip()
                if total_posts == 'N/A' or not total_posts:
                    total_posts = 0
                elif 'K' in total_posts:
                    total_posts = float(total_posts.replace('K', '')) * 1000
                elif 'M' in total_posts:
                    total_posts = float(total_posts.replace('M', '')) * 1000000
                else:
                    try:
                        total_posts = int(total_posts)
                    except:
                        total_posts = 0
            
            # Analyze based on followers if no post count
            if total_posts == 0 or total_posts == 'N/A':
                followers = profile_data.get('followers', 0)
                if isinstance(followers, str):
                    if 'K' in str(followers):
                        followers = float(str(followers).replace('K', '')) * 1000
                    elif 'M' in str(followers):
                        followers = float(str(followers).replace('M', '')) * 1000000
                    else:
                        try:
                            followers = int(followers)
                        except:
                            followers = 0
                
                # Estimate activity based on follower count
                if followers > 10000:
                    analysis['activity_level'] = 'high'
                    analysis['frequency_score'] = 0.7
                    analysis['insights'].append("High follower count suggests active account")
                elif followers > 1000:
                    analysis['activity_level'] = 'medium'
                    analysis['frequency_score'] = 0.5
                    analysis['insights'].append("Moderate follower base")
                elif followers > 100:
                    analysis['activity_level'] = 'low'
                    analysis['frequency_score'] = 0.3
                    analysis['insights'].append("Small but active community")
                else:
                    analysis['activity_level'] = 'minimal'
                    analysis['frequency_score'] = 0.1
                    analysis['insights'].append("New or inactive account")
            else:
                # Analyze based on post count
                if total_posts > 1000:
                    analysis['activity_level'] = 'very_high'
                    analysis['frequency_score'] = 0.9
                    analysis['insights'].append("Very active - posts frequently")
                elif total_posts > 500:
                    analysis['activity_level'] = 'high'
                    analysis['frequency_score'] = 0.7
                    analysis['insights'].append("Active - regular posting")
                elif total_posts > 100:
                    analysis['activity_level'] = 'medium'
                    analysis['frequency_score'] = 0.5
                    analysis['insights'].append("Moderate activity")
                else:
                    analysis['activity_level'] = 'low'
                    analysis['frequency_score'] = 0.3
                    analysis['insights'].append("Low activity - occasional posting")
        except Exception as e:
            logger.error(f"Error analyzing posting frequency: {e}")
            analysis['insights'].append("Unable to determine activity level")
        
        return analysis
    
    def extract_bio_keywords(self, bio: str) -> List[str]:
        """Extract keywords from bio"""
        if not bio or bio == 'No bio':
            return []
        
        import re
        keywords = []
        bio_lower = bio.lower()
        
        patterns = ['crypto', 'trading', 'developer', 'content creator', 
                   'photographer', 'entrepreneur', 'student', 'gamer']
        
        for pattern in patterns:
            if pattern in bio_lower:
                keywords.append(pattern)
        
        hashtags = re.findall(r'#\w+', bio_lower)
        keywords.extend(hashtags[:5])
        
        return keywords[:10]
    
    def assess_account_risk(self, profile_data: Dict) -> Dict:
        """Assess account risk level"""
        risk = {
            'risk_level': 'low',
            'risk_score': 0.0,
            'flags': []
        }
        
        try:
            bio = profile_data.get('bio', '').lower()
            suspicious = ['crypto', 'investment', 'dm for', 'click link', 'giveaway']
            flag_count = sum(1 for k in suspicious if k in bio)
            
            if flag_count > 2:
                risk['flags'].append("Multiple promotional keywords")
                risk['risk_score'] += 0.3
            
            if profile_data.get('private'):
                risk['flags'].append("Private account")
                risk['risk_score'] += 0.1
            
            if not profile_data.get('verified'):
                risk['risk_score'] += 0.2
            
            if risk['risk_score'] >= 0.6:
                risk['risk_level'] = 'high'
            elif risk['risk_score'] >= 0.3:
                risk['risk_level'] = 'medium'
        except:
            pass
        
        return risk
    
    def generate_intelligence_report(self, profile_data: Dict) -> Dict:
        """Generate intelligence report"""
        if not profile_data.get('success'):
            return {'error': 'Profile unavailable'}
        
        profile = profile_data.get('profile', {})
        
        return {
            'target': profile.get('username'),
            'platform': profile_data.get('platform'),
            'timestamp': datetime.now().isoformat(),
            'basic_info': {
                'username': profile.get('username'),
                'display_name': profile.get('nickname') or profile.get('full_name'),
                'verified': profile.get('verified', False),
                'bio': profile.get('bio'),
            },
            'metrics': {
                'followers': profile.get('followers'),
                'following': profile.get('following'),
                'posts': profile.get('total_videos') or profile.get('posts'),
            },
            'analysis': {
                'activity': self.analyze_posting_frequency(profile),
                'keywords': self.extract_bio_keywords(profile.get('bio', '')),
                'risk': self.assess_account_risk(profile),
            },
        }
