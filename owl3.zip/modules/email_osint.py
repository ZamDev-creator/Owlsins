#!/usr/bin/env python3
"""
Email OSINT Module - Advanced Version with Evidence System
Analyze email addresses with intelligent scoring
"""

import re
import requests
from typing import Dict, List, Optional

from config import EMAIL_REGEX, USER_AGENT, HIBP_API_KEY
from utils.logger import setup_logger
from utils.database import Database
from core.entity import Entity, Evidence, EvidenceType
from core.confidence_scoring import ConfidenceScorer

logger = setup_logger(__name__)


class EmailOSINT:
    """Advanced email OSINT with evidence generation"""
    
    def __init__(self, entity_manager=None, scorer=None):
        """Initialize with optional entity manager"""
        self.db = Database()
        self.entity_manager = entity_manager
        self.scorer = scorer or ConfidenceScorer()
        
        # Known disposable domains
        self.disposable_domains = {
            'tempmail.com', 'guerrillamail.com', '10minutemail.com',
            'mailinator.com', 'throwaway.email', 'temp-mail.org',
            'fakeinbox.com', 'maildrop.cc', 'trashmail.com',
            'getnada.com', 'temp-mail.io', 'mohmal.com',
            'yopmail.com', 'sharklasers.com', 'guerrillamail.info',
        }
        
        # Common email providers
        self.common_providers = {
            'gmail.com', 'yahoo.com', 'hotmail.com', 'outlook.com',
            'icloud.com', 'aol.com', 'protonmail.com', 'mail.com',
        }
    
    def validate_format(self, email: str) -> bool:
        """Validate email format"""
        return re.match(EMAIL_REGEX, email) is not None
    
    def check_disposable(self, email: str) -> bool:
        """Check if email is from disposable domain"""
        try:
            domain = email.split('@')[1].lower()
            return domain in self.disposable_domains
        except:
            return False
    
    def check_mx_records(self, email: str) -> Dict:
        """Check if domain has valid MX records (simplified)"""
        try:
            domain = email.split('@')[1]
            # Simplified check - in production use dnspython
            # For now, just check if domain looks valid
            if '.' in domain and len(domain) > 3:
                return {
                    'has_mx': True,
                    'valid': True,
                }
            return {'has_mx': False, 'valid': False}
        except:
            return {'has_mx': False, 'valid': False}
    
    def check_breach(self, email: str) -> Dict:
        """
        Check if email is in known breaches
        Uses HaveIBeenPwned API if key available
        """
        if not HIBP_API_KEY:
            logger.warning("HIBP API key not set. Skipping breach check.")
            return {
                'checked': False,
                'breached': False,
                'breach_count': 0,
                'breaches': [],
                'error': 'API key not configured',
            }
        
        try:
            url = f"https://haveibeenpwned.com/api/v3/breachedaccount/{email}"
            headers = {
                'User-Agent': USER_AGENT,
                'hibp-api-key': HIBP_API_KEY,
            }
            
            response = requests.get(url, headers=headers, timeout=10)
            
            if response.status_code == 200:
                breaches = response.json()
                return {
                    'checked': True,
                    'breached': True,
                    'breach_count': len(breaches),
                    'breaches': breaches,
                }
            elif response.status_code == 404:
                return {
                    'checked': True,
                    'breached': False,
                    'breach_count': 0,
                    'breaches': [],
                }
            else:
                return {
                    'checked': False,
                    'breached': False,
                    'breach_count': 0,
                    'breaches': [],
                    'error': f'HTTP {response.status_code}',
                }
                
        except Exception as e:
            logger.error(f"Breach check failed: {e}")
            return {
                'checked': False,
                'breached': False,
                'breach_count': 0,
                'breaches': [],
                'error': str(e),
            }
    
    def extract_username_from_email(self, email: str) -> str:
        """Extract username part from email"""
        return email.split('@')[0]
    
    def analyze_email(self, email: str, create_entity: bool = False) -> Dict:
        """
        Comprehensive email analysis with evidence generation
        """
        logger.info(f"Analyzing email: {email}")
        
        # Basic validation
        is_valid_format = self.validate_format(email)
        if not is_valid_format:
            return {
                'email': email,
                'valid_format': False,
                'error': 'Invalid email format',
            }
        
        # Extract domain and username
        username = self.extract_username_from_email(email)
        domain = email.split('@')[1].lower()
        
        # Run checks
        is_disposable = self.check_disposable(email)
        mx_check = self.check_mx_records(email)
        breach_check = self.check_breach(email)
        
        # Determine domain type
        if domain in self.common_providers:
            domain_type = 'common_provider'
        elif is_disposable:
            domain_type = 'disposable'
        else:
            domain_type = 'custom_domain'
        
        # Calculate confidence score
        confidence = self._calculate_email_confidence(
            is_valid_format,
            mx_check['valid'],
            not is_disposable,
            domain_type,
        )
        
        # Calculate risk score
        risk_score = 0.0
        if is_disposable:
            risk_score += 0.40
        if breach_check.get('breached'):
            risk_score += min(breach_check['breach_count'] * 0.15, 0.50)
        if not mx_check['valid']:
            risk_score += 0.20
        
        result = {
            'email': email,
            'username': username,
            'domain': domain,
            'domain_type': domain_type,
            'valid_format': is_valid_format,
            'is_disposable': is_disposable,
            'mx_records': mx_check,
            'breach_info': breach_check,
            'confidence': confidence,
            'risk_score': min(risk_score, 1.0),
        }
        
        # Create entity if requested
        if create_entity and self.entity_manager:
            entity = self._create_entity_from_analysis(email, result)
            result['entity'] = entity
        
        # Save to database
        try:
            import json
            self.db.save_email_result(email, json.dumps(result))
        except Exception as e:
            logger.error(f"Failed to save to database: {e}")
        
        return result
    
    def _calculate_email_confidence(self, valid_format: bool, has_mx: bool,
                                   not_disposable: bool, domain_type: str) -> float:
        """Calculate confidence that email is valid and active"""
        score = 0.0
        
        if valid_format:
            score += 0.25
        if has_mx:
            score += 0.40
        if not_disposable:
            score += 0.20
        
        # Bonus for custom domain (implies organization/professional)
        if domain_type == 'custom_domain':
            score += 0.15
        
        return min(score, 1.0)
    
    def _create_entity_from_analysis(self, email: str, analysis: Dict) -> Entity:
        """
        Create entity and evidence from email analysis
        """
        entity = self.entity_manager.get_or_create_entity(email, entity_type='person')
        entity.add_identifier('email', email)
        
        # Add username as identifier
        username = analysis['username']
        entity.add_identifier('username', username)
        
        # Evidence 1: Email validation
        if analysis['valid_format'] and analysis['mx_records']['valid']:
            score = self.scorer.score_email_finding(
                found=True,
                is_valid=True,
                in_breach=analysis['breach_info'].get('breached', False),
                domain_matches=False,
                reliability=0.90,
            )
            
            evidence = Evidence(
                source='email_osint',
                evidence_type=EvidenceType.EMAIL,
                signal='email_validated',
                value=email,
                weight=0.40,
                reliability=0.90,
                metadata={
                    'domain': analysis['domain'],
                    'domain_type': analysis['domain_type'],
                    'mx_records': analysis['mx_records'],
                }
            )
            entity.add_evidence(evidence)
        
        # Evidence 2: Breach information
        if analysis['breach_info'].get('checked') and analysis['breach_info'].get('breached'):
            breach_count = analysis['breach_info']['breach_count']
            
            evidence = Evidence(
                source='email_osint',
                evidence_type=EvidenceType.BREACH,
                signal='email_in_breach',
                value=breach_count,
                weight=0.25,
                reliability=0.95,
                metadata={
                    'breach_count': breach_count,
                    'breaches': analysis['breach_info'].get('breaches', [])[:5],
                }
            )
            entity.add_evidence(evidence)
            
            # Add breach info to attributes
            entity.attributes['breaches'] = analysis['breach_info']['breaches']
        
        # Evidence 3: Domain type signal
        if analysis['domain_type'] == 'custom_domain':
            evidence = Evidence(
                source='email_osint',
                evidence_type=EvidenceType.EMAIL,
                signal='custom_domain_email',
                value=analysis['domain'],
                weight=0.15,
                reliability=0.85,
                metadata={'domain': analysis['domain']}
            )
            entity.add_evidence(evidence)
        
        # Add email attributes
        entity.attributes['email_info'] = {
            'domain': analysis['domain'],
            'domain_type': analysis['domain_type'],
            'is_disposable': analysis['is_disposable'],
            'risk_score': analysis['risk_score'],
        }
        
        # Set risk score
        entity.risk_score = analysis['risk_score']
        
        logger.info(f"Created entity for {email} with {len(entity.evidence)} pieces of evidence")
        return entity
    
    def batch_analyze(self, emails: List[str]) -> List[Dict]:
        """Analyze multiple emails"""
        results = []
        for email in emails:
            result = self.analyze_email(email)
            results.append(result)
        return results
    
    def format_result(self, result: Dict) -> str:
        """Format analysis result for display"""
        email = result['email']
        
        output = [
            f"\n{'='*70}",
            f"EMAIL ANALYSIS: {email}",
            f"{'='*70}\n",
        ]
        
        # Validation
        valid_emoji = "✅" if result['valid_format'] else "❌"
        output.append(f"{valid_emoji} Format: {'Valid' if result['valid_format'] else 'Invalid'}")
        
        # MX Records
        mx = result['mx_records']
        mx_emoji = "✅" if mx.get('valid') else "❌"
        output.append(f"{mx_emoji} MX Records: {'Valid' if mx.get('valid') else 'Invalid'}")
        
        # Domain info
        output.append(f"\n📧 Domain: {result['domain']}")
        output.append(f"   Type: {result['domain_type']}")
        output.append(f"   Disposable: {'Yes ⚠️' if result['is_disposable'] else 'No ✅'}")
        
        # Breach info
        breach = result['breach_info']
        if breach.get('checked'):
            if breach['breached']:
                output.append(f"\n🔴 SECURITY ALERT: Found in {breach['breach_count']} breach(es)")
                if breach.get('breaches'):
                    output.append("   Recent breaches:")
                    for b in breach['breaches'][:3]:
                        if isinstance(b, dict):
                            output.append(f"   • {b.get('Name', 'Unknown')} ({b.get('BreachDate', 'Unknown date')})")
            else:
                output.append("\n🟢 No breaches found")
        
        # Scores
        output.append(f"\n📊 Confidence: {result['confidence']:.2%}")
        output.append(f"⚠️  Risk Score: {result['risk_score']:.2%}")
        
        # Entity info
        if 'entity' in result:
            entity = result['entity']
            output.append(f"\n{'='*70}")
            output.append("ENTITY INTELLIGENCE")
            output.append(f"{'='*70}\n")
            output.append(f"Overall Confidence: {entity.confidence_score:.2%} ({entity.get_confidence_level().label})")
            output.append(f"Evidence Pieces: {len(entity.evidence)}")
            output.append(f"Risk Score: {entity.risk_score:.2%}")
            
            if entity.identifiers.get('username'):
                output.append(f"\nSuggested usernames to search:")
                for username in entity.identifiers['username'][:3]:
                    output.append(f"  • {username}")
        
        return "\n".join(output)
