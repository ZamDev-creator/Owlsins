"""
OSINT Image Intelligence Module - COMPLETE VERSION
Comprehensive image analysis: EXIF extraction, reverse image search, face detection, location recognition
With SearchAPI.io integration (100% FREE, no credit card)
"""

import os
import json
import requests
import cv2
import numpy as np
from PIL import Image
from PIL.ExifTags import TAGS, GPSTAGS
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from datetime import datetime
import base64
from io import BytesIO

from utils.logger import setup_logger
from utils.database import Database

logger = setup_logger(__name__)


class OSINTImageTools:
    """Advanced OSINT Image Intelligence Tool with SearchAPI integration"""
    
    def __init__(self):
        """Initialize OSINT Image Tools"""
        self.db = Database()
        self.cascade_path = self._download_cascade_if_needed()
        
        # Initialize SearchAPI for location recognition
        self.searchapi_key = self._load_searchapi_key()
        
    def _download_cascade_if_needed(self) -> Optional[str]:
        """Download Haar Cascade for face detection if not exists"""
        cascade_dir = Path("data/cascades")
        cascade_dir.mkdir(parents=True, exist_ok=True)
        cascade_path = cascade_dir / "haarcascade_frontalface_alt.xml"
        
        if not cascade_path.exists():
            logger.info("Downloading Haar Cascade for face detection...")
            try:
                url = "https://raw.githubusercontent.com/opencv/opencv/master/data/haarcascades/haarcascade_frontalface_alt.xml"
                response = requests.get(url, timeout=30)
                response.raise_for_status()
                
                with open(cascade_path, 'wb') as f:
                    f.write(response.content)
                logger.info(f"Cascade downloaded to: {cascade_path}")
                return str(cascade_path)
            except Exception as e:
                logger.error(f"Failed to download cascade: {e}")
                return None
        return str(cascade_path)
    
    def _load_searchapi_key(self) -> Optional[str]:
        """Load SearchAPI key from config"""
        try:
            from config import SEARCHAPI_KEY
            if SEARCHAPI_KEY:
                logger.info("[SEARCHAPI] API key loaded")
                return SEARCHAPI_KEY
            else:
                logger.warning("[SEARCHAPI] No API key found in config")
                return None
        except ImportError:
            logger.warning("[SEARCHAPI] config.py not found or SEARCHAPI_KEY not defined")
            return None
        except Exception as e:
            logger.warning(f"[SEARCHAPI] Error loading API key: {e}")
            return None
    
    # ==================== PHASE 1: EXIF EXTRACTION + GPS ====================
    
    def extract_exif_data(self, image_path: str) -> Dict:
        """
        Extract comprehensive EXIF metadata from image
        
        Args:
            image_path: Path to image file
            
        Returns:
            dict: Complete EXIF metadata including GPS
        """
        logger.info(f"[EXIF] Extracting metadata from: {image_path}")
        
        metadata = {
            'filename': Path(image_path).name,
            'filepath': str(image_path),
            'file_size': None,
            'file_size_mb': None,
            'dimensions': None,
            'format': None,
            'mode': None,
            'camera_make': None,
            'camera_model': None,
            'software': None,
            'timestamp_taken': None,
            'timestamp_modified': None,
            'latitude': None,
            'longitude': None,
            'altitude': None,
            'gps_location': None,
            'orientation': None,
            'flash': None,
            'focal_length': None,
            'exposure_time': None,
            'f_number': None,
            'iso': None,
            'lens_make': None,
            'lens_model': None,
            'white_balance': None,
            'metering_mode': None,
            'exposure_program': None,
            'scene_type': None,
            'all_exif': {}
        }
        
        try:
            # File info
            file_stat = Path(image_path).stat()
            metadata['file_size'] = file_stat.st_size
            metadata['file_size_mb'] = round(file_stat.st_size / (1024 * 1024), 2)
            metadata['timestamp_modified'] = datetime.fromtimestamp(file_stat.st_mtime).isoformat()
            
            # Open and analyze image
            with Image.open(image_path) as img:
                metadata['dimensions'] = f"{img.width}x{img.height}"
                metadata['format'] = img.format
                metadata['mode'] = img.mode
                
                # Extract EXIF
                exif_data = img._getexif()
                
                if exif_data:
                    for tag_id, value in exif_data.items():
                        tag = TAGS.get(tag_id, tag_id)
                        
                        # Store all EXIF
                        try:
                            metadata['all_exif'][tag] = str(value)
                        except:
                            metadata['all_exif'][tag] = repr(value)
                        
                        # Extract specific fields
                        self._extract_specific_field(metadata, tag, value)
                    
                    logger.info(f"[EXIF] Extracted {len(metadata['all_exif'])} EXIF tags")
                    
                    # Generate GPS location string
                    if metadata['latitude'] and metadata['longitude']:
                        metadata['gps_location'] = f"{metadata['latitude']:.6f}, {metadata['longitude']:.6f}"
                        metadata['google_maps_url'] = self._generate_maps_url(
                            metadata['latitude'], 
                            metadata['longitude']
                        )
                else:
                    logger.warning("[EXIF] No EXIF data found in image")
            
            # Save to database
            self.db.save_image_metadata(metadata['filename'], metadata)
            
            return metadata
            
        except Exception as e:
            logger.error(f"[EXIF] Error extracting metadata: {e}")
            return metadata
    
    def _extract_specific_field(self, metadata: Dict, tag: str, value):
        """Extract specific EXIF fields into metadata dict"""
        field_mapping = {
            'Make': 'camera_make',
            'Model': 'camera_model',
            'Software': 'software',
            'DateTime': 'timestamp_taken',
            'DateTimeOriginal': 'timestamp_taken',
            'Orientation': 'orientation',
            'Flash': 'flash',
            'FocalLength': 'focal_length',
            'ExposureTime': 'exposure_time',
            'FNumber': 'f_number',
            'ISOSpeedRatings': 'iso',
            'LensMake': 'lens_make',
            'LensModel': 'lens_model',
            'WhiteBalance': 'white_balance',
            'MeteringMode': 'metering_mode',
            'ExposureProgram': 'exposure_program',
            'SceneCaptureType': 'scene_type'
        }
        
        if tag in field_mapping:
            metadata[field_mapping[tag]] = value
        elif tag == 'GPSInfo':
            self._extract_gps_data(metadata, value)
    
    def _extract_gps_data(self, metadata: Dict, gps_value):
        """Extract GPS data from EXIF"""
        try:
            gps_info = {}
            for gps_tag_id in gps_value:
                gps_tag = GPSTAGS.get(gps_tag_id, gps_tag_id)
                gps_info[gps_tag] = gps_value[gps_tag_id]
            
            # Convert to decimal coordinates
            lat, lon = self._gps_to_decimal(gps_info)
            metadata['latitude'] = lat
            metadata['longitude'] = lon
            
            if 'GPSAltitude' in gps_info:
                try:
                    metadata['altitude'] = float(gps_info['GPSAltitude'])
                except:
                    pass
                    
        except Exception as e:
            logger.error(f"[GPS] Error extracting GPS data: {e}")
    
    def _gps_to_decimal(self, gps_info: Dict) -> Tuple[Optional[float], Optional[float]]:
        """Convert GPS coordinates to decimal degrees"""
        try:
            lat = gps_info.get('GPSLatitude')
            lat_ref = gps_info.get('GPSLatitudeRef')
            lon = gps_info.get('GPSLongitude')
            lon_ref = gps_info.get('GPSLongitudeRef')
            
            if lat and lat_ref and lon and lon_ref:
                # Convert to degrees
                lat_decimal = self._dms_to_decimal(lat)
                if lat_ref != 'N':
                    lat_decimal = -lat_decimal
                
                lon_decimal = self._dms_to_decimal(lon)
                if lon_ref != 'E':
                    lon_decimal = -lon_decimal
                
                return lat_decimal, lon_decimal
            return None, None
        except Exception as e:
            logger.error(f"[GPS] Conversion error: {e}")
            return None, None
    
    def _dms_to_decimal(self, dms) -> float:
        """Convert DMS (degrees, minutes, seconds) to decimal"""
        try:
            d = float(dms[0])
            m = float(dms[1])
            s = float(dms[2])
            return d + (m / 60.0) + (s / 3600.0)
        except:
            return float(dms[0])
    
    def _generate_maps_url(self, lat: float, lon: float) -> str:
        """Generate Google Maps URL"""
        return f"https://www.google.com/maps?q={lat},{lon}"
    
    # ==================== PHASE 2: REVERSE IMAGE SEARCH ====================
    
    def reverse_image_search(self, image_path: str, method: str = 'auto') -> Dict:
        """
        Perform reverse image search using available methods
        
        Args:
            image_path: Path to image file
            method: 'auto' (use API if available), 'api' (force API), 'free' (manual URLs)
            
        Returns:
            dict: Search results with URLs for manual search or API results
        """
        logger.info(f"[REVERSE SEARCH] Starting reverse search for: {image_path}")
        
        results = {
            'success': False,
            'method': method,
            'similar_images': [],
            'pages_with_image': [],
            'visually_similar': [],
            'best_guess': None,
            'error': None
        }
        
        try:
            # If API key is available and method is auto or api, try SearchAPI
            if self.searchapi_key and method in ['auto', 'api']:
                logger.info("[REVERSE SEARCH] Using SearchAPI for reverse search...")
                results = self._reverse_search_with_api(image_path)
                
                # If API fails and method is auto, fallback to manual
                if not results.get('success') and method == 'auto':
                    logger.warning("[REVERSE SEARCH] API failed, falling back to manual")
                    results = self._reverse_search_free(image_path)
            else:
                # No API key or method is 'free'
                results = self._reverse_search_free(image_path)
                
        except Exception as e:
            logger.error(f"[REVERSE SEARCH] Error: {e}")
            results['error'] = str(e)
            # Fallback to manual method
            results = self._reverse_search_free(image_path)
        
        return results
    
    def _reverse_search_with_api(self, image_path: str) -> Dict:
        """Perform reverse search using SearchAPI"""
        try:
            # Upload image first
            logger.info("[REVERSE SEARCH] Uploading image...")
            image_url = self._upload_to_imgbb(image_path)
            
            if not image_url:
                logger.warning("[REVERSE SEARCH] Upload failed, using manual method")
                return self._reverse_search_free(image_path)
            
            logger.info(f"[REVERSE SEARCH] Image uploaded: {image_url}")
            
            # Call SearchAPI for reverse image search
            base_url = "https://www.searchapi.io/api/v1/search"
            
            params = {
                "engine": "google_reverse_image",
                "image_url": image_url,
                "api_key": self.searchapi_key
            }
            
            response = requests.get(base_url, params=params, timeout=30)
            response.raise_for_status()
            
            data = response.json()
            
            # Parse results
            results = {
                'success': True,
                'method': 'searchapi',
                'similar_images': [],
                'pages_with_image': [],
                'visually_similar': [],
                'best_guess': None,
                'image_url': image_url
            }
            
            # Extract best guess
            if 'inline_images' in data:
                results['best_guess'] = data['inline_images'][0].get('title', '') if data['inline_images'] else None
            
            # Extract similar images
            if 'visual_matches' in data:
                for match in data['visual_matches'][:10]:
                    results['similar_images'].append({
                        'title': match.get('title', ''),
                        'link': match.get('link', ''),
                        'source': match.get('source', ''),
                        'thumbnail': match.get('thumbnail', '')
                    })
            
            # Extract pages with matching images
            if 'inline_images' in data:
                for img in data['inline_images'][:10]:
                    results['pages_with_image'].append({
                        'title': img.get('title', ''),
                        'link': img.get('link', ''),
                        'source': img.get('source', '')
                    })
            
            logger.info(f"[REVERSE SEARCH] Found {len(results['similar_images'])} similar images")
            return results
            
        except Exception as e:
            logger.error(f"[REVERSE SEARCH] API error: {e}")
            return {
                'success': False,
                'method': 'searchapi',
                'error': str(e),
                'fallback': self._reverse_search_free(image_path)
            }
    
    def _reverse_search_free(self, image_path: str) -> Dict:
        """Provide manual search URLs for reverse image search"""
        try:
            abs_path = Path(image_path).absolute()
            
            results = {
                'success': True,
                'method': 'manual',
                'similar_images': [],
                'pages_with_image': [],
                'visually_similar': [],
                'best_guess': None,
                'search_urls': {
                    'google': 'https://images.google.com/',
                    'tineye': 'https://tineye.com/',
                    'yandex': 'https://yandex.com/images/'
                },
                'note': f'Upload {abs_path.name} to one of these search engines manually:\n' +
                        '1. Google Images: https://images.google.com/ (click camera icon)\n' +
                        '2. TinEye: https://tineye.com/ (drag and drop image)\n' +
                        '3. Yandex: https://yandex.com/images/ (click camera icon)'
            }
            
            logger.info("[REVERSE SEARCH] Returning manual search URLs")
            return results
            
        except Exception as e:
            logger.error(f"[REVERSE SEARCH] Error: {e}")
            return {
                'success': False,
                'method': 'free',
                'error': str(e),
                'similar_images': [],
                'pages_with_image': [],
                'visually_similar': [],
                'best_guess': None
            }
    
    # ==================== PHASE 3: FACE DETECTION ====================
    
    def detect_faces(self, image_path: str, save_output: bool = True) -> Dict:
        """
        Detect faces in image using OpenCV Haar Cascade
        
        Args:
            image_path: Path to image file
            save_output: Whether to save annotated image
            
        Returns:
            dict: Face detection results
        """
        logger.info(f"[FACE DETECTION] Analyzing: {image_path}")
        
        results = {
            'success': False,
            'faces_detected': 0,
            'face_locations': [],
            'annotated_image': None,
            'error': None
        }
        
        if not self.cascade_path or not Path(self.cascade_path).exists():
            results['error'] = "Haar Cascade not available"
            return results
        
        try:
            # Load cascade classifier
            face_cascade = cv2.CascadeClassifier(self.cascade_path)
            
            # Read image
            img = cv2.imread(image_path)
            if img is None:
                results['error'] = "Failed to load image"
                return results
            
            # Convert to grayscale
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            
            # Detect faces with optimized parameters for better detection
            faces = face_cascade.detectMultiScale(
                gray,
                scaleFactor=1.05,  # Lower value = more sensitive (default was 1.1)
                minNeighbors=4,    # Lower value = more detections (default was 5)
                minSize=(20, 20),  # Smaller minimum size (default was 30x30)
                flags=cv2.CASCADE_SCALE_IMAGE
            )
            
            results['faces_detected'] = len(faces)
            
            # Process each face
            for i, (x, y, w, h) in enumerate(faces):
                results['face_locations'].append({
                    'id': i + 1,
                    'x': int(x),
                    'y': int(y),
                    'width': int(w),
                    'height': int(h),
                    'center_x': int(x + w/2),
                    'center_y': int(y + h/2)
                })
                
                # Draw rectangle on image
                cv2.rectangle(img, (x, y), (x+w, y+h), (0, 255, 0), 2)
                cv2.putText(img, f"Face {i+1}", (x, y-10), 
                           cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)
            
            # Save annotated image - FIXED BUG HERE
            if save_output and len(faces) > 0:
                output_dir = Path("output/face_detection")
                output_dir.mkdir(parents=True, exist_ok=True)
                
                filename = Path(image_path).stem
                output_path = output_dir / f"{filename}_faces.jpg"
                cv2.imwrite(str(output_path), img)
                results['annotated_image'] = str(output_path)
                logger.info(f"[FACE DETECTION] Saved to: {output_path}")
            
            results['success'] = True
            logger.info(f"[FACE DETECTION] Found {results['faces_detected']} face(s)")
            
        except Exception as e:
            logger.error(f"[FACE DETECTION] Error: {e}")
            results['error'] = str(e)
        
        return results
    
    # ==================== PHASE 4: LOCATION RECOGNITION (SearchAPI) ====================
    
    def recognize_location(self, image_path: str) -> Dict:
        """
        Recognize landmarks/locations using SearchAPI.io (Google Lens scraper)
        
        Args:
            image_path: Path to image file
            
        Returns:
            dict: Location recognition results
        """
        logger.info(f"[LOCATION] Analyzing location in: {image_path}")
        
        if not self.searchapi_key:
            return self._location_manual_method(image_path)
        
        try:
            # Use SearchAPI to scrape Google Lens results
            results = self._search_with_searchapi(image_path)
            return results
        except Exception as e:
            logger.error(f"[LOCATION] Error: {e}")
            return {
                'success': False,
                'method': 'searchapi',
                'error': str(e),
                'landmarks': [],
                'fallback': self._location_manual_method(image_path)
            }
    
    def _search_with_searchapi(self, image_path: str) -> Dict:
        """Search location using SearchAPI.io"""
        logger.info("[LOCATION] Using SearchAPI.io (Google Lens)...")
        
        try:
            # Step 1: Upload image to ImgBB (free temporary hosting)
            logger.info("[LOCATION] Uploading image to temporary hosting...")
            image_url = self._upload_to_imgbb(image_path)
            
            if not image_url:
                logger.warning("[LOCATION] Image upload failed, using upload method")
                return self._location_upload_method(image_path)
            
            logger.info(f"[LOCATION] Image uploaded: {image_url}")
            
            # Step 2: Call SearchAPI with image URL
            logger.info("[LOCATION] Calling SearchAPI...")
            result = self.search_location_by_url(image_url)
            
            return result
            
        except Exception as e:
            logger.error(f"[LOCATION] SearchAPI error: {e}")
            return self._location_manual_method(image_path)
    
    def _upload_to_imgbb(self, image_path: str) -> Optional[str]:
        """Upload image to ImgBB (free hosting)"""
        try:
            # Using ImgBB free API (no key required for basic upload)
            # Alternative: use 0x0.st or catbox.moe
            
            # Try 0x0.st first (simple, no API key needed)
            url = self._upload_to_0x0(image_path)
            if url:
                return url
            
            # Fallback to catbox.moe
            url = self._upload_to_catbox(image_path)
            if url:
                return url
            
            logger.warning("[LOCATION] All upload services failed")
            return None
            
        except Exception as e:
            logger.error(f"[LOCATION] Upload error: {e}")
            return None
    
    def _upload_to_0x0(self, image_path: str) -> Optional[str]:
        """Upload to 0x0.st (simple, free, no API key)"""
        try:
            with open(image_path, 'rb') as f:
                files = {'file': f}
                response = requests.post('https://0x0.st', files=files, timeout=30)
                
                if response.status_code == 200:
                    url = response.text.strip()
                    logger.info(f"[LOCATION] Uploaded to 0x0.st: {url}")
                    return url
        except Exception as e:
            logger.warning(f"[LOCATION] 0x0.st upload failed: {e}")
        return None
    
    def _upload_to_catbox(self, image_path: str) -> Optional[str]:
        """Upload to catbox.moe (free, no API key)"""
        try:
            with open(image_path, 'rb') as f:
                files = {'fileToUpload': f}
                data = {'reqtype': 'fileupload'}
                response = requests.post(
                    'https://catbox.moe/user/api.php',
                    files=files,
                    data=data,
                    timeout=30
                )
                
                if response.status_code == 200:
                    url = response.text.strip()
                    logger.info(f"[LOCATION] Uploaded to catbox.moe: {url}")
                    return url
        except Exception as e:
            logger.warning(f"[LOCATION] catbox.moe upload failed: {e}")
        return None
    
    def search_location_by_url(self, image_url: str) -> Dict:
        """
        Search location using image URL with SearchAPI
        
        Args:
            image_url: Public URL of the image
            
        Returns:
            dict: Location recognition results
        """
        logger.info(f"[LOCATION] Searching by URL: {image_url}")
        
        if not self.searchapi_key:
            return {
                'success': False,
                'error': 'SearchAPI key required',
                'note': 'Add SEARCHAPI_KEY to config.py',
                'get_api_key': 'Register at https://www.searchapi.io/ (100 free requests/month)'
            }
        
        try:
            base_url = "https://www.searchapi.io/api/v1/search"
            
            params = {
                "engine": "google_lens",
                "url": image_url,
                "api_key": self.searchapi_key
            }
            
            response = requests.get(base_url, params=params, timeout=30)
            response.raise_for_status()
            
            data = response.json()
            results = self._parse_searchapi_results(data)
            results['method'] = 'searchapi'
            results['success'] = True
            
            logger.info(f"[LOCATION] Found {len(results.get('landmarks', []))} result(s)")
            return results
            
        except Exception as e:
            logger.error(f"[LOCATION] URL search error: {e}")
            return {
                'success': False,
                'method': 'searchapi',
                'error': str(e)
            }
    
    def _parse_searchapi_results(self, data: Dict) -> Dict:
        """Parse SearchAPI response"""
        results = {
            'landmarks': [],
            'visual_matches': [],
            'pages_with_image': [],
            'location_name': None,
            'coordinates': None,
            'confidence': 0.0,
            'labels': []
        }
        
        # Extract visual matches
        if 'visual_matches' in data:
            for match in data['visual_matches'][:5]:
                results['visual_matches'].append({
                    'title': match.get('title', ''),
                    'link': match.get('link', ''),
                    'source': match.get('source', '')
                })
        
        # Extract knowledge graph (landmark info)
        if 'knowledge_graph' in data:
            kg = data['knowledge_graph']
            
            landmark_info = {
                'name': kg.get('title', ''),
                'description': kg.get('description', ''),
                'type': kg.get('type', '')
            }
            
            if 'location' in kg:
                landmark_info['location'] = kg['location']
            
            if landmark_info['name']:
                results['landmarks'].append(landmark_info)
                results['location_name'] = landmark_info['name']
                results['confidence'] = 0.90
        
        # Extract text results
        if 'text_results' in data:
            for text in data['text_results'][:5]:
                results['labels'].append(text.get('title', ''))
        
        # Use first visual match if no knowledge graph
        if not results['location_name'] and results['visual_matches']:
            first_match = results['visual_matches'][0]
            results['location_name'] = first_match['title']
            results['confidence'] = 0.70
        
        return results
    
    def _location_manual_method(self, image_path: str) -> Dict:
        """Return manual Google Lens method"""
        abs_path = Path(image_path).absolute()
        
        return {
            'success': True,
            'method': 'manual',
            'landmarks': [],
            'location_name': None,
            'search_urls': {
                'google_lens': 'https://lens.google.com/',
                'google_images': 'https://images.google.com/'
            },
            'instructions': [
                f'Upload {abs_path.name} to Google Lens for location recognition',
                '',
                '🎯 BEST METHOD: Google Lens',
                '   1. Go to https://lens.google.com/',
                '   2. Click "Upload image"',
                '   3. Select your photo',
                '   4. Google will identify the location automatically',
                '',
                '💡 TIP: For automated results, add SearchAPI key to config.py',
                '   Register at: https://www.searchapi.io/ (100 free/month)'
            ],
            'note': 'No SearchAPI key found. Manual upload recommended.'
        }
    
    def _location_upload_method(self, image_path: str) -> Dict:
        """Return upload instructions for SearchAPI"""
        abs_path = Path(image_path).absolute()
        
        return {
            'success': True,
            'method': 'upload_required',
            'landmarks': [],
            'upload_instructions': {
                'step1': f'Upload {abs_path.name} to free image hosting',
                'step2': 'Get public URL of the image',
                'step3': 'Use search_location_by_url(url) method',
                'services': [
                    'ImgBB: https://imgbb.com/ (recommended)',
                    'Imgur: https://imgur.com/',
                    'Postimages: https://postimages.org/'
                ]
            },
            'example': '''
# After uploading to ImgBB:
url = "https://i.ibb.co/xxxxx/image.jpg"
result = osint.search_location_by_url(url)
            ''',
            'note': 'SearchAPI needs image URL. Upload to free hosting, then use URL method.'
        }
    
    # ==================== UTILITY METHODS ====================
    
    def analyze_image_comprehensive(self, image_path: str) -> Dict:
        """
        Perform comprehensive image analysis: EXIF + Reverse Search + Face Detection + Location
        
        Args:
            image_path: Path to image file
            
        Returns:
            dict: Complete analysis results
        """
        logger.info(f"[COMPREHENSIVE] Starting full analysis: {image_path}")
        
        results = {
            'image_path': image_path,
            'filename': Path(image_path).name,
            'timestamp': datetime.now().isoformat(),
            'exif_data': {},
            'reverse_search': {},
            'face_detection': {},
            'location': {}
        }
        
        # Phase 1: EXIF
        logger.info("[COMPREHENSIVE] Phase 1: EXIF extraction...")
        results['exif_data'] = self.extract_exif_data(image_path)
        
        # Phase 2: Reverse Image Search
        logger.info("[COMPREHENSIVE] Phase 2: Reverse image search...")
        results['reverse_search'] = self.reverse_image_search(image_path, method='auto')
        
        # Phase 3: Face Detection
        logger.info("[COMPREHENSIVE] Phase 3: Face detection...")
        results['face_detection'] = self.detect_faces(image_path)
        
        # Phase 4: Location Recognition
        logger.info("[COMPREHENSIVE] Phase 4: Location recognition...")
        results['location'] = self.recognize_location(image_path)
        
        # If GPS exists, add to location results
        if results['exif_data'].get('latitude'):
            if 'from_gps' not in results['location']:
                results['location']['from_gps'] = {}
            results['location']['from_gps'] = {
                'latitude': results['exif_data']['latitude'],
                'longitude': results['exif_data']['longitude'],
                'maps_url': results['exif_data'].get('google_maps_url')
            }
        
        logger.info("[COMPREHENSIVE] Analysis complete!")
        return results
    
    def generate_html_report(self, analysis_results: Dict) -> str:
        """Generate HTML report for image analysis"""
        html = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>OSINT Image Analysis Report</title>
    <style>
        body {{ font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }}
        .container {{ max-width: 1200px; margin: 0 auto; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }}
        h1 {{ color: #2c3e50; border-bottom: 3px solid #3498db; padding-bottom: 10px; }}
        h2 {{ color: #34495e; margin-top: 30px; border-left: 4px solid #3498db; padding-left: 10px; }}
        .section {{ margin: 20px 0; padding: 15px; background: #f9f9f9; border-radius: 5px; }}
        .data-row {{ display: flex; margin: 8px 0; }}
        .data-label {{ font-weight: bold; width: 200px; color: #555; }}
        .data-value {{ color: #333; }}
        .success {{ color: #27ae60; font-weight: bold; }}
        .warning {{ color: #f39c12; font-weight: bold; }}
        .error {{ color: #e74c3c; font-weight: bold; }}
        a {{ color: #3498db; text-decoration: none; }}
        a:hover {{ text-decoration: underline; }}
        pre {{ background: #f4f4f4; padding: 10px; border-radius: 5px; overflow-x: auto; }}
        .info-box {{ background: #e8f4f8; padding: 15px; border-left: 4px solid #3498db; margin: 15px 0; }}
    </style>
</head>
<body>
    <div class="container">
        <h1>🦉 OSINT Image Intelligence Report</h1>
        <div class="section">
            <p><strong>File:</strong> {analysis_results['filename']}</p>
            <p><strong>Analysis Time:</strong> {analysis_results['timestamp']}</p>
        </div>
"""
        
        # EXIF Data
        exif = analysis_results.get('exif_data', {})
        if exif:
            html += """
        <h2>📷 EXIF Metadata</h2>
        <div class="section">
"""
            if exif.get('camera_make'):
                html += f"            <div class='data-row'><span class='data-label'>Camera:</span><span class='data-value'>{exif['camera_make']} {exif.get('camera_model', '')}</span></div>\n"
            if exif.get('timestamp_taken'):
                html += f"            <div class='data-row'><span class='data-label'>Date Taken:</span><span class='data-value'>{exif['timestamp_taken']}</span></div>\n"
            if exif.get('dimensions'):
                html += f"            <div class='data-row'><span class='data-label'>Dimensions:</span><span class='data-value'>{exif['dimensions']}</span></div>\n"
            if exif.get('file_size_mb'):
                html += f"            <div class='data-row'><span class='data-label'>File Size:</span><span class='data-value'>{exif['file_size_mb']} MB</span></div>\n"
            if exif.get('gps_location'):
                html += f"            <div class='data-row'><span class='data-label'>GPS:</span><span class='data-value'>{exif['gps_location']}</span></div>\n"
                if exif.get('google_maps_url'):
                    html += f"            <div class='data-row'><span class='data-label'>Map:</span><span class='data-value'><a href='{exif['google_maps_url']}' target='_blank'>View on Google Maps</a></span></div>\n"
            
            html += "        </div>\n"
        
        # Face Detection
        faces = analysis_results.get('face_detection', {})
        if faces:
            html += f"""
        <h2>👤 Face Detection</h2>
        <div class="section">
            <div class='data-row'><span class='data-label'>Faces Detected:</span><span class='data-value {"success" if faces.get("faces_detected", 0) > 0 else "warning"}'>{faces.get('faces_detected', 0)}</span></div>
"""
            if faces.get('annotated_image'):
                html += f"            <div class='data-row'><span class='data-label'>Annotated Image:</span><span class='data-value'>{faces['annotated_image']}</span></div>\n"
            html += "        </div>\n"
        
        # Location Recognition
        location = analysis_results.get('location', {})
        if location:
            html += """
        <h2>📍 Location Recognition</h2>
        <div class="section">
"""
            if location.get('method') == 'manual':
                html += """            <div class='info-box'>
                <p><strong>Manual Upload Required</strong></p>
                <p>For best location recognition results, upload your image to:</p>
                <ul>
"""
                if location.get('search_urls'):
                    for name, url in location['search_urls'].items():
                        html += f"                    <li><a href='{url}' target='_blank'>{name.replace('_', ' ').title()}</a></li>\n"
                html += """                </ul>
            </div>
"""
            elif location.get('location_name'):
                html += f"            <div class='data-row'><span class='data-label'>Location:</span><span class='data-value success'>{location['location_name']}</span></div>\n"
                if location.get('confidence'):
                    html += f"            <div class='data-row'><span class='data-label'>Confidence:</span><span class='data-value'>{location['confidence']:.0%}</span></div>\n"
            
            if location.get('from_gps'):
                gps = location['from_gps']
                html += f"""            <div class='data-row'><span class='data-label'>GPS Location:</span><span class='data-value'>{gps['latitude']:.6f}, {gps['longitude']:.6f}</span></div>
            <div class='data-row'><span class='data-label'>Map:</span><span class='data-value'><a href='{gps['maps_url']}' target='_blank'>View on Map</a></span></div>
"""
            
            html += "        </div>\n"
        
        # Reverse Search
        search = analysis_results.get('reverse_search', {})
        if search:
            html += """
        <h2>🔍 Reverse Image Search</h2>
        <div class="section">
"""
            if search.get('note'):
                html += f"            <p>{search['note']}</p>\n"
            
            if search.get('search_urls'):
                html += "            <p><strong>Search Engines:</strong></p>\n<ul>\n"
                for engine, url in search['search_urls'].items():
                    html += f"                <li><a href='{url}' target='_blank'>{engine.title()}</a></li>\n"
                html += "            </ul>\n"
            
            html += "        </div>\n"
        
        html += """
    </div>
</body>
</html>
"""
        
        # Save report
        report_dir = Path("output/reports")
        report_dir.mkdir(parents=True, exist_ok=True)
        report_path = report_dir / f"analysis_{datetime.now().strftime('%Y%m%d_%H%M%S')}.html"
        
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write(html)
        
        logger.info(f"[REPORT] Saved to: {report_path}")
        return str(report_path)


# Backward compatibility alias
ImageMetadata = OSINTImageTools
