#!/usr/bin/env python3
"""
Entity and Evidence System - Core of Advanced OSINT
Manages entities, evidence collection, and confidence scoring
"""

from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
import hashlib


class EvidenceType(Enum):
    """Types of evidence that can be collected"""
    USERNAME = "username"
    EMAIL = "email"
    PHONE = "phone"
    SOCIAL_MEDIA = "social_media"
    IMAGE = "image"
    IP = "ip"
    DOMAIN = "domain"
    BREACH = "breach"
    METADATA = "metadata"
    CORRELATION = "correlation"


class ConfidenceLevel(Enum):
    """Confidence levels for evidence"""
    VERY_LOW = (0.0, 0.3, "Very Low")
    LOW = (0.3, 0.5, "Low")
    MEDIUM = (0.5, 0.7, "Medium")
    HIGH = (0.7, 0.85, "High")
    VERY_HIGH = (0.85, 1.0, "Very High")
    
    def __init__(self, min_val, max_val, label):
        self.min_val = min_val
        self.max_val = max_val
        self.label = label
    
    @classmethod
    def from_score(cls, score: float):
        """Get confidence level from score"""
        for level in cls:
            if level.min_val <= score < level.max_val:
                return level
        return cls.VERY_HIGH if score >= 0.85 else cls.VERY_LOW


@dataclass
class Evidence:
    """
    Single piece of evidence about an entity
    This is the fundamental unit of intelligence
    """
    source: str  # Module that found this (e.g., "username_hunter", "instagram_api")
    evidence_type: EvidenceType
    signal: str  # What was found (e.g., "username_match", "avatar_similarity")
    value: Any  # The actual data
    weight: float  # How important this evidence is (0.0-1.0)
    reliability: float  # How reliable the source is (0.0-1.0)
    timestamp: datetime = field(default_factory=datetime.now)
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def score(self) -> float:
        """Calculate evidence score"""
        return self.weight * self.reliability
    
    def __repr__(self):
        return f"Evidence({self.signal}: {self.score():.2f})"


@dataclass
class Entity:
    """
    Central entity being investigated
    All evidence points to this entity
    """
    primary_identifier: str  # Main identifier (username, email, etc.)
    entity_type: str  # Type: "person", "organization", "account"
    
    # All identifiers associated with this entity
    identifiers: Dict[str, List[str]] = field(default_factory=dict)
    # username: [list of usernames]
    # email: [list of emails]
    # phone: [list of phones]
    
    # Evidence collected
    evidence: List[Evidence] = field(default_factory=list)
    
    # Attributes discovered
    attributes: Dict[str, Any] = field(default_factory=dict)
    # platforms: {platform: data}
    # images: [image data]
    # breaches: [breach data]
    
    # Correlations found
    correlations: List[Dict[str, Any]] = field(default_factory=list)
    
    # Calculated scores
    confidence_score: float = 0.0
    risk_score: float = 0.0
    
    # Metadata
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)
    
    def add_identifier(self, id_type: str, value: str):
        """Add an identifier to this entity"""
        if id_type not in self.identifiers:
            self.identifiers[id_type] = []
        if value not in self.identifiers[id_type]:
            self.identifiers[id_type].append(value)
            self.updated_at = datetime.now()
    
    def add_evidence(self, evidence: Evidence):
        """Add evidence to this entity"""
        self.evidence.append(evidence)
        self.updated_at = datetime.now()
        # Recalculate confidence after adding evidence
        self._recalculate_confidence()
    
    def add_attribute(self, key: str, value: Any):
        """Add an attribute to this entity"""
        self.attributes[key] = value
        self.updated_at = datetime.now()
    
    def add_correlation(self, correlation: Dict[str, Any]):
        """Add a correlation finding"""
        self.correlations.append(correlation)
        self.updated_at = datetime.now()
    
    def _recalculate_confidence(self):
        """Recalculate confidence score based on all evidence"""
        if not self.evidence:
            self.confidence_score = 0.0
            return
        
        # Aggregate evidence scores by type
        type_scores: Dict[EvidenceType, List[float]] = {}
        for ev in self.evidence:
            if ev.evidence_type not in type_scores:
                type_scores[ev.evidence_type] = []
            type_scores[ev.evidence_type].append(ev.score())
        
        # Calculate weighted average across types
        total_score = 0.0
        total_weight = 0.0
        
        for ev_type, scores in type_scores.items():
            # Take max score per type (avoid double-counting)
            max_score = max(scores)
            # Weight by number of independent sources
            type_weight = min(len(scores) * 0.2, 1.0)  # Cap at 1.0
            
            total_score += max_score * type_weight
            total_weight += type_weight
        
        if total_weight > 0:
            self.confidence_score = min(total_score / total_weight, 1.0)
        else:
            self.confidence_score = 0.0
    
    def get_confidence_level(self) -> ConfidenceLevel:
        """Get confidence level classification"""
        return ConfidenceLevel.from_score(self.confidence_score)
    
    def get_evidence_by_type(self, evidence_type: EvidenceType) -> List[Evidence]:
        """Get all evidence of a specific type"""
        return [ev for ev in self.evidence if ev.evidence_type == evidence_type]
    
    def get_evidence_by_source(self, source: str) -> List[Evidence]:
        """Get all evidence from a specific source"""
        return [ev for ev in self.evidence if ev.source == source]
    
    def get_top_evidence(self, limit: int = 5) -> List[Evidence]:
        """Get top N evidence by score"""
        return sorted(self.evidence, key=lambda e: e.score(), reverse=True)[:limit]
    
    def get_summary(self) -> Dict[str, Any]:
        """Get entity summary"""
        return {
            'primary_identifier': self.primary_identifier,
            'entity_type': self.entity_type,
            'confidence_score': self.confidence_score,
            'confidence_level': self.get_confidence_level().label,
            'identifiers': self.identifiers,
            'evidence_count': len(self.evidence),
            'platforms': list(self.attributes.get('platforms', {}).keys()),
            'correlations_count': len(self.correlations),
            'risk_score': self.risk_score,
        }
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert entity to dictionary"""
        return {
            'primary_identifier': self.primary_identifier,
            'entity_type': self.entity_type,
            'identifiers': self.identifiers,
            'confidence_score': self.confidence_score,
            'confidence_level': self.get_confidence_level().label,
            'risk_score': self.risk_score,
            'evidence': [
                {
                    'source': ev.source,
                    'type': ev.evidence_type.value,
                    'signal': ev.signal,
                    'score': ev.score(),
                    'timestamp': ev.timestamp.isoformat(),
                }
                for ev in self.evidence
            ],
            'attributes': self.attributes,
            'correlations': self.correlations,
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat(),
        }
    
    def __repr__(self):
        conf_level = self.get_confidence_level()
        return f"Entity({self.primary_identifier}, confidence={self.confidence_score:.2f} [{conf_level.label}], evidence={len(self.evidence)})"


class EntityManager:
    """Manages multiple entities and their relationships"""
    
    def __init__(self):
        self.entities: Dict[str, Entity] = {}
        self.entity_links: List[Dict[str, Any]] = []
    
    def create_entity(self, identifier: str, entity_type: str = "person") -> Entity:
        """Create a new entity"""
        entity = Entity(primary_identifier=identifier, entity_type=entity_type)
        self.entities[identifier] = entity
        return entity
    
    def get_entity(self, identifier: str) -> Optional[Entity]:
        """Get an entity by identifier"""
        return self.entities.get(identifier)
    
    def get_or_create_entity(self, identifier: str, entity_type: str = "person") -> Entity:
        """Get existing entity or create new one"""
        if identifier in self.entities:
            return self.entities[identifier]
        return self.create_entity(identifier, entity_type)
    
    def link_entities(self, entity1_id: str, entity2_id: str, 
                     link_type: str, confidence: float, evidence: Dict[str, Any]):
        """Link two entities together"""
        self.entity_links.append({
            'entity1': entity1_id,
            'entity2': entity2_id,
            'type': link_type,
            'confidence': confidence,
            'evidence': evidence,
            'timestamp': datetime.now(),
        })
    
    def find_related_entities(self, identifier: str) -> List[Dict[str, Any]]:
        """Find all entities related to the given one"""
        related = []
        for link in self.entity_links:
            if link['entity1'] == identifier:
                related.append({
                    'entity': link['entity2'],
                    'type': link['type'],
                    'confidence': link['confidence'],
                })
            elif link['entity2'] == identifier:
                related.append({
                    'entity': link['entity1'],
                    'type': link['type'],
                    'confidence': link['confidence'],
                })
        return related
    
    def get_all_entities(self) -> List[Entity]:
        """Get all entities"""
        return list(self.entities.values())
    
    def merge_entities(self, target_id: str, source_id: str):
        """Merge source entity into target entity"""
        target = self.get_entity(target_id)
        source = self.get_entity(source_id)
        
        if not target or not source:
            return
        
        # Merge identifiers
        for id_type, values in source.identifiers.items():
            for value in values:
                target.add_identifier(id_type, value)
        
        # Merge evidence
        for evidence in source.evidence:
            target.add_evidence(evidence)
        
        # Merge attributes
        for key, value in source.attributes.items():
            if key not in target.attributes:
                target.add_attribute(key, value)
        
        # Merge correlations
        for correlation in source.correlations:
            target.add_correlation(correlation)
        
        # Remove source entity
        del self.entities[source_id]
    
    def export_graph(self) -> Dict[str, Any]:
        """Export entity graph for visualization"""
        nodes = []
        edges = []
        
        for entity in self.entities.values():
            nodes.append({
                'id': entity.primary_identifier,
                'type': entity.entity_type,
                'confidence': entity.confidence_score,
                'label': entity.primary_identifier,
            })
        
        for link in self.entity_links:
            edges.append({
                'source': link['entity1'],
                'target': link['entity2'],
                'type': link['type'],
                'confidence': link['confidence'],
            })
        
        return {
            'nodes': nodes,
            'edges': edges,
        }
