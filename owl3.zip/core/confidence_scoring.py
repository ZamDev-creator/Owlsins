#!/usr/bin/env python3
"""
Confidence Scoring System
Calculates confidence scores based on evidence quality and quantity
"""

from typing import Dict, List, Any
from dataclasses import dataclass
from core.entity import Evidence, EvidenceType


@dataclass
class ScoringWeights:
    """Configurable weights for different types of evidence"""
    
    # Evidence type weights (how important each type is)
    USERNAME_FOUND = 0.20
    USERNAME_WITH_PROFILE = 0.35
    USERNAME_WITH_AVATAR = 0.15
    USERNAME_WITH_BIO = 0.10
    USERNAME_VERIFIED = 0.20
    
    EMAIL_FOUND = 0.25
    EMAIL_VALIDATED = 0.40
    EMAIL_IN_BREACH = 0.20
    EMAIL_DOMAIN_MATCH = 0.15
    
    SOCIAL_PROFILE_FOUND = 0.30
    SOCIAL_PROFILE_ACTIVE = 0.20
    SOCIAL_PROFILE_VERIFIED = 0.30
    SOCIAL_PROFILE_COMPLETE = 0.20
    
    IMAGE_HASH_MATCH = 0.40
    IMAGE_EXIF_MATCH = 0.25
    IMAGE_FACE_MATCH = 0.35
    
    CORRELATION_WEAK = 0.15
    CORRELATION_MEDIUM = 0.30
    CORRELATION_STRONG = 0.50
    
    # Source reliability (how much to trust each source)
    API_OFFICIAL = 0.95
    API_THIRD_PARTY = 0.80
    WEB_SCRAPE_VERIFIED = 0.70
    WEB_SCRAPE_HEURISTIC = 0.60
    MANUAL_CONFIRMED = 1.00
    INFERENCE = 0.40


class ConfidenceScorer:
    """Calculates confidence scores for OSINT findings"""
    
    def __init__(self, weights: ScoringWeights = None):
        self.weights = weights or ScoringWeights()
    
    def score_username_finding(self, 
                               found: bool,
                               has_profile: bool = False,
                               has_avatar: bool = False,
                               has_bio: bool = False,
                               is_verified: bool = False,
                               reliability: float = 0.8) -> float:
        """Score a username finding"""
        if not found:
            return 0.0
        
        score = self.weights.USERNAME_FOUND
        
        if has_profile:
            score += self.weights.USERNAME_WITH_PROFILE
        if has_avatar:
            score += self.weights.USERNAME_WITH_AVATAR
        if has_bio:
            score += self.weights.USERNAME_WITH_BIO
        if is_verified:
            score += self.weights.USERNAME_VERIFIED
        
        return min(score * reliability, 1.0)
    
    def score_email_finding(self,
                           found: bool,
                           is_valid: bool = False,
                           in_breach: bool = False,
                           domain_matches: bool = False,
                           reliability: float = 0.8) -> float:
        """Score an email finding"""
        if not found:
            return 0.0
        
        score = self.weights.EMAIL_FOUND
        
        if is_valid:
            score += self.weights.EMAIL_VALIDATED
        if in_breach:
            score += self.weights.EMAIL_IN_BREACH
        if domain_matches:
            score += self.weights.EMAIL_DOMAIN_MATCH
        
        return min(score * reliability, 1.0)
    
    def score_social_profile(self,
                            found: bool,
                            is_active: bool = False,
                            is_verified: bool = False,
                            is_complete: bool = False,
                            reliability: float = 0.8) -> float:
        """Score a social media profile finding"""
        if not found:
            return 0.0
        
        score = self.weights.SOCIAL_PROFILE_FOUND
        
        if is_active:
            score += self.weights.SOCIAL_PROFILE_ACTIVE
        if is_verified:
            score += self.weights.SOCIAL_PROFILE_VERIFIED
        if is_complete:
            score += self.weights.SOCIAL_PROFILE_COMPLETE
        
        return min(score * reliability, 1.0)
    
    def score_image_correlation(self,
                               hash_match: bool = False,
                               exif_match: bool = False,
                               face_match: bool = False,
                               reliability: float = 0.8) -> float:
        """Score an image correlation"""
        score = 0.0
        
        if hash_match:
            score += self.weights.IMAGE_HASH_MATCH
        if exif_match:
            score += self.weights.IMAGE_EXIF_MATCH
        if face_match:
            score += self.weights.IMAGE_FACE_MATCH
        
        return min(score * reliability, 1.0)
    
    def score_correlation(self, 
                         correlation_type: str,
                         reliability: float = 0.8) -> float:
        """Score a correlation between entities"""
        weights = {
            'weak': self.weights.CORRELATION_WEAK,
            'medium': self.weights.CORRELATION_MEDIUM,
            'strong': self.weights.CORRELATION_STRONG,
        }
        
        score = weights.get(correlation_type, 0.0)
        return score * reliability
    
    def get_source_reliability(self, source_type: str) -> float:
        """Get reliability score for a source type"""
        reliability_map = {
            'api_official': self.weights.API_OFFICIAL,
            'api_third_party': self.weights.API_THIRD_PARTY,
            'web_scrape_verified': self.weights.WEB_SCRAPE_VERIFIED,
            'web_scrape_heuristic': self.weights.WEB_SCRAPE_HEURISTIC,
            'manual': self.weights.MANUAL_CONFIRMED,
            'inference': self.weights.INFERENCE,
        }
        
        return reliability_map.get(source_type, 0.5)
    
    def aggregate_evidence_scores(self, evidence_list: List[Evidence]) -> Dict[str, Any]:
        """
        Aggregate multiple evidence scores
        Returns overall score and breakdown by type
        """
        if not evidence_list:
            return {
                'overall_score': 0.0,
                'evidence_count': 0,
                'by_type': {},
                'top_evidence': [],
            }
        
        # Group by type
        by_type: Dict[EvidenceType, List[float]] = {}
        for ev in evidence_list:
            if ev.evidence_type not in by_type:
                by_type[ev.evidence_type] = []
            by_type[ev.evidence_type].append(ev.score())
        
        # Calculate type scores
        type_scores = {}
        for ev_type, scores in by_type.items():
            type_scores[ev_type.value] = {
                'max_score': max(scores),
                'avg_score': sum(scores) / len(scores),
                'count': len(scores),
            }
        
        # Calculate overall score
        # Use diminishing returns for multiple evidence of same type
        total_score = 0.0
        for ev_type, scores in by_type.items():
            # Take best score for this type
            best_score = max(scores)
            # Bonus for corroboration (multiple sources)
            corroboration_bonus = min(len(scores) * 0.05, 0.15)
            type_contribution = min(best_score + corroboration_bonus, 1.0)
            total_score += type_contribution
        
        # Normalize by number of evidence types (max 5 types = 1.0)
        num_types = len(by_type)
        overall_score = min(total_score / max(num_types, 1), 1.0)
        
        # Get top evidence
        top_evidence = sorted(evidence_list, key=lambda e: e.score(), reverse=True)[:5]
        
        return {
            'overall_score': overall_score,
            'evidence_count': len(evidence_list),
            'evidence_types': num_types,
            'by_type': type_scores,
            'top_evidence': [
                {
                    'source': ev.source,
                    'signal': ev.signal,
                    'score': ev.score(),
                }
                for ev in top_evidence
            ],
        }
    
    def calculate_risk_score(self, entity_attributes: Dict[str, Any]) -> float:
        """
        Calculate risk score based on entity attributes
        Higher score = higher risk
        """
        risk_score = 0.0
        
        # Check for breach involvement
        breaches = entity_attributes.get('breaches', [])
        if breaches:
            # More recent breaches = higher risk
            risk_score += min(len(breaches) * 0.15, 0.50)
        
        # Check for suspicious patterns
        if entity_attributes.get('suspicious_activity'):
            risk_score += 0.20
        
        # Check for exposed personal info
        exposed_fields = entity_attributes.get('exposed_fields', [])
        if exposed_fields:
            risk_score += min(len(exposed_fields) * 0.05, 0.20)
        
        # Check for darkweb presence
        if entity_attributes.get('darkweb_mentions'):
            risk_score += 0.30
        
        return min(risk_score, 1.0)
    
    def explain_confidence(self, evidence_list: List[Evidence]) -> List[str]:
        """
        Generate human-readable explanation of confidence score
        """
        explanations = []
        
        # Aggregate scores
        aggregated = self.aggregate_evidence_scores(evidence_list)
        overall = aggregated['overall_score']
        
        # Overall assessment
        if overall >= 0.85:
            explanations.append("🟢 Very High Confidence - Strong evidence from multiple sources")
        elif overall >= 0.70:
            explanations.append("🟡 High Confidence - Good evidence with some corroboration")
        elif overall >= 0.50:
            explanations.append("🟠 Medium Confidence - Limited evidence or single source")
        elif overall >= 0.30:
            explanations.append("🔴 Low Confidence - Weak or unverified evidence")
        else:
            explanations.append("⚫ Very Low Confidence - Minimal or unreliable evidence")
        
        # Explain by evidence type
        by_type = aggregated['by_type']
        for ev_type, scores in by_type.items():
            count = scores['count']
            max_score = scores['max_score']
            explanations.append(
                f"  • {ev_type}: {count} source(s), strength {max_score:.2f}"
            )
        
        # Top contributing evidence
        if aggregated['top_evidence']:
            explanations.append("\nTop Evidence:")
            for ev in aggregated['top_evidence'][:3]:
                explanations.append(
                    f"  • {ev['signal']} from {ev['source']} (score: {ev['score']:.2f})"
                )
        
        return explanations
