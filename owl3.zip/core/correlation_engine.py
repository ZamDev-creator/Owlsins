#!/usr/bin/env python3
"""
Correlation Engine - The Brain of Advanced OSINT
Connects evidence across modules to build intelligence
"""

from typing import Dict, List, Any, Tuple, Optional
from dataclasses import dataclass
import hashlib
from datetime import datetime
from core.entity import Entity, Evidence, EvidenceType, EntityManager
from core.confidence_scoring import ConfidenceScorer


@dataclass
class Correlation:
    """Represents a correlation between two pieces of data"""
    type: str  # 'image_hash', 'email_domain', 'username_pattern', etc.
    entity1: str
    entity2: str
    strength: float  # 0.0-1.0
    evidence: Dict[str, Any]
    timestamp: datetime


class CorrelationEngine:
    """
    Core intelligence engine that finds connections between data points
    This is what makes OSINT "advanced" instead of just "data collection"
    """
    
    def __init__(self, entity_manager: EntityManager, scorer: ConfidenceScorer):
        self.entity_manager = entity_manager
        self.scorer = scorer
        self.correlations: List[Correlation] = []
    
    def analyze_entity(self, entity: Entity) -> List[Dict[str, Any]]:
        """
        MAIN ANALYSIS METHOD - Analyze entity and find all correlations
        This is the master method that ties everything together
        """
        correlations = []
        
        # 1. Image hash correlations
        image_corr = self.correlate_image_hashes(entity)
        if image_corr:
            correlations.extend(image_corr)
        
        # 2. Username pattern correlations
        username_corr = self.correlate_username_patterns(entity)
        if username_corr:
            correlations.extend(username_corr)
        
        # 3. Email domain correlations
        email_corr = self.correlate_email_domains(entity)
        if email_corr:
            correlations.extend(email_corr)
        
        # 4. Temporal pattern correlations (activity times)
        temporal_corr = self.correlate_temporal_patterns(entity)
        if temporal_corr:
            correlations.extend(temporal_corr)
        
        # 5. Geographic correlations
        geo_corr = self.correlate_geographic_data(entity)
        if geo_corr:
            correlations.extend(geo_corr)
        
        # 6. Cross-platform consistency check
        consistency = self.check_cross_platform_consistency(entity)
        if consistency:
            correlations.append(consistency)
        
        # 7. Behavioral pattern analysis
        behavioral = self.analyze_behavioral_patterns(entity)
        if behavioral:
            correlations.append(behavioral)
        
        return correlations
    
    # ===== IMAGE CORRELATIONS =====
    
    def correlate_image_hashes(self, entity: Entity) -> List[Dict[str, Any]]:
        """
        Find images with matching hashes across platforms
        This is STRONG evidence of same person
        """
        correlations = []
        
        # Get all images from entity
        platforms = entity.attributes.get('platforms', {})
        image_hashes = {}
        
        for platform, data in platforms.items():
            if 'avatar' in data or 'profile_pic' in data:
                image_url = data.get('avatar') or data.get('profile_pic')
                if image_url:
                    # In real impl, would fetch and hash the image
                    # For now, use URL as proxy
                    img_hash = hashlib.md5(image_url.encode()).hexdigest()
                    if img_hash not in image_hashes:
                        image_hashes[img_hash] = []
                    image_hashes[img_hash].append(platform)
        
        # Find matches
        for img_hash, platforms_list in image_hashes.items():
            if len(platforms_list) > 1:
                correlation = {
                    'type': 'image_hash_match',
                    'platforms': platforms_list,
                    'strength': 0.85,  # Very strong signal
                    'evidence': f'Same avatar image across {", ".join(platforms_list)}',
                }
                correlations.append(correlation)
                
                # Add evidence to entity
                evidence = Evidence(
                    source='correlation_engine',
                    evidence_type=EvidenceType.CORRELATION,
                    signal='avatar_match_cross_platform',
                    value=platforms_list,
                    weight=0.40,
                    reliability=0.95,
                    metadata={'platforms': platforms_list, 'hash': img_hash}
                )
                entity.add_evidence(evidence)
        
        return correlations
    
    # ===== USERNAME CORRELATIONS =====
    
    def correlate_username_patterns(self, entity: Entity) -> List[Dict[str, Any]]:
        """
        Find patterns in usernames across platforms
        Similar patterns = likely same person
        """
        correlations = []
        
        usernames = entity.identifiers.get('username', [])
        if len(usernames) < 2:
            return correlations
        
        # Check for common patterns
        # Example: "john_doe", "johndoe123", "john.doe" are related
        
        # Simple similarity: shared base (before numbers/special chars)
        bases = {}
        for username in usernames:
            # Strip numbers and special chars
            import re
            base = re.sub(r'[0-9_\-\.]', '', username.lower())
            if base:
                if base not in bases:
                    bases[base] = []
                bases[base].append(username)
        
        # Find groups with same base
        for base, username_group in bases.items():
            if len(username_group) > 1:
                correlation = {
                    'type': 'username_pattern',
                    'pattern': f'base: {base}',
                    'usernames': username_group,
                    'strength': 0.70,
                    'evidence': f'Username pattern match: {", ".join(username_group)}',
                }
                correlations.append(correlation)
                
                # Add evidence
                evidence = Evidence(
                    source='correlation_engine',
                    evidence_type=EvidenceType.CORRELATION,
                    signal='username_pattern_match',
                    value=username_group,
                    weight=0.30,
                    reliability=0.70,
                    metadata={'base': base, 'usernames': username_group}
                )
                entity.add_evidence(evidence)
        
        return correlations
    
    # ===== EMAIL CORRELATIONS =====
    
    def correlate_email_domains(self, entity: Entity) -> List[Dict[str, Any]]:
        """
        Correlate emails with same domain
        Same domain = possibly related or same org
        """
        correlations = []
        
        emails = entity.identifiers.get('email', [])
        if len(emails) < 2:
            return correlations
        
        # Group by domain
        domains = {}
        for email in emails:
            if '@' in email:
                domain = email.split('@')[1].lower()
                if domain not in domains:
                    domains[domain] = []
                domains[domain].append(email)
        
        # Find groups
        for domain, email_group in domains.items():
            if len(email_group) > 1:
                strength = 0.50  # Medium strength - could be org-wide
                correlation = {
                    'type': 'email_domain_match',
                    'domain': domain,
                    'emails': email_group,
                    'strength': strength,
                    'evidence': f'Multiple emails from same domain: {domain}',
                }
                correlations.append(correlation)
                
                # Add evidence
                evidence = Evidence(
                    source='correlation_engine',
                    evidence_type=EvidenceType.CORRELATION,
                    signal='email_domain_match',
                    value=email_group,
                    weight=0.25,
                    reliability=0.60,
                    metadata={'domain': domain, 'emails': email_group}
                )
                entity.add_evidence(evidence)
        
        return correlations
    
    # ===== TEMPORAL CORRELATIONS =====
    
    def correlate_temporal_patterns(self, entity: Entity) -> List[Dict[str, Any]]:
        """
        Find temporal patterns in activity
        Similar posting times = likely same person
        """
        correlations = []
        
        # Get activity timestamps from evidence
        timestamps = []
        for evidence in entity.evidence:
            if evidence.timestamp:
                timestamps.append({
                    'time': evidence.timestamp,
                    'source': evidence.source,
                })
        
        if len(timestamps) < 3:
            return correlations
        
        # Analyze activity patterns (simplified)
        # In real impl, would do timezone analysis, frequency patterns, etc.
        
        hours = [t['time'].hour for t in timestamps]
        if hours:
            avg_hour = sum(hours) / len(hours)
            correlation = {
                'type': 'temporal_pattern',
                'pattern': f'avg_activity_hour: {avg_hour:.1f}',
                'strength': 0.40,
                'evidence': f'Consistent activity timing across {len(timestamps)} events',
            }
            correlations.append(correlation)
        
        return correlations
    
    # ===== GEOGRAPHIC CORRELATIONS =====
    
    def correlate_geographic_data(self, entity: Entity) -> List[Dict[str, Any]]:
        """
        Find geographic patterns
        Same locations = strong correlation
        """
        correlations = []
        
        # Get location data from evidence
        locations = []
        for evidence in entity.evidence:
            if 'location' in evidence.metadata:
                loc = evidence.metadata['location']
                locations.append({
                    'location': loc,
                    'source': evidence.source,
                })
        
        if len(locations) < 2:
            return correlations
        
        # Find location matches
        location_map = {}
        for loc_data in locations:
            loc = str(loc_data['location'])
            if loc not in location_map:
                location_map[loc] = []
            location_map[loc].append(loc_data['source'])
        
        for location, sources in location_map.items():
            if len(sources) > 1:
                correlation = {
                    'type': 'geographic_match',
                    'location': location,
                    'sources': sources,
                    'strength': 0.75,
                    'evidence': f'Same location across {len(sources)} sources: {location}',
                }
                correlations.append(correlation)
        
        return correlations
    
    # ===== CONSISTENCY CHECKS =====
    
    def check_cross_platform_consistency(self, entity: Entity) -> Optional[Dict[str, Any]]:
        """
        Check if data is consistent across platforms
        Inconsistencies = red flags (different people or impersonation)
        """
        platforms = entity.attributes.get('platforms', {})
        if len(platforms) < 2:
            return None
        
        # Check name consistency
        names = []
        for platform, data in platforms.items():
            profile_data = data.get('profile_data', {})
            if 'name' in profile_data:
                names.append(profile_data['name'])
        
        if names:
            unique_names = set(names)
            if len(unique_names) == 1:
                consistency = {
                    'type': 'consistency_check',
                    'aspect': 'name',
                    'status': 'consistent',
                    'value': list(unique_names)[0],
                    'strength': 0.80,
                    'evidence': 'Name consistent across all platforms',
                }
            else:
                consistency = {
                    'type': 'consistency_check',
                    'aspect': 'name',
                    'status': 'inconsistent',
                    'values': list(unique_names),
                    'strength': -0.30,  # Negative = red flag
                    'evidence': f'Name inconsistency: {", ".join(unique_names)}',
                }
            return consistency
        
        return None
    
    # ===== BEHAVIORAL ANALYSIS =====
    
    def analyze_behavioral_patterns(self, entity: Entity) -> Optional[Dict[str, Any]]:
        """
        Analyze behavioral patterns from collected data
        Activity levels, engagement style, content patterns
        """
        platforms = entity.attributes.get('platforms', {})
        if not platforms:
            return None
        
        # Count signals of activity
        activity_signals = []
        for platform, data in platforms.items():
            signals = data.get('activity_signals', {})
            
            # Check various activity indicators
            if signals.get('has_avatar'):
                activity_signals.append('has_avatar')
            if signals.get('has_bio'):
                activity_signals.append('has_bio')
            if signals.get('follower_count', 0) > 0:
                activity_signals.append('has_followers')
            if signals.get('is_verified'):
                activity_signals.append('verified')
        
        if activity_signals:
            activity_level = len(activity_signals) / (len(platforms) * 3)  # Normalized
            
            pattern = {
                'type': 'behavioral_pattern',
                'activity_level': activity_level,
                'signals': activity_signals,
                'strength': min(activity_level * 0.7, 0.7),  # Cap at 0.7
                'evidence': f'Activity indicators across {len(platforms)} platforms',
            }
            return pattern
        
        return None
    
    # ===== CROSS-ENTITY CORRELATION =====
    
    def cross_entity_correlation(self, entity1: Entity, entity2: Entity) -> Dict[str, Any]:
        """
        Find correlations between two different entities
        Are they the same person? Related? Connected?
        """
        correlations = []
        
        # Check for shared identifiers
        for id_type in ['email', 'username', 'phone']:
            ids1 = set(entity1.identifiers.get(id_type, []))
            ids2 = set(entity2.identifiers.get(id_type, []))
            shared = ids1 & ids2
            
            if shared:
                correlations.append({
                    'type': f'shared_{id_type}',
                    'values': list(shared),
                    'strength': 0.95,  # Very strong - same identifiers
                    'evidence': f'Shared {id_type}: {", ".join(shared)}',
                })
        
        # Check for similar patterns
        # (Would implement more sophisticated checks here)
        
        if correlations:
            # High confidence these are related
            confidence = max(c['strength'] for c in correlations)
            relationship = 'same_entity' if confidence > 0.90 else 'related_entities'
        else:
            confidence = 0.0
            relationship = 'unrelated'
        
        return {
            'entity1': entity1.primary_identifier,
            'entity2': entity2.primary_identifier,
            'relationship': relationship,
            'confidence': confidence,
            'correlations': correlations,
        }
    
    def suggest_next_search(self, entity: Entity) -> List[Dict[str, str]]:
        """
        Based on current evidence, suggest what to search next
        This is intelligence-driven investigation
        """
        suggestions = []
        
        # If we have email but no social media
        if entity.identifiers.get('email') and not entity.attributes.get('platforms'):
            suggestions.append({
                'type': 'search',
                'target': 'social_media',
                'reason': 'Email found but no social media profiles yet',
                'priority': 'high',
            })
        
        # If we have username on one platform, try others
        platforms_found = list(entity.attributes.get('platforms', {}).keys())
        if platforms_found:
            username = entity.primary_identifier
            suggestions.append({
                'type': 'expand_search',
                'target': 'other_platforms',
                'username': username,
                'reason': f'Found on {", ".join(platforms_found)}, check other platforms',
                'priority': 'medium',
            })
        
        # If we have images without metadata
        images = entity.attributes.get('images', [])
        images_without_exif = [img for img in images if not img.get('exif')]
        if images_without_exif:
            suggestions.append({
                'type': 'analyze',
                'target': 'image_metadata',
                'count': len(images_without_exif),
                'reason': 'Images without EXIF analysis',
                'priority': 'low',
            })
        
        return suggestions
