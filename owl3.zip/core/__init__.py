#!/usr/bin/env python3
"""
Core Intelligence Module
Advanced OSINT entity-centric system
"""

from .entity import Entity, Evidence, EvidenceType, ConfidenceLevel, EntityManager
from .confidence_scoring import ConfidenceScorer, ScoringWeights
from .correlation_engine import CorrelationEngine, Correlation

__all__ = [
    'Entity',
    'Evidence',
    'EvidenceType',
    'ConfidenceLevel',
    'EntityManager',
    'ConfidenceScorer',
    'ScoringWeights',
    'CorrelationEngine',
    'Correlation',
]
