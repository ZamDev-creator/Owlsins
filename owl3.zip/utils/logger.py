"""
Logging utility for OSINT Suite
Provides colored console output and file logging
"""

import logging
import sys
from datetime import datetime
from pathlib import Path
from config import LOGS_DIR, LOG_LEVEL, LOG_FORMAT, LOG_DATE_FORMAT


class ColoredFormatter(logging.Formatter):
    """Custom formatter with colors for terminal output"""
    
    COLORS = {
        'DEBUG': '\033[36m',     # Cyan
        'INFO': '\033[32m',      # Green
        'WARNING': '\033[33m',   # Yellow
        'ERROR': '\033[31m',     # Red
        'CRITICAL': '\033[35m',  # Magenta
        'RESET': '\033[0m'       # Reset
    }
    
    def format(self, record):
        log_color = self.COLORS.get(record.levelname, self.COLORS['RESET'])
        record.levelname = f"{log_color}{record.levelname}{self.COLORS['RESET']}"
        return super().format(record)


def setup_logger(name, level=None):
    """
    Setup logger with file and console handlers
    
    Args:
        name: Logger name (usually __name__)
        level: Logging level (defaults to config.LOG_LEVEL)
    
    Returns:
        logging.Logger: Configured logger instance
    """
    
    if level is None:
        level = getattr(logging, LOG_LEVEL)
    
    logger = logging.getLogger(name)
    logger.setLevel(level)
    
    # Avoid duplicate handlers
    if logger.handlers:
        return logger
    
    # File handler - logs everything to file
    log_file = LOGS_DIR / f"{datetime.now().strftime('%Y%m%d')}_osint.log"
    file_handler = logging.FileHandler(log_file, encoding='utf-8')
    file_handler.setLevel(logging.DEBUG)
    file_formatter = logging.Formatter(LOG_FORMAT, datefmt=LOG_DATE_FORMAT)
    file_handler.setFormatter(file_formatter)
    
    # Console handler - colored output
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(level)
    console_formatter = ColoredFormatter(
        '%(levelname)s - %(message)s'
    )
    console_handler.setFormatter(console_formatter)
    
    logger.addHandler(file_handler)
    logger.addHandler(console_handler)
    
    return logger
