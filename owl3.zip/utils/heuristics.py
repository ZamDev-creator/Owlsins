#!/usr/bin/env python3
"""
Heuristic Detection System
Goes beyond status codes to intelligently detect profiles
"""

import re
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass, field


@dataclass
class DetectionResult:
    """Result of heuristic detection"""
    exists: bool
    confidence: float
    signals: List[str]
    method: str
    completeness: float = 0.0  # NEW: Profile completeness score (0.0-1.0)
    metadata: Dict = field(default_factory=dict)


class PlatformHeuristics:
    """Heuristic detection patterns for various platforms"""
    
    # Platform-specific patterns that indicate a valid profile
    PLATFORM_PATTERNS = {
        'github': {
            'positive': [
                r'<meta property="og:type" content="profile"',
                r'class="[^"]*user-profile',
                r'data-hovercard-type="user"',
                r'<span class="p-nickname',
                r'vcard-username',
            ],
            'negative': [
                r'Not Found',
                r'404',
                r'This is not the web page you are looking for',
                r'Page not found',
            ],
            'profile_indicators': [
                r'followers',
                r'repositories',
                r'contribution activity',
                r'pinned repositories',
            ],
        },
        'instagram': {
            'positive': [
                r'"username":"[^"]+',
                r'"full_name":"[^"]*',
                r'"edge_followed_by"',
                r'"profile_pic_url"',
                r'og:description',
            ],
            'negative': [
                r'Sorry, this page isn',
                r'The link you followed may be broken',
                r'Page Not Found',
                r'User not found',
            ],
            'profile_indicators': [
                r'followers',
                r'following',
                r'posts',
                r'profile pic',
            ],
        },
        'twitter': {
            'positive': [
                r'ProfileHeaderCard',
                r'ProfileNav',
                r'data-user-id=',
                r'class="ProfileHeaderCard',
                r'twitter:creator',
            ],
            'negative': [
                r'Account suspended',
                r'This account doesn',
                r'Sorry, that page doesn',
                r'suspended',
            ],
            'profile_indicators': [
                r'Tweets',
                r'Following',
                r'Followers',
                r'Joined',
            ],
        },
        'tiktok': {
            'positive': [
                r'"uniqueId":"[^"]+',
                r'"nickname":"[^"]+',
                r'"followerCount":\d+',
                r'__UNIVERSAL_DATA_FOR_REHYDRATION__',
                r'tiktok:app:url',
            ],
            'negative': [
                r'Couldn\'t find this account',
                r'This account is private',
                r'user not found',
                r'Account not found',
            ],
            'profile_indicators': [
                r'Followers',
                r'Following',
                r'Likes',
                r'Videos',
            ],
        },
        'linkedin': {
            'positive': [
                r'<meta property="og:type" content="profile"',
                r'profile-view',
                r'"name":"[^"]+',
                r'pv-top-card',
            ],
            'negative': [
                r'Page not found',
                r'404',
                r'Member not found',
            ],
            'profile_indicators': [
                r'connections',
                r'Experience',
                r'Education',
                r'Skills',
            ],
        },
        'youtube': {
            'positive': [
                r'"channelId":"[^"]+',
                r'"subscriberCount":"[^"]+',
                r'channel-header',
                r'ytInitialData',
            ],
            'negative': [
                r'This channel does not exist',
                r'404',
                r'not found',
            ],
            'profile_indicators': [
                r'subscribers',
                r'videos',
                r'views',
                r'description',
            ],
        },
        'reddit': {
            'positive': [
                r'"author":"[^"]+',
                r'user-profile',
                r'profile-page',
                r'karma',
            ],
            'negative': [
                r'page not found',
                r'404',
                r'nobody here but us chickens',
            ],
            'profile_indicators': [
                r'karma',
                r'post karma',
                r'comment karma',
                r'cake day',
            ],
        },
        'medium': {
            'positive': [
                r'"username":"@[^"]+',
                r'"name":"[^"]+',
                r'user-profile',
                r'profileHeaderWrapper',
            ],
            'negative': [
                r'Page not found',
                r'404',
                r'does not exist',
            ],
            'profile_indicators': [
                r'followers',
                r'following',
                r'stories',
            ],
        },
        'pinterest': {
            'positive': [
                r'"username":"[^"]+',
                r'"fullName":"[^"]+',
                r'profilePage',
                r'userImage',
            ],
            'negative': [
                r'Page not found',
                r'404',
                r'Sorry',
            ],
            'profile_indicators': [
                r'followers',
                r'following',
                r'pins',
                r'boards',
            ],
        },
        'twitch': {
            'positive': [
                r'"name":"[^"]+',
                r'"displayName":"[^"]+',
                r'channel-header',
                r'tw-channel',
            ],
            'negative': [
                r'Sorry',
                r'404',
                r'not found',
            ],
            'profile_indicators': [
                r'followers',
                r'views',
                r'videos',
            ],
        },
    }
    
    def detect_profile(self, platform: str, html: str, status_code: int) -> DetectionResult:
        """
        Use heuristics to detect if profile exists
        Goes beyond simple status code checking
        """
        platform = platform.lower()
        
        if platform not in self.PLATFORM_PATTERNS:
            # Fallback to simple status code check with better defaults
            completeness = 0.3 if status_code == 200 else 0.0
            return DetectionResult(
                exists=(status_code == 200),
                confidence=0.3 if status_code == 200 else 0.1,
                signals=['status_code_only'],
                method='fallback',
                completeness=completeness,
            )
        
        patterns = self.PLATFORM_PATTERNS[platform]
        signals = []
        confidence = 0.0
        
        # Check status code first (but don't rely on it solely)
        if status_code == 200:
            signals.append('status_200')
            confidence += 0.2
        elif status_code == 404:
            signals.append('status_404')
            return DetectionResult(
                exists=False,
                confidence=0.95,
                signals=signals,
                method='status_code',
                completeness=0.0,
            )
        
        # Check negative patterns (profile NOT found indicators)
        negative_matches = 0
        for pattern in patterns['negative']:
            if re.search(pattern, html, re.IGNORECASE):
                negative_matches += 1
                signals.append(f'negative_match: {pattern[:30]}')
        
        if negative_matches > 0:
            return DetectionResult(
                exists=False,
                confidence=0.90,
                signals=signals,
                method='negative_pattern',
                completeness=0.0,
            )
        
        # Check positive patterns (profile EXISTS indicators)
        positive_matches = 0
        for pattern in patterns['positive']:
            if re.search(pattern, html, re.IGNORECASE):
                positive_matches += 1
                signals.append(f'positive_match: {pattern[:30]}')
                confidence += 0.25
        
        # Check profile indicators (content that shows it's a real profile)
        indicator_matches = 0
        for pattern in patterns['profile_indicators']:
            if re.search(pattern, html, re.IGNORECASE):
                indicator_matches += 1
                signals.append(f'indicator: {pattern}')
                confidence += 0.15
        
        # Calculate completeness based on indicators found
        total_indicators = len(patterns['profile_indicators'])
        completeness = min(indicator_matches / total_indicators, 1.0) if total_indicators > 0 else 0.3
        
        # Decision logic
        if positive_matches >= 2 or (positive_matches >= 1 and indicator_matches >= 1):
            exists = True
            confidence = min(confidence, 0.95)
            method = 'heuristic_positive'
        elif positive_matches == 1:
            exists = True
            confidence = min(confidence, 0.70)
            method = 'heuristic_weak'
        else:
            exists = False
            confidence = 0.40
            method = 'heuristic_negative'
            completeness = 0.0
        
        return DetectionResult(
            exists=exists,
            confidence=min(confidence, 1.0),
            signals=signals,
            method=method,
            completeness=completeness,
        )
    
    def extract_profile_data(self, platform: str, html: str) -> Dict[str, any]:
        """
        Extract profile data using heuristics
        """
        platform = platform.lower()
        data = {}
        
        # Common patterns across platforms
        patterns = {
            'followers': [
                r'(\d+(?:,\d+)*(?:\.\d+)?[KMB]?)\s*[Ff]ollowers',
                r'"followerCount":\s*(\d+)',
                r'"followers":\s*(\d+)',
            ],
            'following': [
                r'(\d+(?:,\d+)*(?:\.\d+)?[KMB]?)\s*[Ff]ollowing',
                r'"followingCount":\s*(\d+)',
                r'"following":\s*(\d+)',
            ],
            'posts': [
                r'(\d+(?:,\d+)*(?:\.\d+)?[KMB]?)\s*[Pp]osts',
                r'"postCount":\s*(\d+)',
                r'"videoCount":\s*(\d+)',
            ],
            'bio': [
                r'"biography":\s*"([^"]+)',
                r'"description":\s*"([^"]+)',
                r'"signature":\s*"([^"]+)',
            ],
            'name': [
                r'"full_name":\s*"([^"]+)',
                r'"nickname":\s*"([^"]+)',
                r'"name":\s*"([^"]+)',
            ],
            'verified': [
                r'"is_verified":\s*(true|false)',
                r'"verified":\s*(true|false)',
            ],
        }
        
        for field, field_patterns in patterns.items():
            for pattern in field_patterns:
                match = re.search(pattern, html, re.IGNORECASE)
                if match:
                    data[field] = match.group(1)
                    break
        
        return data
    
    def check_activity_signals(self, html: str) -> Dict[str, bool]:
        """
        Check for signals that indicate an active vs inactive profile
        """
        signals = {
            'has_recent_posts': False,
            'has_followers': False,
            'has_bio': False,
            'has_avatar': False,
            'is_verified': False,
            'is_private': False,
        }
        
        # Recent activity patterns
        recent_patterns = [
            r'\d+[hdwm]\s*ago',  # "2h ago", "3d ago", etc.
            r'posted.*today',
            r'updated.*recently',
        ]
        
        for pattern in recent_patterns:
            if re.search(pattern, html, re.IGNORECASE):
                signals['has_recent_posts'] = True
                break
        
        # Followers indicator
        if re.search(r'followers?["\s]*[:>]\s*\d', html, re.IGNORECASE):
            signals['has_followers'] = True
        
        # Bio indicator
        if re.search(r'bio.*\w{10,}', html, re.IGNORECASE):
            signals['has_bio'] = True
        
        # Avatar indicator
        avatar_patterns = [
            r'profile[-_]pic',
            r'avatar',
            r'user[-_]image',
        ]
        for pattern in avatar_patterns:
            if re.search(pattern, html, re.IGNORECASE):
                signals['has_avatar'] = True
                break
        
        # Verification badge
        if re.search(r'verified|badge', html, re.IGNORECASE):
            signals['is_verified'] = True
        
        # Private account
        if re.search(r'private|locked', html, re.IGNORECASE):
            signals['is_private'] = True
        
        return signals


class ContentAnalyzer:
    """Analyze HTML content for additional data extraction"""
    
    def extract_emails(self, text: str) -> List[str]:
        """Extract email addresses from text"""
        email_pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
        emails = re.findall(email_pattern, text)
        
        # Filter out common false positives
        exclude_domains = ['example.com', 'test.com', 'example.org', 'sentry.io']
        emails = [e for e in emails if not any(d in e for d in exclude_domains)]
        
        return list(set(emails))
    
    def extract_usernames(self, text: str) -> List[str]:
        """Extract potential usernames from text"""
        username_patterns = [
            r'@([a-zA-Z0-9_]{3,30})',  # @username format
            r'/users?/([a-zA-Z0-9_\-]{3,30})',  # /user/username
            r'profile/([a-zA-Z0-9_\-]{3,30})',  # profile/username
        ]
        
        usernames = []
        for pattern in username_patterns:
            matches = re.findall(pattern, text)
            usernames.extend(matches)
        
        # Deduplicate and filter
        usernames = list(set(usernames))
        
        # Remove common false positives
        exclude = ['user', 'profile', 'account', 'admin', 'username']
        usernames = [u for u in usernames if u.lower() not in exclude]
        
        return usernames[:10]  # Return top 10
    
    def extract_phone_numbers(self, text: str) -> List[str]:
        """Extract phone numbers from text"""
        phone_patterns = [
            r'\+?1?\d{10,14}',  # International format
            r'\(\d{3}\)\s*\d{3}-\d{4}',  # (123) 456-7890
            r'\d{3}[-.\s]?\d{3}[-.\s]?\d{4}',  # 123-456-7890
        ]
        
        phones = []
        for pattern in phone_patterns:
            matches = re.findall(pattern, text)
            phones.extend(matches)
        
        return list(set(phones))
    
    def extract_social_links(self, html: str) -> Dict[str, List[str]]:
        """Extract social media links from HTML"""
        platforms = {
            'twitter': r'https?://(?:www\.)?twitter\.com/([a-zA-Z0-9_]+)',
            'instagram': r'https?://(?:www\.)?instagram\.com/([a-zA-Z0-9_.]+)',
            'facebook': r'https?://(?:www\.)?facebook\.com/([a-zA-Z0-9.]+)',
            'linkedin': r'https?://(?:www\.)?linkedin\.com/in/([a-zA-Z0-9\-]+)',
            'github': r'https?://(?:www\.)?github\.com/([a-zA-Z0-9\-]+)',
            'youtube': r'https?://(?:www\.)?youtube\.com/(?:@|c/)?([a-zA-Z0-9_\-]+)',
        }
        
        links = {}
        for platform, pattern in platforms.items():
            matches = re.findall(pattern, html)
            if matches:
                links[platform] = list(set(matches))
        
        return links
