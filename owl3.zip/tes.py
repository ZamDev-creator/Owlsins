#!/usr/bin/env python3
"""
Test script untuk Face Detection
Verifikasi bahwa OpenCV dan cascade files bekerja dengan baik
"""

import sys
from pathlib import Path

def test_opencv():
    """Test OpenCV installation"""
    print("=" * 70)
    print("TEST 1: OpenCV Installation")
    print("=" * 70)
    
    try:
        import cv2
        print(f"✓ OpenCV installed: version {cv2.__version__}")
        return True
    except ImportError as e:
        print(f"✗ OpenCV NOT installed: {e}")
        print("\nInstall dengan: pkg install opencv -y")
        return False

def test_cascade():
    """Test cascade file"""
    print("\n" + "=" * 70)
    print("TEST 2: Haar Cascade File")
    print("=" * 70)
    
    cascade_path = Path("data/cascades/haarcascade_frontalface_alt.xml")
    
    if not cascade_path.exists():
        print(f"✗ Cascade file NOT found: {cascade_path}")
        print("\nDownload dengan: python setup_osint_tools.py")
        return False
    
    print(f"✓ Cascade file found: {cascade_path}")
    
    # Test loading
    try:
        import cv2
        face_cascade = cv2.CascadeClassifier(str(cascade_path))
        if face_cascade.empty():
            print("✗ Cascade file is EMPTY or corrupt!")
            return False
        print("✓ Cascade loaded successfully")
        return True
    except Exception as e:
        print(f"✗ Error loading cascade: {e}")
        return False

def test_face_detection():
    """Test face detection on sample image"""
    print("\n" + "=" * 70)
    print("TEST 3: Face Detection")
    print("=" * 70)
    
    # Check if test image exists
    test_images = [
        "IMG20260129101638.jpg",
        "test_image.jpg",
        "DSCN0010.jpg"
    ]
    
    test_image = None
    for img in test_images:
        if Path(img).exists():
            test_image = img
            break
    
    if not test_image:
        print("✗ No test image found")
        print(f"  Looked for: {', '.join(test_images)}")
        print("\nLetakkan gambar dengan wajah di folder ini untuk test")
        return False
    
    print(f"Using test image: {test_image}")
    
    try:
        import cv2
        
        # Load cascade
        cascade_path = "data/cascades/haarcascade_frontalface_alt.xml"
        face_cascade = cv2.CascadeClassifier(cascade_path)
        
        # Load image
        img = cv2.imread(test_image)
        if img is None:
            print(f"✗ Cannot load image: {test_image}")
            return False
        
        print(f"✓ Image loaded: {img.shape[1]}x{img.shape[0]} pixels")
        
        # Convert to grayscale
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        
        # Detect faces with OPTIMIZED parameters
        faces = face_cascade.detectMultiScale(
            gray,
            scaleFactor=1.05,      # Lower = more sensitive
            minNeighbors=4,        # Lower = more detections
            minSize=(20, 20),      # Smaller minimum size
            flags=cv2.CASCADE_SCALE_IMAGE
        )
        
        print(f"\n{'=' * 70}")
        print(f"RESULT: Found {len(faces)} face(s)!")
        print(f"{'=' * 70}\n")
        
        if len(faces) > 0:
            for i, (x, y, w, h) in enumerate(faces):
                print(f"Face {i+1}:")
                print(f"  Position: x={x}, y={y}")
                print(f"  Size: {w}x{h} pixels")
                print(f"  Center: ({x + w//2}, {y + h//2})")
            
            # Draw rectangles and save
            for i, (x, y, w, h) in enumerate(faces):
                cv2.rectangle(img, (x, y), (x+w, y+h), (0, 255, 0), 2)
                cv2.putText(img, f"Face {i+1}", (x, y-10), 
                           cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 0), 2)
            
            output_dir = Path("output/face_detection")
            output_dir.mkdir(parents=True, exist_ok=True)
            output_path = output_dir / "test_detection_result.jpg"
            cv2.imwrite(str(output_path), img)
            
            print(f"\n✓ Annotated image saved to: {output_path}")
            print("✓ Face detection is WORKING!")
            return True
        else:
            print("⚠ No faces detected")
            print("\nTips:")
            print("  - Pastikan gambar memiliki wajah yang jelas")
            print("  - Wajah tidak terlalu kecil (minimal 20x20 pixel)")
            print("  - Pencahayaan cukup baik")
            print("  - Wajah menghadap ke depan")
            return False
            
    except Exception as e:
        print(f"✗ Error during face detection: {e}")
        import traceback
        traceback.print_exc()
        return False

def main():
    """Run all tests"""
    print("\n")
    print("╔" + "=" * 68 + "╗")
    print("║" + " " * 15 + "OSINT TOOLS - FACE DETECTION TEST" + " " * 20 + "║")
    print("╚" + "=" * 68 + "╝")
    print()
    
    results = []
    
    # Run tests
    results.append(("OpenCV Installation", test_opencv()))
    results.append(("Cascade File", test_cascade()))
    results.append(("Face Detection", test_face_detection()))
    
    # Summary
    print("\n" + "=" * 70)
    print("TEST SUMMARY")
    print("=" * 70)
    
    all_passed = True
    for test_name, passed in results:
        status = "✓ PASS" if passed else "✗ FAIL"
        print(f"{status:10} | {test_name}")
        if not passed:
            all_passed = False
    
    print("=" * 70)
    
    if all_passed:
        print("\n✓ All tests PASSED! Face detection is ready to use.")
        print("  Run: python main.py")
        return 0
    else:
        print("\n✗ Some tests FAILED. Please fix the issues above.")
        return 1

if __name__ == "__main__":
    sys.exit(main())
