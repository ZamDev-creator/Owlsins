#!/bin/bash
# OSINT Image Tools Installation Script for Termux
# Avoids compiling numpy from source

echo "================================================"
echo "OSINT Image Tools - Termux Installation"
echo "================================================"

# Update packages
echo ""
echo "[1/5] Updating Termux packages..."
pkg update -y

# Install system dependencies
echo ""
echo "[2/5] Installing system dependencies..."
pkg install -y python python-pip git wget

# Install Python packages (avoiding numpy compilation)
echo ""
echo "[3/5] Installing Python packages..."
echo "⚠️  This may take a few minutes..."

# Install pre-built wheels first
pip install --upgrade pip --break-system-packages

# Core dependencies that don't need compilation
pip install requests beautifulsoup4 --break-system-packages

# Image processing
pip install Pillow piexif --break-system-packages

# UI and utilities
pip install click colorama tabulate tqdm python-dotenv --break-system-packages
pip install pyfiglet termcolor questionary nest-asyncio --break-system-packages
pip install aiohttp jinja2 phonenumbers --break-system-packages

# Try to install numpy (pre-built wheel if available)
echo ""
echo "Installing numpy..."
pip install numpy --break-system-packages 2>/dev/null || {
    echo "⚠️  Numpy pre-built wheel not available"
    echo "Trying alternative installation..."
    pkg install python-numpy -y
}

# Try to install opencv (lightweight version)
echo ""
echo "Installing OpenCV (this may take a moment)..."
pip install opencv-python-headless --break-system-packages 2>/dev/null || {
    echo "⚠️  OpenCV installation failed"
    echo "Face detection will be limited"
}

# Download cascade files
echo ""
echo "[4/5] Setting up face detection cascades..."
python3 setup_osint_tools.py

# Create output directories
echo ""
echo "[5/5] Creating directories..."
mkdir -p output/face_detection
mkdir -p output/reports
mkdir -p output/images
mkdir -p data/cascades

echo ""
echo "================================================"
echo "✅ Installation Complete!"
echo "================================================"
echo ""
echo "Available Features:"
echo "  📸 EXIF Metadata Extraction ✓"
echo "  🔍 Reverse Image Search ✓"
echo "  👤 Face Detection (if OpenCV installed)"
echo "  📍 Location Recognition (requires API key)"
echo ""
echo "To start:"
echo "  python main.py"
echo ""
echo "================================================"

