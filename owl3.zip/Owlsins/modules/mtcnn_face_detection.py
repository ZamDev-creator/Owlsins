"""
MTCNN Face Detection Module
Lebih akurat dari Haar Cascade, dan compatible dengan Termux
"""

import os
import cv2
import numpy as np
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from PIL import Image

from utils.logger import setup_logger

logger = setup_logger(__name__)


class MTCNNFaceDetector:
    """Face detection using MTCNN (Multi-task Cascaded Convolutional Networks)"""
    
    def __init__(self):
        """Initialize MTCNN detector"""
        self.detector = None
        self._load_detector()
    
    def _load_detector(self):
        """Load MTCNN detector (lazy loading)"""
        try:
            from mtcnn import MTCNN
            self.detector = MTCNN()
            logger.info("[MTCNN] Detector loaded successfully")
        except ImportError:
            logger.error("[MTCNN] MTCNN not installed. Install with: pip install mtcnn")
            self.detector = None
        except Exception as e:
            logger.error(f"[MTCNN] Failed to load detector: {e}")
            self.detector = None
    
    def detect_faces(self, image_path: str, min_confidence: float = 0.90) -> Dict:
        """
        Detect faces in image using MTCNN
        
        Args:
            image_path: Path to image file
            min_confidence: Minimum confidence threshold (0.0 - 1.0)
            
        Returns:
            dict: Detection results with face bounding boxes and landmarks
        """
        if not self.detector:
            logger.error("[MTCNN] Detector not available")
            return {
                'success': False,
                'method': 'mtcnn',
                'error': 'MTCNN not installed or failed to load',
                'faces_detected': 0,
                'faces': []
            }
        
        logger.info(f"[MTCNN] Detecting faces in: {image_path}")
        
        try:
            # Load image using PIL (MTCNN requires PIL/RGB format)
            img_pil = Image.open(image_path)
            img_rgb = img_pil.convert('RGB')
            img_array = np.array(img_rgb)
            
            # Detect faces
            detections = self.detector.detect_faces(img_array)
            
            # Filter by confidence
            filtered_faces = [
                face for face in detections 
                if face['confidence'] >= min_confidence
            ]
            
            logger.info(f"[MTCNN] Found {len(filtered_faces)} faces (min conf: {min_confidence})")
            
            # Format results
            results = {
                'success': True,
                'method': 'mtcnn',
                'faces_detected': len(filtered_faces),
                'faces': [],
                'image_path': str(image_path),
                'image_size': img_array.shape[:2]
            }
            
            for i, face in enumerate(filtered_faces):
                face_info = {
                    'id': i + 1,
                    'confidence': round(face['confidence'], 3),
                    'box': {
                        'x': face['box'][0],
                        'y': face['box'][1],
                        'width': face['box'][2],
                        'height': face['box'][3]
                    },
                    'keypoints': {
                        'left_eye': face['keypoints']['left_eye'],
                        'right_eye': face['keypoints']['right_eye'],
                        'nose': face['keypoints']['nose'],
                        'mouth_left': face['keypoints']['mouth_left'],
                        'mouth_right': face['keypoints']['mouth_right']
                    }
                }
                results['faces'].append(face_info)
            
            return results
            
        except Exception as e:
            logger.error(f"[MTCNN] Detection error: {e}")
            return {
                'success': False,
                'method': 'mtcnn',
                'error': str(e),
                'faces_detected': 0,
                'faces': []
            }
    
    def save_face_crops(self, image_path: str, output_dir: str = None, 
                        min_confidence: float = 0.90) -> List[str]:
        """
        Detect faces and save individual crops
        
        Args:
            image_path: Path to image file
            output_dir: Directory to save face crops (default: output/face_detection)
            min_confidence: Minimum confidence threshold
            
        Returns:
            list: Paths to saved face crops
        """
        if output_dir is None:
            output_dir = "output/face_detection"
        
        Path(output_dir).mkdir(parents=True, exist_ok=True)
        
        # Detect faces
        results = self.detect_faces(image_path, min_confidence)
        
        if not results['success'] or results['faces_detected'] == 0:
            logger.warning("[MTCNN] No faces to crop")
            return []
        
        # Load image
        img = cv2.imread(image_path)
        if img is None:
            logger.error(f"[MTCNN] Failed to load image: {image_path}")
            return []
        
        saved_paths = []
        base_name = Path(image_path).stem
        
        for face in results['faces']:
            try:
                # Get box coordinates
                x = face['box']['x']
                y = face['box']['y']
                w = face['box']['width']
                h = face['box']['height']
                
                # Add padding (10%)
                padding = int(max(w, h) * 0.1)
                x1 = max(0, x - padding)
                y1 = max(0, y - padding)
                x2 = min(img.shape[1], x + w + padding)
                y2 = min(img.shape[0], y + h + padding)
                
                # Crop face
                face_crop = img[y1:y2, x1:x2]
                
                # Save
                output_path = Path(output_dir) / f"{base_name}_face_{face['id']}.jpg"
                cv2.imwrite(str(output_path), face_crop)
                
                logger.info(f"[MTCNN] Saved face crop: {output_path}")
                saved_paths.append(str(output_path))
                
            except Exception as e:
                logger.error(f"[MTCNN] Failed to crop face {face['id']}: {e}")
        
        return saved_paths
    
    def draw_faces(self, image_path: str, output_path: str = None, 
                   min_confidence: float = 0.90) -> Optional[str]:
        """
        Draw bounding boxes and landmarks on detected faces
        
        Args:
            image_path: Path to image file
            output_path: Path to save annotated image
            min_confidence: Minimum confidence threshold
            
        Returns:
            str: Path to saved annotated image or None
        """
        # Detect faces
        results = self.detect_faces(image_path, min_confidence)
        
        if not results['success'] or results['faces_detected'] == 0:
            logger.warning("[MTCNN] No faces to draw")
            return None
        
        # Load image
        img = cv2.imread(image_path)
        if img is None:
            logger.error(f"[MTCNN] Failed to load image: {image_path}")
            return None
        
        # Draw each face
        for face in results['faces']:
            # Draw bounding box
            x = face['box']['x']
            y = face['box']['y']
            w = face['box']['width']
            h = face['box']['height']
            
            cv2.rectangle(img, (x, y), (x + w, y + h), (0, 255, 0), 2)
            
            # Draw confidence label
            label = f"Face {face['id']}: {face['confidence']:.2f}"
            cv2.putText(img, label, (x, y - 10), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)
            
            # Draw keypoints
            keypoints = face['keypoints']
            for key, (kx, ky) in keypoints.items():
                cv2.circle(img, (kx, ky), 2, (0, 0, 255), -1)
        
        # Save annotated image
        if output_path is None:
            output_dir = Path("output/face_detection")
            output_dir.mkdir(parents=True, exist_ok=True)
            output_path = output_dir / f"{Path(image_path).stem}_mtcnn.jpg"
        
        cv2.imwrite(str(output_path), img)
        logger.info(f"[MTCNN] Saved annotated image: {output_path}")
        
        return str(output_path)


# Standalone helper function
def detect_faces_mtcnn(image_path: str, min_confidence: float = 0.90) -> Dict:
    """
    Quick function to detect faces using MTCNN
    
    Args:
        image_path: Path to image file
        min_confidence: Minimum confidence threshold
        
    Returns:
        dict: Detection results
    """
    detector = MTCNNFaceDetector()
    return detector.detect_faces(image_path, min_confidence)
