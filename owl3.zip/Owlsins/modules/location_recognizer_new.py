"""
Location Recognition Module - IMPROVED VERSION
Menggunakan Google Lens (lebih akurat dari reverse image search)
Dengan parallel upload dan multiple providers
Compatible dengan Termux
"""

import os
import json
import requests
import base64
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from PIL import Image
import io

from utils.logger import setup_logger
from utils.image_uploader import ImageUploader

logger = setup_logger(__name__)


class LocationRecognizerSearchAPI:
    """Recognize location/landmarks using SearchAPI.io with Google Lens"""
    
    def __init__(self, api_key: Optional[str] = None):
        """
        Initialize Location Recognizer with SearchAPI
        
        Args:
            api_key: SearchAPI.io API key (get from https://www.searchapi.io/)
        """
        self.api_key = api_key
        self.base_url = "https://www.searchapi.io/api/v1/search"
        self.uploader = ImageUploader()
    
    def recognize_location(self, image_path: str) -> Dict:
        """
        Recognize location from image using Google Lens via SearchAPI
        
        Args:
            image_path: Path to image file
            
        Returns:
            dict: Location recognition results with confidence score
        """
        logger.info(f"[LOCATION] Analyzing with Google Lens: {image_path}")
        
        if not self.api_key:
            return self._return_manual_method(image_path)
        
        try:
            # Use improved Google Lens search
            results = self._search_with_google_lens(image_path)
            
            # Add confidence scoring
            from core.confidence_scoring import ConfidenceScorer
            scorer = ConfidenceScorer()
            
            # Calculate confidence based on results
            confidence = self._calculate_confidence(results)
            results['confidence'] = confidence
            results['confidence_label'] = scorer.get_confidence_label(confidence)
            
            return results
            
        except Exception as e:
            logger.error(f"[LOCATION] SearchAPI error: {e}")
            return {
                'success': False,
                'method': 'searchapi',
                'error': str(e),
                'landmarks': [],
                'fallback': self._return_manual_method(image_path)
            }
    
    def _search_with_google_lens(self, image_path: str) -> Dict:
        """
        IMPROVED: Search using Google Lens (not reverse image search)
        Uses parallel upload for faster processing
        """
        logger.info("[LOCATION] Using Google Lens engine (improved method)...")
        
        try:
            # Step 1: Upload image to public hosting (parallel, fast)
            logger.info("[LOCATION] Uploading image for Lens search...")
            image_url = self.uploader.upload_parallel(image_path)
            
            if not image_url:
                logger.warning("[LOCATION] Upload failed, trying manual method")
                return self._return_manual_method(image_path)
            
            logger.info(f"[LOCATION] Image uploaded: {image_url}")
            
            # Step 2: Search with Google Lens using URL
            params = {
                "engine": "google_lens",  # ✅ CHANGED: dari google_reverse_image
                "url": image_url,         # ✅ CHANGED: dari base64 ke URL
                "api_key": self.api_key
            }
            
            response = requests.get(self.base_url, params=params, timeout=30)
            response.raise_for_status()
            
            data = response.json()
            
            # Step 3: Parse results with improved parser
            results = self._parse_lens_results(data)  # ✅ NEW: parser khusus
            results['method'] = 'google_lens'
            results['success'] = True
            results['image_url'] = image_url
            
            return results
            
        except requests.exceptions.RequestException as e:
            logger.error(f"[LOCATION] SearchAPI request error: {e}")
            return self._return_manual_method(image_path)
    
    def _parse_lens_results(self, data: Dict) -> Dict:
        """
        NEW: Parser khusus untuk Google Lens response
        Fokus pada Knowledge Graph untuk akurasi maksimal
        """
        results = {
            'landmarks': [],
            'location_name': None,
            'coordinates': None,
            'confidence': 0.0,
            'visual_matches': [],
            'knowledge_graph': {},
            'source': 'google_lens'
        }
        
        # PRIORITY 1: Knowledge Graph (info landmark paling akurat)
        if 'knowledge_graph' in data:
            kg = data['knowledge_graph']
            results['knowledge_graph'] = kg
            
            logger.info("[LOCATION] ✓ Knowledge Graph found (high confidence)")
            
            # Extract landmark info
            if 'title' in kg:
                results['location_name'] = kg['title']
                results['confidence'] = 0.95  # Very high for knowledge graph
                
                landmark = {
                    'name': kg.get('title'),
                    'type': kg.get('type', 'Unknown'),
                    'description': kg.get('description', ''),
                    'rating': kg.get('rating'),
                    'reviews': kg.get('reviews_count'),
                    'address': kg.get('address'),
                    'phone': kg.get('phone'),
                    'website': kg.get('website'),
                    'hours': kg.get('hours')
                }
                
                # Extract GPS coordinates if available
                if 'gps_coordinates' in kg:
                    coords = kg['gps_coordinates']
                    results['coordinates'] = {
                        'latitude': coords.get('latitude'),
                        'longitude': coords.get('longitude'),
                        'altitude': coords.get('altitude')
                    }
                    landmark['coordinates'] = results['coordinates']
                    logger.info(f"[LOCATION] GPS: {coords.get('latitude')}, {coords.get('longitude')}")
                
                results['landmarks'].append(landmark)
        
        # PRIORITY 2: Visual Matches (jika knowledge graph tidak ada)
        if not results['location_name'] and 'visual_matches' in data:
            logger.info(f"[LOCATION] Processing {len(data['visual_matches'])} visual matches")
            
            for match in data['visual_matches'][:10]:
                results['visual_matches'].append({
                    'title': match.get('title', ''),
                    'link': match.get('link', ''),
                    'source': match.get('source', ''),
                    'thumbnail': match.get('thumbnail', ''),
                    'snippet': match.get('snippet', '')
                })
            
            # Use first match as best guess
            if results['visual_matches']:
                results['location_name'] = results['visual_matches'][0]['title']
                results['confidence'] = 0.70
                logger.info(f"[LOCATION] Best guess: {results['location_name']}")
        
        # PRIORITY 3: Text Results (cadangan)
        if not results['location_name'] and 'text_results' in data:
            if data['text_results']:
                results['location_name'] = data['text_results'][0].get('title', 'Unknown')
                results['confidence'] = 0.50
                logger.info(f"[LOCATION] Text result: {results['location_name']}")
        
        return results
    
    def _calculate_confidence(self, results: Dict) -> float:
        """
        Calculate confidence score for location results
        
        Factors:
        - Knowledge graph: +0.40
        - Coordinates: +0.20
        - Visual matches: +0.20
        - Address/details: +0.10
        - Reviews/rating: +0.10
        """
        confidence = 0.0
        
        # Knowledge graph present
        if results.get('knowledge_graph'):
            confidence += 0.40
        
        # Has coordinates
        if results.get('coordinates'):
            confidence += 0.20
        
        # Multiple visual matches
        num_matches = len(results.get('visual_matches', []))
        if num_matches >= 5:
            confidence += 0.20
        elif num_matches >= 3:
            confidence += 0.15
        elif num_matches >= 1:
            confidence += 0.10
        
        # Has address/details
        landmarks = results.get('landmarks', [])
        if landmarks:
            first = landmarks[0]
            if first.get('address') or first.get('phone'):
                confidence += 0.10
        
        # Reviews/rating
        if landmarks:
            first = landmarks[0]
            if first.get('reviews') or first.get('rating'):
                confidence += 0.10
        
        return min(confidence, 1.0)
    
    def _return_manual_method(self, image_path: str) -> Dict:
        """Return manual Google Lens method when no API key"""
        abs_path = Path(image_path).absolute()
        
        return {
            'success': True,
            'method': 'manual',
            'landmarks': [],
            'location_name': None,
            'coordinates': None,
            'confidence': 0.0,
            'search_urls': {
                'google_lens': 'https://lens.google.com/',
                'google_images': 'https://images.google.com/',
                'yandex': 'https://yandex.com/images/',
                'tineye': 'https://tineye.com/'
            },
            'instructions': [
                f'Upload {abs_path.name} to Google Lens for best results',
                '',
                '🎯 RECOMMENDED: Google Lens',
                '   1. Go to https://lens.google.com/',
                '   2. Click "Upload image"',
                '   3. Select your photo',
                '   4. Google will identify the location automatically',
                '',
                '📸 Alternative: Google Images',
                '   1. Go to https://images.google.com/',
                '   2. Click camera icon',
                '   3. Upload image',
                '   4. Check "Pages that include matching images"'
            ],
            'note': 'No SearchAPI key found. Using manual method (recommended for accuracy).',
            'get_api_key': 'Register at https://www.searchapi.io/ for automated results (100 free requests/month)'
        }
    
    def search_by_url(self, image_url: str) -> Dict:
        """
        Search location using image URL directly
        
        Args:
            image_url: Public URL of the image
            
        Returns:
            dict: Location recognition results
        """
        logger.info(f"[LOCATION] Searching by URL: {image_url}")
        
        if not self.api_key:
            return {
                'success': False,
                'error': 'SearchAPI key required',
                'get_api_key': 'https://www.searchapi.io/'
            }
        
        try:
            params = {
                "engine": "google_lens",  # ✅ CHANGED
                "url": image_url,
                "api_key": self.api_key
            }
            
            response = requests.get(self.base_url, params=params, timeout=30)
            response.raise_for_status()
            
            data = response.json()
            results = self._parse_lens_results(data)  # ✅ NEW parser
            results['method'] = 'google_lens_url'
            results['success'] = True
            
            # Add confidence
            confidence = self._calculate_confidence(results)
            results['confidence'] = confidence
            
            logger.info(f"[LOCATION] Found {len(results.get('landmarks', []))} results")
            return results
            
        except Exception as e:
            logger.error(f"[LOCATION] URL search error: {e}")
            return {
                'success': False,
                'method': 'google_lens_url',
                'error': str(e)
            }
    
    def batch_recognize(self, image_paths: List[str]) -> List[Dict]:
        """
        Recognize locations from multiple images
        
        Args:
            image_paths: List of image file paths
            
        Returns:
            list: List of recognition results
        """
        logger.info(f"[LOCATION] Batch processing {len(image_paths)} images...")
        
        results = []
        for i, image_path in enumerate(image_paths, 1):
            logger.info(f"[LOCATION] Processing {i}/{len(image_paths)}: {image_path}")
            
            result = self.recognize_location(image_path)
            result['image_path'] = image_path
            result['index'] = i
            results.append(result)
        
        logger.info(f"[LOCATION] Batch processing complete")
        return results


# Backward compatibility
LocationRecognizer = LocationRecognizerSearchAPI


# Standalone helper functions
def recognize_location_searchapi(image_path: str, api_key: Optional[str] = None) -> Dict:
    """Quick function to recognize location using SearchAPI"""
    recognizer = LocationRecognizerSearchAPI(api_key=api_key)
    return recognizer.recognize_location(image_path)


def recognize_by_url(image_url: str, api_key: str) -> Dict:
    """Quick function to search by image URL"""
    recognizer = LocationRecognizerSearchAPI(api_key=api_key)
    return recognizer.search_by_url(image_url)
