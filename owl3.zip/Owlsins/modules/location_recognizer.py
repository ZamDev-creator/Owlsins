"""
Location Recognition Module - SearchAPI.io (Google Lens Scraper)
100% FREE - No Credit Card Required
Register: https://www.searchapi.io/ (100 requests/month gratis)
"""

import os
import json
import requests
import base64
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from PIL import Image
import io

from utils.logger import setup_logger

logger = setup_logger(__name__)


class LocationRecognizerSearchAPI:
    """Recognize location/landmarks using SearchAPI.io (Google Lens scraper)"""
    
    def __init__(self, api_key: Optional[str] = None):
        """
        Initialize Location Recognizer with SearchAPI
        
        Args:
            api_key: SearchAPI.io API key (get from https://www.searchapi.io/)
        """
        self.api_key = api_key
        self.base_url = "https://www.searchapi.io/api/v1/search"
    
    def recognize_location(self, image_path: str) -> Dict:
        """
        Recognize location from image using Google Lens via SearchAPI
        
        Args:
            image_path: Path to image file
            
        Returns:
            dict: Location recognition results
        """
        logger.info(f"[LOCATION] Analyzing with SearchAPI: {image_path}")
        
        if not self.api_key:
            return self._return_manual_method(image_path)
        
        try:
            # Method 1: Try with image URL (if image is accessible online)
            # Method 2: Upload to temporary hosting, then use URL
            # Method 3: Use base64 (if supported)
            
            # For now, we'll use Google Lens reverse search
            results = self._search_with_google_lens(image_path)
            return results
            
        except Exception as e:
            logger.error(f"[LOCATION] SearchAPI error: {e}")
            return {
                'success': False,
                'method': 'searchapi',
                'error': str(e),
                'landmarks': [],
                'fallback': self._return_manual_method(image_path)
            }
    
    def _search_with_google_lens(self, image_path: str) -> Dict:
        """Search using Google Lens engine via SearchAPI"""
        logger.info("[LOCATION] Using Google Lens engine...")
        
        try:
            # Convert image to base64
            with open(image_path, 'rb') as f:
                image_data = f.read()
            
            image_b64 = base64.b64encode(image_data).decode('utf-8')
            
            # SearchAPI parameters for Google Lens
            params = {
                "engine": "google_lens",
                "api_key": self.api_key
            }
            
            # Upload image as base64 or use URL
            # Check if we need to upload to temp host first
            # For now, try direct base64 approach
            
            # Alternative: Use reverse image search endpoint
            params = {
                "engine": "google_reverse_image",
                "api_key": self.api_key,
                "image_url": f"data:image/jpeg;base64,{image_b64}"
            }
            
            response = requests.get(self.base_url, params=params, timeout=30)
            response.raise_for_status()
            
            data = response.json()
            
            # Parse results
            results = self._parse_searchapi_results(data)
            results['method'] = 'searchapi'
            results['success'] = True
            
            return results
            
        except requests.exceptions.RequestException as e:
            logger.error(f"[LOCATION] SearchAPI request error: {e}")
            
            # Try alternative: provide upload URL
            return self._return_upload_method(image_path)
    
    def _parse_searchapi_results(self, data: Dict) -> Dict:
        """Parse SearchAPI response"""
        results = {
            'landmarks': [],
            'visual_matches': [],
            'pages_with_image': [],
            'location_name': None,
            'coordinates': None,
            'confidence': 0.0,
            'labels': []
        }
        
        # Extract visual matches (Google Lens results)
        if 'visual_matches' in data:
            for match in data['visual_matches'][:5]:
                results['visual_matches'].append({
                    'title': match.get('title', ''),
                    'link': match.get('link', ''),
                    'source': match.get('source', '')
                })
        
        # Extract knowledge graph (landmark info)
        if 'knowledge_graph' in data:
            kg = data['knowledge_graph']
            
            landmark_info = {
                'name': kg.get('title', ''),
                'description': kg.get('description', ''),
                'type': kg.get('type', '')
            }
            
            # Try to get location from knowledge graph
            if 'location' in kg:
                landmark_info['location'] = kg['location']
            
            if landmark_info['name']:
                results['landmarks'].append(landmark_info)
                results['location_name'] = landmark_info['name']
                results['confidence'] = 0.85  # High confidence from knowledge graph
        
        # Extract text matches for context
        if 'text_results' in data:
            for text in data['text_results'][:3]:
                results['labels'].append(text.get('title', ''))
        
        # Try to extract location from visual matches titles
        if not results['location_name'] and results['visual_matches']:
            # Use first visual match as potential location
            first_match = results['visual_matches'][0]
            results['location_name'] = first_match['title']
            results['confidence'] = 0.65
        
        return results
    
    def _return_upload_method(self, image_path: str) -> Dict:
        """Return method for manual upload to SearchAPI-compatible services"""
        abs_path = Path(image_path).absolute()
        
        return {
            'success': True,
            'method': 'upload_required',
            'landmarks': [],
            'location_name': None,
            'upload_instructions': {
                'step1': f'Upload {abs_path.name} to image hosting service',
                'step2': 'Get public URL of the image',
                'step3': 'Use the URL with SearchAPI',
                'services': [
                    'ImgBB: https://imgbb.com/',
                    'Imgur: https://imgur.com/',
                    'Postimages: https://postimages.org/'
                ]
            },
            'note': 'SearchAPI needs image URL. Upload to free hosting first, then try again.'
        }
    
    def _return_manual_method(self, image_path: str) -> Dict:
        """Return manual Google Lens method when no API key"""
        abs_path = Path(image_path).absolute()
        
        return {
            'success': True,
            'method': 'manual',
            'landmarks': [],
            'location_name': None,
            'coordinates': None,
            'search_urls': {
                'google_lens': 'https://lens.google.com/',
                'google_images': 'https://images.google.com/',
                'yandex': 'https://yandex.com/images/',
                'tineye': 'https://tineye.com/'
            },
            'instructions': [
                f'Upload {abs_path.name} to Google Lens for best results',
                '',
                '🎯 RECOMMENDED: Google Lens',
                '   1. Go to https://lens.google.com/',
                '   2. Click "Upload image"',
                '   3. Select your photo',
                '   4. Google will identify the location automatically',
                '',
                '📸 Alternative: Google Images',
                '   1. Go to https://images.google.com/',
                '   2. Click camera icon',
                '   3. Upload image',
                '   4. Check "Pages that include matching images"'
            ],
            'note': 'No SearchAPI key found. Using manual method (recommended for accuracy).',
            'get_api_key': 'Register at https://www.searchapi.io/ for automated results (100 free requests/month)'
        }
    
    def search_by_url(self, image_url: str) -> Dict:
        """
        Search location using image URL directly
        
        Args:
            image_url: Public URL of the image
            
        Returns:
            dict: Location recognition results
        """
        logger.info(f"[LOCATION] Searching by URL: {image_url}")
        
        if not self.api_key:
            return {
                'success': False,
                'error': 'SearchAPI key required',
                'get_api_key': 'https://www.searchapi.io/'
            }
        
        try:
            params = {
                "engine": "google_lens",
                "url": image_url,
                "api_key": self.api_key
            }
            
            response = requests.get(self.base_url, params=params, timeout=30)
            response.raise_for_status()
            
            data = response.json()
            results = self._parse_searchapi_results(data)
            results['method'] = 'searchapi_url'
            results['success'] = True
            
            logger.info(f"[LOCATION] Found {len(results.get('landmarks', []))} results")
            return results
            
        except Exception as e:
            logger.error(f"[LOCATION] URL search error: {e}")
            return {
                'success': False,
                'method': 'searchapi_url',
                'error': str(e)
            }
    
    def batch_recognize(self, image_paths: List[str]) -> List[Dict]:
        """
        Recognize locations from multiple images
        
        Args:
            image_paths: List of image file paths
            
        Returns:
            list: List of recognition results
        """
        logger.info(f"[LOCATION] Batch processing {len(image_paths)} images...")
        
        results = []
        for i, image_path in enumerate(image_paths, 1):
            logger.info(f"[LOCATION] Processing {i}/{len(image_paths)}: {image_path}")
            
            result = self.recognize_location(image_path)
            result['image_path'] = image_path
            result['index'] = i
            results.append(result)
        
        logger.info(f"[LOCATION] Batch processing complete")
        return results


# Backward compatibility
LocationRecognizer = LocationRecognizerSearchAPI


# Standalone helper functions
def recognize_location_searchapi(image_path: str, api_key: Optional[str] = None) -> Dict:
    """Quick function to recognize location using SearchAPI"""
    recognizer = LocationRecognizerSearchAPI(api_key=api_key)
    return recognizer.recognize_location(image_path)


def recognize_by_url(image_url: str, api_key: str) -> Dict:
    """Quick function to search by image URL"""
    recognizer = LocationRecognizerSearchAPI(api_key=api_key)
    return recognizer.search_by_url(image_url)
