"""
Database utility for OSINT Suite
Handles SQLite database operations for storing results
"""

import sqlite3
from datetime import datetime
from config import DB_PATH
from utils.logger import setup_logger

logger = setup_logger(__name__)


class Database:
    """SQLite database handler for OSINT Suite"""
    
    def __init__(self):
        """Initialize database connection and create tables"""
        self.conn = sqlite3.connect(DB_PATH)
        self.cursor = self.conn.cursor()
        self._create_tables()
    
    def _create_tables(self):
        """Create necessary database tables if they don't exist"""
        
        # Username search results
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS username_searches (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL,
                platform TEXT NOT NULL,
                found BOOLEAN NOT NULL,
                url TEXT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                UNIQUE(username, platform)
            )
        ''')
        
        # Email OSINT results
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS email_searches (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                email TEXT NOT NULL UNIQUE,
                breached BOOLEAN,
                breach_count INTEGER,
                disposable BOOLEAN,
                valid BOOLEAN,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Image metadata results
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS image_metadata (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                filename TEXT NOT NULL,
                latitude REAL,
                longitude REAL,
                timestamp_taken DATETIME,
                camera_make TEXT,
                camera_model TEXT,
                software TEXT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Change monitoring
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS monitored_urls (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                url TEXT NOT NULL UNIQUE,
                last_hash TEXT,
                last_check DATETIME,
                change_detected BOOLEAN DEFAULT 0,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Entities table - for advanced OSINT
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS entities (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                primary_identifier TEXT NOT NULL UNIQUE,
                entity_type TEXT NOT NULL,
                confidence_score REAL DEFAULT 0.0,
                risk_score REAL DEFAULT 0.0,
                identifiers TEXT,
                attributes TEXT,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Evidence table - tracks all evidence for entities
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS evidence (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                entity_id INTEGER NOT NULL,
                source TEXT NOT NULL,
                evidence_type TEXT NOT NULL,
                signal TEXT NOT NULL,
                value TEXT,
                weight REAL NOT NULL,
                reliability REAL NOT NULL,
                score REAL,
                metadata TEXT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (entity_id) REFERENCES entities(id)
            )
        ''')
        
        # Correlations table - tracks correlations between data
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS correlations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                entity_id INTEGER NOT NULL,
                correlation_type TEXT NOT NULL,
                confidence REAL NOT NULL,
                details TEXT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (entity_id) REFERENCES entities(id)
            )
        ''')
        
        self.conn.commit()
        logger.info("Database initialized successfully with entity support")
    
    def save_username_result(self, username, platform, found, url):
        """
        Save username search result to database
        
        Args:
            username: Username searched
            platform: Platform name
            found: Whether profile was found
            url: Profile URL
        """
        try:
            self.cursor.execute('''
                INSERT OR REPLACE INTO username_searches 
                (username, platform, found, url, timestamp)
                VALUES (?, ?, ?, ?, ?)
            ''', (username, platform, found, url, datetime.now()))
            self.conn.commit()
        except Exception as e:
            logger.error(f"Error saving username result: {e}")
    
    def save_email_result(self, email, breached, breach_count, disposable, valid):
        """
        Save email OSINT result to database
        
        Args:
            email: Email address
            breached: Whether found in breaches
            breach_count: Number of breaches
            disposable: Whether disposable email
            valid: Whether format is valid
        """
        try:
            self.cursor.execute('''
                INSERT OR REPLACE INTO email_searches 
                (email, breached, breach_count, disposable, valid, timestamp)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (email, breached, breach_count, disposable, valid, datetime.now()))
            self.conn.commit()
        except Exception as e:
            logger.error(f"Error saving email result: {e}")
    
    def save_image_metadata(self, filename, metadata):
        """
        Save image metadata to database
        
        Args:
            filename: Image filename
            metadata: Dictionary containing metadata
        """
        try:
            self.cursor.execute('''
                INSERT INTO image_metadata 
                (filename, latitude, longitude, timestamp_taken, 
                 camera_make, camera_model, software, timestamp)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                filename,
                metadata.get('latitude'),
                metadata.get('longitude'),
                metadata.get('timestamp_taken'),
                metadata.get('camera_make'),
                metadata.get('camera_model'),
                metadata.get('software'),
                datetime.now()
            ))
            self.conn.commit()
        except Exception as e:
            logger.error(f"Error saving image metadata: {e}")
    
    def add_monitored_url(self, url, content_hash):
        """
        Add URL to monitoring list
        
        Args:
            url: URL to monitor
            content_hash: Initial content hash
        
        Returns:
            bool: Success status
        """
        try:
            self.cursor.execute('''
                INSERT OR REPLACE INTO monitored_urls 
                (url, last_hash, last_check)
                VALUES (?, ?, ?)
            ''', (url, content_hash, datetime.now()))
            self.conn.commit()
            return True
        except Exception as e:
            logger.error(f"Error adding monitored URL: {e}")
            return False
    
    def update_monitored_url(self, url, content_hash, change_detected):
        """
        Update monitored URL status
        
        Args:
            url: URL to update
            content_hash: New content hash
            change_detected: Whether change was detected
        """
        try:
            self.cursor.execute('''
                UPDATE monitored_urls 
                SET last_hash = ?, last_check = ?, change_detected = ?
                WHERE url = ?
            ''', (content_hash, datetime.now(), change_detected, url))
            self.conn.commit()
        except Exception as e:
            logger.error(f"Error updating monitored URL: {e}")
    
    def get_monitored_urls(self):
        """
        Get all monitored URLs
        
        Returns:
            list: List of monitored URL records
        """
        self.cursor.execute('SELECT * FROM monitored_urls')
        return self.cursor.fetchall()
    
    def get_username_history(self, username):
        """
        Get search history for a username
        
        Args:
            username: Username to search for
        
        Returns:
            list: List of search records
        """
        self.cursor.execute('''
            SELECT platform, found, url, timestamp 
            FROM username_searches 
            WHERE username = ?
            ORDER BY timestamp DESC
        ''', (username,))
        return self.cursor.fetchall()
    
    def remove_monitored_url(self, url):
        """
        Remove URL from monitoring
        
        Args:
            url: URL to remove
        
        Returns:
            bool: Success status
        """
        try:
            self.cursor.execute('DELETE FROM monitored_urls WHERE url = ?', (url,))
            self.conn.commit()
            return True
        except Exception as e:
            logger.error(f"Error removing URL: {e}")
            return False
    
    def save_entity(self, entity):
        """
        Save entity to database
        
        Args:
            entity: Entity object to save
        
        Returns:
            int: Entity ID
        """
        import json
        try:
            identifiers_json = json.dumps(entity.identifiers)
            attributes_json = json.dumps(entity.attributes)
            
            self.cursor.execute('''
                INSERT OR REPLACE INTO entities 
                (primary_identifier, entity_type, confidence_score, risk_score, 
                 identifiers, attributes, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (
                entity.primary_identifier,
                entity.entity_type,
                entity.confidence_score,
                entity.risk_score,
                identifiers_json,
                attributes_json,
                datetime.now()
            ))
            self.conn.commit()
            
            entity_id = self.cursor.lastrowid
            
            # Save evidence
            for evidence in entity.evidence:
                self.save_evidence(entity_id, evidence)
            
            return entity_id
        except Exception as e:
            logger.error(f"Error saving entity: {e}")
            return None
    
    def save_evidence(self, entity_id, evidence):
        """
        Save evidence to database
        
        Args:
            entity_id: ID of the entity this evidence belongs to
            evidence: Evidence object to save
        """
        import json
        try:
            value_json = json.dumps(evidence.value) if evidence.value else None
            metadata_json = json.dumps(evidence.metadata) if evidence.metadata else None
            
            self.cursor.execute('''
                INSERT INTO evidence 
                (entity_id, source, evidence_type, signal, value, weight, 
                 reliability, score, metadata, timestamp)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                entity_id,
                evidence.source,
                evidence.evidence_type.value,
                evidence.signal,
                value_json,
                evidence.weight,
                evidence.reliability,
                evidence.score(),
                metadata_json,
                evidence.timestamp
            ))
            self.conn.commit()
        except Exception as e:
            logger.error(f"Error saving evidence: {e}")
    
    def save_correlation(self, entity_id, correlation):
        """
        Save correlation to database
        
        Args:
            entity_id: ID of the entity
            correlation: Correlation data
        """
        import json
        try:
            details_json = json.dumps(correlation)
            
            self.cursor.execute('''
                INSERT INTO correlations 
                (entity_id, correlation_type, confidence, details, timestamp)
                VALUES (?, ?, ?, ?, ?)
            ''', (
                entity_id,
                correlation.get('type', 'unknown'),
                correlation.get('confidence', 0.0),
                details_json,
                datetime.now()
            ))
            self.conn.commit()
        except Exception as e:
            logger.error(f"Error saving correlation: {e}")
    
    def get_entity(self, primary_identifier):
        """
        Get entity from database
        
        Args:
            primary_identifier: Primary identifier of the entity
        
        Returns:
            dict: Entity data or None
        """
        import json
        try:
            self.cursor.execute('''
                SELECT * FROM entities WHERE primary_identifier = ?
            ''', (primary_identifier,))
            row = self.cursor.fetchone()
            
            if row:
                return {
                    'id': row[0],
                    'primary_identifier': row[1],
                    'entity_type': row[2],
                    'confidence_score': row[3],
                    'risk_score': row[4],
                    'identifiers': json.loads(row[5]) if row[5] else {},
                    'attributes': json.loads(row[6]) if row[6] else {},
                    'created_at': row[7],
                    'updated_at': row[8],
                }
            return None
        except Exception as e:
            logger.error(f"Error getting entity: {e}")
            return None
    
    def get_entity_evidence(self, entity_id):
        """
        Get all evidence for an entity
        
        Args:
            entity_id: ID of the entity
        
        Returns:
            list: List of evidence records
        """
        try:
            self.cursor.execute('''
                SELECT * FROM evidence WHERE entity_id = ? ORDER BY score DESC
            ''', (entity_id,))
            return self.cursor.fetchall()
        except Exception as e:
            logger.error(f"Error getting entity evidence: {e}")
            return []
    
    def close(self):
        """Close database connection"""
        self.conn.close()
        logger.debug("Database connection closed")


