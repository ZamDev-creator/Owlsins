"""
Image Uploader Utility - Parallel Upload to Multiple Free Services
Compatible with Termux - No heavy dependencies
"""

import os
import requests
from pathlib import Path
from typing import Optional
from concurrent.futures import ThreadPoolExecutor, as_completed
from PIL import Image
import io
import tempfile

from utils.logger import setup_logger

logger = setup_logger(__name__)


class ImageUploader:
    """Upload images to free hosting services with parallel processing"""
    
    def __init__(self):
        """Initialize uploader"""
        self.timeout = 10  # Timeout per service
        
    def upload_parallel(self, image_path: str, max_workers: int = 3) -> Optional[str]:
        """
        Upload image to multiple services in parallel, return first success
        
        Args:
            image_path: Path to image file
            max_workers: Number of parallel uploads
            
        Returns:
            str: Public URL of uploaded image or None
        """
        logger.info(f"[UPLOAD] Starting parallel upload: {Path(image_path).name}")
        
        # Optimize image first if needed
        optimized_path = self._optimize_image(image_path)
        
        # List of upload services (sorted by speed/reliability)
        upload_services = [
            self._upload_tmpfiles,
            self._upload_0x0,
            self._upload_catbox
        ]
        
        # Try parallel upload
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = {
                executor.submit(func, optimized_path): func.__name__ 
                for func in upload_services
            }
            
            for future in as_completed(futures, timeout=30):
                try:
                    url = future.result(timeout=15)
                    if url and self._verify_url(url):
                        logger.info(f"[UPLOAD] ✓ Success via {futures[future]}")
                        self._cleanup_temp(optimized_path, image_path)
                        return url
                except Exception as e:
                    logger.debug(f"[UPLOAD] {futures[future]} failed: {e}")
                    continue
        
        logger.warning("[UPLOAD] All upload services failed")
        self._cleanup_temp(optimized_path, image_path)
        return None
    
    def _optimize_image(self, image_path: str, max_size: int = 800, quality: int = 75) -> str:
        """
        Optimize image for faster upload (resize if > 500KB)
        
        Args:
            image_path: Original image path
            max_size: Max dimension (width/height)
            quality: JPEG quality (1-100)
            
        Returns:
            str: Path to optimized image (or original if no optimization needed)
        """
        try:
            file_size = Path(image_path).stat().st_size
            
            # Skip if already small
            if file_size < 512 * 1024:  # < 500KB
                logger.debug("[UPLOAD] Image already optimized, skipping resize")
                return image_path
            
            logger.info(f"[UPLOAD] Optimizing image: {file_size / 1024:.1f}KB → target <500KB")
            
            # Open and resize
            img = Image.open(image_path)
            
            # Calculate new size maintaining aspect ratio
            ratio = min(max_size / img.width, max_size / img.height)
            if ratio < 1:
                new_size = (int(img.width * ratio), int(img.height * ratio))
                img = img.resize(new_size, Image.Resampling.LANCZOS)
            
            # Convert to RGB if needed
            if img.mode in ('RGBA', 'P', 'LA'):
                bg = Image.new('RGB', img.size, (255, 255, 255))
                if img.mode == 'P':
                    img = img.convert('RGBA')
                bg.paste(img, mask=img.split()[-1] if img.mode in ('RGBA', 'LA') else None)
                img = bg
            
            # Save to temp file
            temp_fd, temp_path = tempfile.mkstemp(suffix='.jpg')
            os.close(temp_fd)
            
            img.save(temp_path, 'JPEG', quality=quality, optimize=True)
            
            new_size = Path(temp_path).stat().st_size
            logger.info(f"[UPLOAD] Optimized: {new_size / 1024:.1f}KB (saved {(file_size - new_size) / 1024:.1f}KB)")
            
            return temp_path
            
        except Exception as e:
            logger.error(f"[UPLOAD] Optimization failed: {e}, using original")
            return image_path
    
    def _upload_tmpfiles(self, image_path: str) -> Optional[str]:
        """
        Upload to tmpfiles.org (24h retention, no registration)
        
        Args:
            image_path: Path to image
            
        Returns:
            str: Public URL or None
        """
        try:
            logger.debug("[UPLOAD] Trying tmpfiles.org...")
            
            with open(image_path, 'rb') as f:
                files = {'file': (Path(image_path).name, f, 'image/jpeg')}
                response = requests.post(
                    'https://tmpfiles.org/api/v1/upload',
                    files=files,
                    timeout=self.timeout
                )
            
            if response.status_code == 200:
                data = response.json()
                if data.get('status') == 'success':
                    url = data['data']['url']
                    # Fix tmpfiles URL format
                    url = url.replace('tmpfiles.org/', 'tmpfiles.org/dl/')
                    logger.debug(f"[UPLOAD] tmpfiles.org: {url}")
                    return url
            
            return None
            
        except Exception as e:
            logger.debug(f"[UPLOAD] tmpfiles.org error: {e}")
            return None
    
    def _upload_0x0(self, image_path: str) -> Optional[str]:
        """
        Upload to 0x0.st (365 days retention, no registration)
        
        Args:
            image_path: Path to image
            
        Returns:
            str: Public URL or None
        """
        try:
            logger.debug("[UPLOAD] Trying 0x0.st...")
            
            with open(image_path, 'rb') as f:
                files = {'file': (Path(image_path).name, f)}
                response = requests.post(
                    'https://0x0.st',
                    files=files,
                    timeout=self.timeout
                )
            
            if response.status_code == 200:
                url = response.text.strip()
                if url.startswith('http'):
                    logger.debug(f"[UPLOAD] 0x0.st: {url}")
                    return url
            
            return None
            
        except Exception as e:
            logger.debug(f"[UPLOAD] 0x0.st error: {e}")
            return None
    
    def _upload_catbox(self, image_path: str) -> Optional[str]:
        """
        Upload to catbox.moe (permanent storage, no registration)
        
        Args:
            image_path: Path to image
            
        Returns:
            str: Public URL or None
        """
        try:
            logger.debug("[UPLOAD] Trying catbox.moe...")
            
            with open(image_path, 'rb') as f:
                files = {
                    'reqtype': (None, 'fileupload'),
                    'fileToUpload': (Path(image_path).name, f, 'image/jpeg')
                }
                response = requests.post(
                    'https://catbox.moe/user/api.php',
                    files=files,
                    timeout=self.timeout
                )
            
            if response.status_code == 200:
                url = response.text.strip()
                if url.startswith('http'):
                    logger.debug(f"[UPLOAD] catbox.moe: {url}")
                    return url
            
            return None
            
        except Exception as e:
            logger.debug(f"[UPLOAD] catbox.moe error: {e}")
            return None
    
    def _verify_url(self, url: str, timeout: int = 5) -> bool:
        """
        Verify uploaded URL is accessible
        
        Args:
            url: URL to verify
            timeout: Request timeout
            
        Returns:
            bool: True if accessible
        """
        try:
            response = requests.head(url, timeout=timeout, allow_redirects=True)
            return response.status_code == 200
        except:
            return False
    
    def _cleanup_temp(self, optimized_path: str, original_path: str):
        """Clean up temporary optimized file"""
        try:
            if optimized_path != original_path and Path(optimized_path).exists():
                Path(optimized_path).unlink()
                logger.debug("[UPLOAD] Cleaned up temp file")
        except Exception as e:
            logger.debug(f"[UPLOAD] Cleanup error: {e}")


# Standalone helper function
def upload_image_fast(image_path: str) -> Optional[str]:
    """
    Quick function to upload image and get public URL
    
    Args:
        image_path: Path to image file
        
    Returns:
        str: Public URL or None if all failed
    """
    uploader = ImageUploader()
    return uploader.upload_parallel(image_path)
