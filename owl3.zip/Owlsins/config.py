"""
Configuration file for OSINT Suite
Contains all settings, paths, and constants
"""

import os
from pathlib import Path
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# ============================================================================
# BASE PATHS
# ============================================================================

BASE_DIR = Path(__file__).parent
DATA_DIR = BASE_DIR / "data"
OUTPUT_DIR = BASE_DIR / "output"
REPORTS_DIR = OUTPUT_DIR / "reports"
SCREENSHOTS_DIR = OUTPUT_DIR / "screenshots"
LOGS_DIR = OUTPUT_DIR / "logs"

# Create directories if they don't exist
for directory in [DATA_DIR, OUTPUT_DIR, REPORTS_DIR, SCREENSHOTS_DIR, LOGS_DIR]:
    directory.mkdir(parents=True, exist_ok=True)

# ============================================================================
# API KEYS (Optional - from environment variables)
# ============================================================================

HIBP_API_KEY = os.getenv("HIBP_API_KEY", "")  # Have I Been Pwned
HUNTER_IO_KEY = os.getenv("HUNTER_IO_KEY", "")  # Hunter.io for email verification
SEARCHAPI_KEY = "MMuuVWQEumiQoHm96eVDWwkS"

# IMPROVED: API keys untuk reverse search alternatif
BING_VISUAL_SEARCH_KEY = os.getenv("BING_VISUAL_SEARCH_KEY", "")  # Bing Visual Search (1000 free/month)
TINEYE_API_KEY = os.getenv("TINEYE_API_KEY", "")  # TinEye API
TINEYE_PRIVATE_KEY = os.getenv("TINEYE_PRIVATE_KEY", "")  # TinEye Private Key
# ============================================================================
# DATABASE
# ============================================================================

DB_PATH = BASE_DIR / "osint_data.db"

# ============================================================================
# NETWORK SETTINGS
# ============================================================================

MAX_WORKERS = 10  # For concurrent requests
REQUEST_TIMEOUT = 10  # seconds
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"

# ============================================================================
# EMAIL VALIDATION
# ============================================================================

EMAIL_REGEX = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'

# ============================================================================
# CHANGE MONITOR SETTINGS
# ============================================================================

MONITOR_INTERVAL = 300  # seconds (5 minutes)
MAX_CONTENT_SIZE = 5 * 1024 * 1024  # 5MB

# ============================================================================
# LOGGING SETTINGS
# ============================================================================

LOG_LEVEL = "INFO"  # DEBUG, INFO, WARNING, ERROR, CRITICAL
LOG_FORMAT = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
LOG_DATE_FORMAT = '%Y-%m-%d %H:%M:%S'

# ============================================================================
# ADVANCED OSINT - CONFIDENCE SCORING
# ============================================================================

# Confidence thresholds
CONFIDENCE_VERY_LOW = 0.3
CONFIDENCE_LOW = 0.5
CONFIDENCE_MEDIUM = 0.7
CONFIDENCE_HIGH = 0.85
CONFIDENCE_VERY_HIGH = 0.95

# Minimum confidence for reporting
MIN_CONFIDENCE_REPORT = 0.5

# Evidence weights (how much each type of evidence contributes)
EVIDENCE_WEIGHT_USERNAME_FOUND = 0.20
EVIDENCE_WEIGHT_PROFILE_COMPLETE = 0.35
EVIDENCE_WEIGHT_EMAIL_VALIDATED = 0.40
EVIDENCE_WEIGHT_IMAGE_MATCH = 0.45
EVIDENCE_WEIGHT_BREACH_FOUND = 0.25
EVIDENCE_WEIGHT_CORRELATION = 0.30

# Source reliability (how much to trust each source)
SOURCE_RELIABILITY_API_OFFICIAL = 0.95
SOURCE_RELIABILITY_API_THIRD_PARTY = 0.80
SOURCE_RELIABILITY_WEB_SCRAPE = 0.65
SOURCE_RELIABILITY_HEURISTIC = 0.60
SOURCE_RELIABILITY_INFERENCE = 0.40

# ============================================================================
# ADVANCED OSINT - CORRELATION ENGINE
# ============================================================================

# Minimum similarity for correlations
MIN_IMAGE_HASH_SIMILARITY = 0.90
MIN_USERNAME_PATTERN_SIMILARITY = 0.70
MIN_DOMAIN_CORRELATION = 0.75

# Correlation weights
CORRELATION_WEIGHT_IMAGE_EXACT = 0.85
CORRELATION_WEIGHT_IMAGE_SIMILAR = 0.65
CORRELATION_WEIGHT_EMAIL_DOMAIN = 0.70
CORRELATION_WEIGHT_USERNAME_PATTERN = 0.60
CORRELATION_WEIGHT_BIO_KEYWORD = 0.50

# ============================================================================
# ADVANCED OSINT - HEURISTIC DETECTION
# ============================================================================

# Enable heuristic detection (goes beyond status codes)
ENABLE_HEURISTICS = True

# Minimum signals needed for heuristic positive
MIN_POSITIVE_SIGNALS = 2
MIN_PROFILE_INDICATORS = 1

# Profile completeness weights
PROFILE_WEIGHT_AVATAR = 0.20
PROFILE_WEIGHT_BIO = 0.20
PROFILE_WEIGHT_POSTS = 0.25
PROFILE_WEIGHT_FOLLOWERS = 0.20
PROFILE_WEIGHT_VERIFIED = 0.15
