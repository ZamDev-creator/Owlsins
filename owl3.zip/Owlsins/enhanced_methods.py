#!/usr/bin/env python3
"""
Enhanced methods for main.py
Copy these methods to replace the existing ones in main.py
"""

def phone_osint_analysis_enhanced(self):
    """Enhanced Phone OSINT module interface with better reporting"""
    self.print_module_header("📱 PHONE NUMBER OSINT")
    
    phone = questionary.text(
        "Enter phone number (with country code):",
        validate=lambda text: len(text) > 0 or "Phone number cannot be empty"
    ).ask()
    
    if not phone:
        return
    
    print(colored(f"\n📞 Analyzing phone number '{phone}'...\n", "cyan"))
    
    try:
        # Perform phone analysis
        results = self.phone_osint.get_phone_info(phone)
        
        # Display results
        if results.get('valid'):
            print(colored("✅ PHONE NUMBER VALIDATION:", "cyan", attrs=["bold"]))
            print(colored("  Status: Valid", "blue"))
            print()
            
            # Basic Information
            info = results.get('info', {})
            if info:
                print(colored("📋 BASIC INFORMATION:", "cyan", attrs=["bold"]))
                
                # Country info
                country_info = info.get('country_code', {})
                if isinstance(country_info, dict):
                    print(f"  Country: {colored(country_info.get('country', 'N/A'), 'blue')}")
                    print(f"  Country Code: {colored(country_info.get('code', 'N/A'), 'blue')}")
                else:
                    print(f"  Country Code: {colored(str(country_info), 'blue')}")
                
                # Type and carrier
                print(f"  Number Type: {colored(info.get('number_type', 'N/A'), 'blue')}")
                print(f"  Carrier: {colored(info.get('carrier', 'N/A'), 'blue')}")
                print(f"  Location: {colored(info.get('location', 'N/A'), 'blue')}")
                
                # Timezones
                timezones = info.get('timezones', [])
                if timezones and timezones[0] != 'Unknown':
                    print(f"  Timezone(s): {colored(', '.join(timezones), 'blue')}")
                
                print()
                
                # Formatted Numbers
                formatted = info.get('formatted')
                if isinstance(formatted, dict):
                    print(colored("📝 FORMATTED NUMBERS:", "cyan", attrs=["bold"]))
                    for fmt_type, fmt_value in formatted.items():
                        print(f"  {fmt_type.title()}: {colored(fmt_value, 'blue')}")
                    print()
                elif formatted:
                    print(colored("📝 FORMATTED NUMBER:", "cyan", attrs=["bold"]))
                    print(f"  {colored(formatted, 'blue')}")
                    print()
            
            # Advanced Information
            advanced_info = results.get('advanced_info', {})
            if advanced_info:
                spam_check = advanced_info.get('spam_check', {})
                if spam_check.get('checked'):
                    print(colored("🛡️ SPAM ANALYSIS:", "cyan", attrs=["bold"]))
                    if spam_check.get('is_spam'):
                        print(colored("  ⚠️ WARNING: Number reported as spam!", "red", attrs=["bold"]))
                        print(f"  Reports: {colored(str(spam_check.get('reports', 0)), 'red')}")
                    else:
                        print(colored("  ✅ No spam reports found", "blue"))
                    print()
            
            # Social Media Links
            social_media = results.get('social_media', {})
            if social_media:
                print(colored("🔗 SOCIAL MEDIA PRESENCE:", "cyan", attrs=["bold"]))
                print("  Check these platforms:")
                for platform, info in social_media.items():
                    if platform != 'note' and isinstance(info, dict):
                        url = info.get('url', info.get('check_url', '#'))
                        print(f"  • {colored(platform.upper(), 'magenta')}: {colored(url, 'blue')}")
                print()
            
            # Ask for report generation
            report_format = questionary.select(
                "\n📄 Generate report?",
                choices=[
                    "HTML Report",
                    "PDF Report (if available)",
                    "Both",
                    "Skip"
                ]
            ).ask()
            
            if report_format and report_format != "Skip":
                try:
                    # Import enhanced report generator
                    from utils.report_generator_enhanced import EnhancedReportGenerator
                    enhanced_gen = EnhancedReportGenerator()
                    
                    if report_format == "HTML Report":
                        report_path = enhanced_gen.generate_phone_report(phone, results, format='html')
                        print(colored(f"\n📄 HTML Report saved: {report_path}", "magenta"))
                    elif report_format == "PDF Report (if available)":
                        report_path = enhanced_gen.generate_phone_report(phone, results, format='pdf')
                        print(colored(f"\n📄 Report saved: {report_path}", "magenta"))
                    elif report_format == "Both":
                        html_path = enhanced_gen.generate_phone_report(phone, results, format='html')
                        pdf_path = enhanced_gen.generate_phone_report(phone, results, format='pdf')
                        print(colored(f"\n📄 HTML Report: {html_path}", "magenta"))
                        print(colored(f"📄 PDF Report: {pdf_path}", "magenta"))
                except ImportError:
                    # Fallback to regular report
                    report_path = self.report_gen.generate_phone_report(phone, results)
                    print(colored(f"\n📄 Report saved: {report_path}", "magenta"))
        else:
            print(colored(f"❌ Invalid phone number: {results.get('error', 'Unknown error')}", "red"))
    
    except Exception as e:
        logger.error(f"Error during phone analysis: {e}")
        print(colored(f"\n❌ An error occurred: {e}", "red"))
    
    self.wait_for_continue()


def ip_geolocation_analysis_enhanced(self):
    """Enhanced IP Geolocation module interface"""
    self.print_module_header("🌐 IP ADDRESS GEOLOCATION")
    
    action = questionary.select(
        "What would you like to do?",
        choices=[
            "Lookup specific IP address",
            "Get my public IP",
            "Bulk IP lookup from file",
            "Check VPN/Proxy detection",
            "Back to main menu"
        ]
    ).ask()
    
    if action == "Back to main menu":
        return
    
    try:
        if action == "Get my public IP":
            print(colored("\n🔍 Getting your public IP address...", "cyan"))
            my_ip = self.ip_geo.get_my_ip()
            if my_ip:
                print(colored(f"\n✅ Your IP: {my_ip}", "blue", attrs=["bold"]))
                
                # Ask if they want to lookup this IP
                lookup = questionary.confirm("Lookup detailed information for this IP?", default=True).ask()
                if lookup:
                    results = self.ip_geo.get_ip_info(my_ip)
                    self._display_ip_results(my_ip, results)
            else:
                print(colored("❌ Failed to get public IP", "red"))
        
        elif action == "Lookup specific IP address":
            ip_address = questionary.text(
                "Enter IP address:",
                validate=lambda text: len(text) > 0 or "IP address cannot be empty"
            ).ask()
            
            if ip_address:
                print(colored(f"\n🔍 Looking up IP: {ip_address}...\n", "cyan"))
                results = self.ip_geo.get_ip_info(ip_address)
                self._display_ip_results(ip_address, results)
        
        elif action == "Check VPN/Proxy detection":
            ip_address = questionary.text(
                "Enter IP address to check:",
                validate=lambda text: len(text) > 0 or "IP address cannot be empty"
            ).ask()
            
            if ip_address:
                print(colored(f"\n🔍 Checking VPN/Proxy for: {ip_address}...\n", "cyan"))
                vpn_results = self.ip_geo.check_vpn_proxy(ip_address)
                
                print(colored("🛡️ VPN/PROXY DETECTION:", "cyan", attrs=["bold"]))
                
                risk_score = vpn_results.get('risk_score', 0)
                risk_color = 'blue' if risk_score < 30 else 'yellow' if risk_score < 50 else 'red'
                
                print(f"  Risk Score: {colored(str(risk_score), risk_color)}")
                print(f"  VPN: {colored('Yes' if vpn_results.get('is_vpn') else 'No', 'red' if vpn_results.get('is_vpn') else 'blue')}")
                print(f"  Proxy: {colored('Yes' if vpn_results.get('is_proxy') else 'No', 'red' if vpn_results.get('is_proxy') else 'blue')}")
                print(f"  Tor: {colored('Yes' if vpn_results.get('is_tor') else 'No', 'red' if vpn_results.get('is_tor') else 'blue')}")
                print(f"  Hosting: {colored('Yes' if vpn_results.get('is_hosting') else 'No', 'yellow' if vpn_results.get('is_hosting') else 'blue')}")
                print(f"  Type: {colored(vpn_results.get('type', 'Unknown'), 'blue')}")
                print()
        
        elif action == "Bulk IP lookup from file":
            file_path = questionary.path(
                "Enter path to file (one IP per line):"
            ).ask()
            
            if file_path and Path(file_path).exists():
                with open(file_path, 'r') as f:
                    ip_list = [line.strip() for line in f if line.strip()]
                
                print(colored(f"\n🔍 Looking up {len(ip_list)} IP addresses...\n", "cyan"))
                results = self.ip_geo.bulk_ip_lookup(ip_list)
                
                # Display summary
                valid_count = sum(1 for r in results if r.get('valid'))
                print(colored(f"✅ Successfully looked up {valid_count}/{len(ip_list)} IPs", "blue"))
                
                # Ask to save results
                save = questionary.confirm("Save results to file?", default=True).ask()
                if save:
                    import json
                    output_file = OUTPUT_DIR / f'bulk_ip_results_{datetime.now().strftime("%Y%m%d_%H%M%S")}.json'
                    with open(output_file, 'w') as f:
                        json.dump(results, f, indent=2)
                    print(colored(f"\n📄 Results saved: {output_file}", "magenta"))
    
    except Exception as e:
        logger.error(f"Error during IP geolocation: {e}")
        print(colored(f"\n❌ An error occurred: {e}", "red"))
    
    self.wait_for_continue()


def _display_ip_results(self, ip: str, results: Dict):
    """Helper method to display IP lookup results"""
    if results.get('valid'):
        info = results.get('info', {})
        
        print(colored("📍 LOCATION INFORMATION:", "cyan", attrs=["bold"]))
        print(f"  Country: {colored(info.get('country', 'N/A'), 'blue')}")
        print(f"  Region: {colored(info.get('region', 'N/A'), 'blue')}")
        print(f"  City: {colored(info.get('city', 'N/A'), 'blue')}")
        print(f"  ZIP: {colored(info.get('zip', 'N/A'), 'blue')}")
        print(f"  Timezone: {colored(info.get('timezone', 'N/A'), 'blue')}")
        print()
        
        print(colored("🗺️ COORDINATES:", "cyan", attrs=["bold"]))
        print(f"  Latitude: {colored(str(info.get('latitude', 'N/A')), 'blue')}")
        print(f"  Longitude: {colored(str(info.get('longitude', 'N/A')), 'blue')}")
        
        maps_url = info.get('maps_url')
        if maps_url:
            print(f"  🗺️ Map: {colored(maps_url, 'magenta')}")
        print()
        
        print(colored("🌐 NETWORK INFORMATION:", "cyan", attrs=["bold"]))
        print(f"  ISP: {colored(info.get('isp', 'N/A'), 'blue')}")
        print(f"  Organization: {colored(info.get('organization', 'N/A'), 'blue')}")
        print(f"  AS: {colored(info.get('as', 'N/A'), 'blue')}")
        print()
        
        print(colored("🛡️ SECURITY FLAGS:", "cyan", attrs=["bold"]))
        print(f"  Mobile: {colored('Yes' if info.get('mobile') else 'No', 'blue')}")
        print(f"  Proxy: {colored('Yes' if info.get('proxy') else 'No', 'red' if info.get('proxy') else 'blue')}")
        print(f"  Hosting: {colored('Yes' if info.get('hosting') else 'No', 'yellow' if info.get('hosting') else 'blue')}")
        print()
        
        # Ask for report generation
        report_format = questionary.select(
            "\n📄 Generate report?",
            choices=[
                "HTML Report",
                "PDF Report (if available)",
                "Both",
                "Skip"
            ]
        ).ask()
        
        if report_format and report_format != "Skip":
            try:
                from utils.report_generator_enhanced import EnhancedReportGenerator
                enhanced_gen = EnhancedReportGenerator()
                
                if report_format == "HTML Report":
                    report_path = enhanced_gen.generate_ip_report(ip, results, format='html')
                    print(colored(f"\n📄 HTML Report saved: {report_path}", "magenta"))
                elif report_format == "PDF Report (if available)":
                    report_path = enhanced_gen.generate_ip_report(ip, results, format='pdf')
                    print(colored(f"\n📄 Report saved: {report_path}", "magenta"))
                elif report_format == "Both":
                    html_path = enhanced_gen.generate_ip_report(ip, results, format='html')
                    pdf_path = enhanced_gen.generate_ip_report(ip, results, format='pdf')
                    print(colored(f"\n📄 HTML Report: {html_path}", "magenta"))
                    print(colored(f"📄 PDF Report: {pdf_path}", "magenta"))
            except ImportError:
                report_path = self.report_gen.generate_ip_report(ip, results)
                print(colored(f"\n📄 Report saved: {report_path}", "magenta"))
    else:
        print(colored(f"❌ Invalid IP address: {results.get('error', 'Unknown error')}", "red"))


def blockchain_tracking_enhanced(self):
    """Enhanced Blockchain address tracking module"""
    self.print_module_header("₿ BLOCKCHAIN ADDRESS TRACKER")
    
    address = questionary.text(
        "Enter cryptocurrency address:",
        validate=lambda text: len(text) > 0 or "Address cannot be empty"
    ).ask()
    
    if not address:
        return
    
    print(colored(f"\n🔍 Analyzing blockchain address...\n", "cyan"))
    
    try:
        # Auto-detect and track address
        results = self.blockchain.track_address(address)
        
        crypto_type = results.get('detected_type', results.get('type', 'unknown'))
        print(colored(f"🔍 Detected Type: {crypto_type.upper()}", "blue", attrs=["bold"]))
        print()
        
        if results.get('success'):
            info = results.get('info', {})
            
            print(colored("💰 BALANCE & ACTIVITY:", "cyan", attrs=["bold"]))
            
            # Display balance based on cryptocurrency type
            if 'final_balance' in info:
                print(f"  Current Balance: {colored(f'{info["final_balance"]:,.8f} BTC', 'blue')}")
                print(f"  Total Received: {colored(f'{info.get("total_received", 0):,.8f} BTC', 'blue')}")
                print(f"  Total Sent: {colored(f'{info.get("total_sent", 0):,.8f} BTC', 'blue')}")
            elif 'balance' in info:
                print(f"  Current Balance: {colored(f'{info["balance"]:,.8f} ETH', 'blue')}")
            
            if 'total_transactions' in info or 'n_tx' in info:
                tx_count = info.get('total_transactions', info.get('n_tx', 0))
                print(f"  Total Transactions: {colored(f'{tx_count:,}', 'blue')}")
            print()
            
            # Recent transactions
            transactions = results.get('recent_transactions', [])
            if transactions:
                print(colored("📊 RECENT TRANSACTIONS:", "cyan", attrs=["bold"]))
                for i, tx in enumerate(transactions[:5], 1):
                    if isinstance(tx, dict):
                        tx_hash = tx.get('hash', tx.get('txid', 'N/A'))
                        print(f"  {i}. {tx_hash[:16]}... (Block: {tx.get('block_height', tx.get('block', 'N/A'))})")
                print()
            
            # Explorer links
            explorer_links = results.get('explorer_links', {})
            if explorer_links:
                print(colored("🔗 BLOCKCHAIN EXPLORERS:", "cyan", attrs=["bold"]))
                for name, url in explorer_links.items():
                    display_name = name.replace('_', ' ').title()
                    print(f"  • {display_name}: {colored(url, 'magenta')}")
                print()
            
            # Ask for report generation
            report_format = questionary.select(
                "\n📄 Generate report?",
                choices=[
                    "HTML Report",
                    "PDF Report (if available)",
                    "Both",
                    "Skip"
                ]
            ).ask()
            
            if report_format and report_format != "Skip":
                try:
                    from utils.report_generator_enhanced import EnhancedReportGenerator
                    enhanced_gen = EnhancedReportGenerator()
                    
                    if report_format == "HTML Report":
                        report_path = enhanced_gen.generate_blockchain_report(address, results, format='html')
                        print(colored(f"\n📄 HTML Report saved: {report_path}", "magenta"))
                    elif report_format == "PDF Report (if available)":
                        report_path = enhanced_gen.generate_blockchain_report(address, results, format='pdf')
                        print(colored(f"\n📄 Report saved: {report_path}", "magenta"))
                    elif report_format == "Both":
                        html_path = enhanced_gen.generate_blockchain_report(address, results, format='html')
                        pdf_path = enhanced_gen.generate_blockchain_report(address, results, format='pdf')
                        print(colored(f"\n📄 HTML Report: {html_path}", "magenta"))
                        print(colored(f"📄 PDF Report: {pdf_path}", "magenta"))
                except ImportError:
                    # Fallback if enhanced generator not available
                    print(colored("\n⚠️ Enhanced report generator not available", "yellow"))
        else:
            error_msg = results.get('error', 'Unable to track address')
            print(colored(f"⚠️ {error_msg}", "yellow"))
            
            # Still show explorer links if available
            explorer_links = results.get('explorer_links', {})
            if explorer_links:
                print(colored("\n🔗 You can view this address on:", "cyan"))
                for name, url in explorer_links.items():
                    display_name = name.replace('_', ' ').title()
                    print(f"  • {display_name}: {colored(url, 'magenta')}")
    
    except Exception as e:
        logger.error(f"Error during blockchain tracking: {e}")
        print(colored(f"\n❌ An error occurred: {e}", "red"))
    
    self.wait_for_continue()


def social_media_stalking_enhanced(self):
    """Enhanced Social media stalking module with API integration"""
    self.print_module_header("👁️ SOCIAL MEDIA STALKER")
    
    action = questionary.select(
        "Select stalking mode:",
        choices=[
            "Stalk TikTok profile",
            "Stalk Instagram profile",
            "Stalk both platforms (same username)",
            "Compare TikTok vs Instagram profiles",
            "Back to main menu"
        ]
    ).ask()
    
    if action == "Back to main menu":
        return
    
    try:
        if action == "Stalk TikTok profile":
            username = questionary.text(
                "Enter TikTok username (without @):",
                validate=lambda text: len(text) > 0 or "Username cannot be empty"
            ).ask()
            
            if username:
                print(colored(f"\n🔍 Stalking TikTok profile @{username}...\n", "cyan"))
                results = self.social_stalker.stalk_tiktok(username)
                self._display_social_results(results)
        
        elif action == "Stalk Instagram profile":
            username = questionary.text(
                "Enter Instagram username (without @):",
                validate=lambda text: len(text) > 0 or "Username cannot be empty"
            ).ask()
            
            if username:
                print(colored(f"\n🔍 Stalking Instagram profile @{username}...\n", "cyan"))
                results = self.social_stalker.stalk_instagram(username)
                self._display_social_results(results)
        
        elif action == "Stalk both platforms (same username)":
            username = questionary.text(
                "Enter username to search on both platforms:",
                validate=lambda text: len(text) > 0 or "Username cannot be empty"
            ).ask()
            
            if username:
                print(colored(f"\n🔍 Stalking @{username} on multiple platforms...\n", "cyan"))
                results = self.social_stalker.stalk_multi_platform(username)
                
                # Display results for each platform
                for platform, platform_results in results.get('platforms', {}).items():
                    print(colored(f"\n{'='*60}", "magenta"))
                    print(colored(f"  {platform.upper()}", "magenta", attrs=["bold"]))
                    print(colored(f"{'='*60}\n", "magenta"))
                    self._display_social_results(platform_results)
                
                # Summary
                found_on = results.get('found_on', 0)
                total_checked = results.get('total_checked', 0)
                print(colored(f"\n📊 SUMMARY:", "cyan", attrs=["bold"]))
                print(f"  Found on {colored(str(found_on), 'blue')} out of {total_checked} platforms")
        
        elif action == "Compare TikTok vs Instagram profiles":
            tt_username = questionary.text(
                "Enter TikTok username:"
            ).ask()
            
            ig_username = questionary.text(
                "Enter Instagram username:",
                default=tt_username
            ).ask()
            
            if tt_username and ig_username:
                print(colored(f"\n🔍 Comparing profiles...\n", "cyan"))
                results = self.social_stalker.compare_profiles(tt_username, ig_username)
                
                # Display TikTok results
                print(colored("TIKTOK PROFILE:", "magenta", attrs=["bold"]))
                self._display_social_results(results.get('tiktok', {}))
                
                # Display Instagram results
                print(colored("\nINSTAGRAM PROFILE:", "magenta", attrs=["bold"]))
                self._display_social_results(results.get('instagram', {}))
                
                # Display comparison
                comparison = results.get('comparison', {})
                if comparison:
                    print(colored("\n📊 COMPARISON:", "cyan", attrs=["bold"]))
                    
                    followers_comp = comparison.get('total_followers', {})
                    print(f"  Followers:")
                    print(f"    TikTok: {colored(f'{followers_comp.get("tiktok", 0):,}', 'blue')}")
                    print(f"    Instagram: {colored(f'{followers_comp.get("instagram", 0):,}', 'blue')}")
                    print(f"    Difference: {colored(f'{followers_comp.get("difference", 0):,}', 'yellow')}")
                    
                    verified = comparison.get('verified', {})
                    print(f"\n  Verification:")
                    print(f"    TikTok: {colored('Yes' if verified.get('tiktok') else 'No', 'blue')}")
                    print(f"    Instagram: {colored('Yes' if verified.get('instagram') else 'No', 'blue')}")
    
    except Exception as e:
        logger.error(f"Error during social media stalking: {e}")
        print(colored(f"\n❌ An error occurred: {e}", "red"))
    
    self.wait_for_continue()


def _display_social_results(self, results: Dict):
    """Helper method to display social media profile results"""
    if results.get('success'):
        profile = results.get('profile', {})
        platform = results.get('platform', 'unknown')
        
        print(colored(f"✅ Profile Found!", "blue", attrs=["bold"]))
        print()
        
        # Basic info
        print(colored("👤 PROFILE INFORMATION:", "cyan", attrs=["bold"]))
        print(f"  Username: {colored('@' + profile.get('username', 'N/A'), 'blue')}")
        print(f"  Name: {colored(profile.get('nickname', profile.get('full_name', 'N/A')), 'blue')}")
        print(f"  Verified: {colored('Yes ✓' if profile.get('verified') else 'No', 'blue')}")
        print(f"  Private: {colored('Yes 🔒' if profile.get('private') else 'No 🔓', 'blue')}")
        print()
        
        # Bio
        bio = profile.get('bio', 'No bio')
        if bio and bio != 'No bio':
            print(colored("📝 BIO:", "cyan", attrs=["bold"]))
            print(f"  {bio}")
            print()
        
        # Statistics
        print(colored("📊 STATISTICS:", "cyan", attrs=["bold"]))
        followers = profile.get('followers', 0)
        following = profile.get('following', 0)
        posts = profile.get('total_videos', profile.get('posts', 0))
        
        print(f"  👥 Followers: {colored(f'{followers:,}', 'blue')}")
        print(f"  👤 Following: {colored(f'{following:,}', 'blue')}")
        print(f"  📸 Posts: {colored(f'{posts:,}', 'blue')}")
        
        if profile.get('total_likes'):
            print(f"  ❤️ Total Likes: {colored(f'{profile["total_likes"]:,}', 'blue')}")
        print()
        
        # Profile links
        profile_url = profile.get('profile_url')
        if profile_url:
            print(colored("🔗 PROFILE LINK:", "cyan", attrs=["bold"]))
            print(f"  {colored(profile_url, 'magenta')}")
            print()
        
        # Ask for report generation
        report_format = questionary.select(
            "\n📄 Generate report?",
            choices=[
                "HTML Report",
                "PDF Report (if available)",
                "Both",
                "Skip"
            ]
        ).ask()
        
        if report_format and report_format != "Skip":
            try:
                from utils.report_generator_enhanced import EnhancedReportGenerator
                enhanced_gen = EnhancedReportGenerator()
                
                username = profile.get('username', 'unknown')
                
                if report_format == "HTML Report":
                    report_path = enhanced_gen.generate_social_stalker_report(username, results, format='html')
                    print(colored(f"\n📄 HTML Report saved: {report_path}", "magenta"))
                elif report_format == "PDF Report (if available)":
                    report_path = enhanced_gen.generate_social_stalker_report(username, results, format='pdf')
                    print(colored(f"\n📄 Report saved: {report_path}", "magenta"))
                elif report_format == "Both":
                    html_path = enhanced_gen.generate_social_stalker_report(username, results, format='html')
                    pdf_path = enhanced_gen.generate_social_stalker_report(username, results, format='pdf')
                    print(colored(f"\n📄 HTML Report: {html_path}", "magenta"))
                    print(colored(f"📄 PDF Report: {pdf_path}", "magenta"))
            except ImportError:
                print(colored("\n⚠️ Enhanced report generator not available", "yellow"))
    else:
        error_msg = results.get('error', 'Profile not found')
        print(colored(f"❌ {error_msg}", "red"))
        print()
