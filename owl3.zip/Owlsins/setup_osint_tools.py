#!/usr/bin/env python3
"""
Setup script for OSINT Image Tools
Downloads necessary files without compiling from source
"""

import os
import sys
import requests
from pathlib import Path

def download_file(url, destination):
    """Download file from URL to destination"""
    print(f"Downloading {destination}...")
    try:
        response = requests.get(url, stream=True, timeout=60)
        response.raise_for_status()
        
        destination = Path(destination)
        destination.parent.mkdir(parents=True, exist_ok=True)
        
        with open(destination, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                f.write(chunk)
        
        print(f"✓ Downloaded to {destination}")
        return True
    except Exception as e:
        print(f"✗ Failed to download: {e}")
        return False

def setup_cascades():
    """Download Haar Cascade files for face detection"""
    print("\n=== Setting up Face Detection Cascades ===")
    
    cascades = {
        'haarcascade_frontalface_alt.xml': 'https://raw.githubusercontent.com/opencv/opencv/master/data/haarcascades/haarcascade_frontalface_alt.xml',
        'haarcascade_frontalface_default.xml': 'https://raw.githubusercontent.com/opencv/opencv/master/data/haarcascades/haarcascade_frontalface_default.xml',
        'haarcascade_eye.xml': 'https://raw.githubusercontent.com/opencv/opencv/master/data/haarcascades/haarcascade_eye.xml'
    }
    
    cascade_dir = Path('data/cascades')
    cascade_dir.mkdir(parents=True, exist_ok=True)
    
    success_count = 0
    for filename, url in cascades.items():
        dest = cascade_dir / filename
        if dest.exists():
            print(f"✓ {filename} already exists")
            success_count += 1
        else:
            if download_file(url, dest):
                success_count += 1
    
    print(f"\n{success_count}/{len(cascades)} cascades ready")
    return success_count == len(cascades)

def create_directories():
    """Create necessary directories"""
    print("\n=== Creating directories ===")
    
    directories = [
        'data/cascades',
        'output/face_detection',
        'output/reports',
        'output/images'
    ]
    
    for directory in directories:
        Path(directory).mkdir(parents=True, exist_ok=True)
        print(f"✓ Created {directory}")

def check_dependencies():
    """Check if required packages are installed"""
    print("\n=== Checking dependencies ===")
    
    required = {
        'cv2': 'opencv-python-headless',
        'PIL': 'Pillow',
        'requests': 'requests',
        'numpy': 'numpy'
    }
    
    missing = []
    for module, package in required.items():
        try:
            __import__(module)
            print(f"✓ {package}")
        except ImportError:
            print(f"✗ {package} not installed")
            missing.append(package)
    
    if missing:
        print("\n⚠️  Missing packages. Install with:")
        print(f"pip install {' '.join(missing)} --break-system-packages")
        return False
    
    return True

def main():
    """Main setup function"""
    print("=" * 60)
    print("OSINT Image Tools Setup")
    print("=" * 60)
    
    # Create directories
    create_directories()
    
    # Check dependencies
    deps_ok = check_dependencies()
    
    # Download cascades
    cascades_ok = setup_cascades()
    
    print("\n" + "=" * 60)
    if deps_ok and cascades_ok:
        print("✅ Setup completed successfully!")
        print("\nYou can now use:")
        print("  • EXIF Extraction")
        print("  • Reverse Image Search")
        print("  • Face Detection")
        print("  • Location Recognition (requires API key)")
    else:
        print("⚠️  Setup completed with warnings")
        if not deps_ok:
            print("   - Some dependencies are missing")
        if not cascades_ok:
            print("   - Some cascade files failed to download")
    print("=" * 60)

if __name__ == '__main__':
    main()
