#!/bin/bash
# OWL OSINT Suite - Enhanced Edition - Installation Script
# Run this script to install all dependencies

echo "============================================================"
echo "🦉 OWL OSINT Suite - Enhanced Edition"
echo "Installation Script"
echo "============================================================"
echo ""

# Check Python version
echo "[1/5] Checking Python version..."
python3 --version
if [ $? -ne 0 ]; then
    echo "❌ Python 3 is not installed. Please install Python 3.8 or higher."
    exit 1
fi
echo "✅ Python is installed"
echo ""

# Install system dependencies (for PDF support)
echo "[2/5] Installing system dependencies..."
echo "Note: This may require sudo password"

if [[ "$OSTYPE" == "linux-gnu"* ]]; then
    echo "Detected Linux system"
    sudo apt-get update
    sudo apt-get install -y python3-pip python3-dev
    sudo apt-get install -y libpango-1.0-0 libpangoft2-1.0-0 libharfbuzz-dev libffi-dev libjpeg-dev libopenjp2-7-dev
    echo "✅ System dependencies installed"
elif [[ "$OSTYPE" == "darwin"* ]]; then
    echo "Detected macOS system"
    brew install python3 pango
    echo "✅ System dependencies installed"
else
    echo "⚠️  Unknown OS. Please install dependencies manually."
    echo "   See README_ENHANCED.md for details"
fi
echo ""

# Install Python packages
echo "[3/5] Installing Python packages..."
pip3 install -r requirements.txt --break-system-packages
if [ $? -ne 0 ]; then
    echo "⚠️  Some packages may have failed. Trying individually..."
    
    # Core packages
    pip3 install requests beautifulsoup4 pillow --break-system-packages
    pip3 install termcolor questionary pyfiglet tabulate tqdm --break-system-packages
    pip3 install aiohttp nest-asyncio --break-system-packages
    
    # Enhanced packages
    pip3 install phonenumbers --break-system-packages
    pip3 install weasyprint reportlab --break-system-packages
    
    echo "✅ Core packages installed (some optional packages may have failed)"
else
    echo "✅ All packages installed successfully"
fi
echo ""

# Create necessary directories
echo "[4/5] Creating directories..."
mkdir -p output/reports
mkdir -p output/screenshots
mkdir -p data
echo "✅ Directories created"
echo ""

# Test installation
echo "[5/5] Testing installation..."
python3 test_enhanced_features.py
echo ""

echo "============================================================"
echo "Installation Complete!"
echo "============================================================"
echo ""
echo "To run the tool:"
echo "  python3 main.py"
echo ""
echo "For detailed documentation, see:"
echo "  README_ENHANCED.md"
echo ""
echo "============================================================"
