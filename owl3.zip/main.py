#!/usr/bin/env python3
"""
OSINT Multi-Tool Suite
A comprehensive OSINT toolkit with interactive CLI

Main entry point for the application
"""

import asyncio
import sys
import os
from pathlib import Path
from typing import Optional

# Import UI libraries
import pyfiglet
from termcolor import colored
import questionary
from tabulate import tabulate

# Import modules
from modules.username_hunter import UsernameHunter
from modules.email_osint import EmailOSINT
from modules.image_metadata import ImageMetadata
from modules.change_monitor import ChangeMonitor
from modules.phone_osint import PhoneOSINT
from modules.ip_geolocation import IPGeolocation
from modules.blockchain_tracker import BlockchainTracker
from modules.social_stalker import SocialMediaStalker
from utils.report_generator import ReportGenerator
from utils.logger import setup_logger
from config import OUTPUT_DIR, SCREENSHOTS_DIR

# Import core systems for advanced OSINT
from core.entity import EntityManager
from core.confidence_scoring import ConfidenceScorer
from core.correlation_engine import CorrelationEngine

logger = setup_logger(__name__)

# ANSI Color Codes for custom banner
PURPLE = '\033[38;5;93m'
BRIGHT_PURPLE = '\033[38;5;129m'
DARK_PURPLE = '\033[38;5;54m'
LIGHT_PURPLE = '\033[38;5;141m'
CYAN = '\033[38;5;51m'
BRIGHT_CYAN = '\033[38;5;87m'
GRAY = '\033[38;5;245m'
DARK_GRAY = '\033[38;5;237m'
RESET = '\033[0m'


class OSINTSuite:
    """Main OSINT Suite application class"""
    
    def __init__(self):
        """Initialize all OSINT modules with core intelligence systems"""
        try:
            # Initialize core intelligence systems FIRST
            logger.info("Initializing core intelligence systems...")
            self.entity_manager = EntityManager()
            self.scorer = ConfidenceScorer()
            self.correlation_engine = CorrelationEngine(
                entity_manager=self.entity_manager,
                scorer=self.scorer
            )
            
            # Initialize modules with entity manager and scorer
            logger.info("Initializing OSINT modules...")
            self.username_hunter = UsernameHunter(
                entity_manager=self.entity_manager,
                scorer=self.scorer
            )
            self.email_osint = EmailOSINT()
            self.image_metadata = ImageMetadata()
            self.change_monitor = ChangeMonitor()
            self.phone_osint = PhoneOSINT()
            self.ip_geo = IPGeolocation()
            self.blockchain = BlockchainTracker()
            self.social_stalker = SocialMediaStalker()
            self.report_gen = ReportGenerator()
            
            logger.info("OSINT Suite initialized successfully with Entity Management")
        except Exception as e:
            logger.error(f"Failed to initialize OSINT Suite: {e}")
            raise
    
    def print_banner(self):
        """Print custom OWL ASCII banner with purple/blue theme"""
        banner = f"""
{DARK_PURPLE}╔═══════════════════════════════════════════════════════════════════════════╗
║{RESET}                                                                           {DARK_PURPLE}║
║{BRIGHT_PURPLE}                        .#@@@@@@@@@@@@@@@#.                            {DARK_PURPLE}║
║{BRIGHT_PURPLE}                    *@@@@@@@@@@@@@@@@@@@@@@@*                        {DARK_PURPLE}║
║{BRIGHT_PURPLE}                  #@@@@@@@@@@@@@@@@@@@@@@@@@@@#                      {DARK_PURPLE}║
║{LIGHT_PURPLE}                *@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*                    {DARK_PURPLE}║
║{LIGHT_PURPLE}               @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@                   {DARK_PURPLE}║
║{PURPLE}              @@@@@#*.             .             .*#@@@@@              {DARK_PURPLE}║
║{PURPLE}            .@@@@*.   .-=#@@@@=.   .   .=@@@@#=-.   .*@@@@.            {DARK_PURPLE}║
║{PURPLE}            @@@*.   .#@@@@@@@@@@@. . .@@@@@@@@@@@#.   .*@@@            {DARK_PURPLE}║
║{BRIGHT_PURPLE}           #@@*   .@@@@@@{CYAN}###{BRIGHT_PURPLE}@@@@@@. .@@@@@@{CYAN}###{BRIGHT_PURPLE}@@@@@@.   *@@#           {DARK_PURPLE}║
║{BRIGHT_PURPLE}          .@@#   *@@@@@@{CYAN}#{BRIGHT_CYAN}@@@{CYAN}#{BRIGHT_PURPLE}@@@@@.@@@@@{CYAN}#{BRIGHT_CYAN}@@@{CYAN}#{BRIGHT_PURPLE}@@@@@@*   #@@.          {DARK_PURPLE}║
║{BRIGHT_PURPLE}          *@@.  .@@@@@@@{CYAN}#{BRIGHT_CYAN}@@@{CYAN}#{BRIGHT_PURPLE}@@@@@@@@@@{CYAN}#{BRIGHT_CYAN}@@@{CYAN}#{BRIGHT_PURPLE}@@@@@@@.  .@@*          {DARK_PURPLE}║
║{BRIGHT_PURPLE}          @@@   #@@@@@@@@{CYAN}###{BRIGHT_PURPLE}@@@@@@@@@@@{CYAN}###{BRIGHT_PURPLE}@@@@@@@@#   @@@          {DARK_PURPLE}║
║{PURPLE}          @@@.  =@@@@@@@@@@@@@@*.{BRIGHT_CYAN}###.{PURPLE}*@@@@@@@@@@@@@@=  .@@@          {DARK_PURPLE}║
║{PURPLE}          #@@*   -@@@@@@@@@@@@@#.{BRIGHT_CYAN}###.{PURPLE}#@@@@@@@@@@@@@-   *@@#          {DARK_PURPLE}║
║{PURPLE}           @@@=    -*@@@@@@@@@@@#{BRIGHT_CYAN}####{PURPLE}#@@@@@@@@@@@*-    =@@@           {DARK_PURPLE}║
║{LIGHT_PURPLE}           *@@@#.     .=*#@@@@@@@@@@@@@@@@@#*=.     .#@@@*           {DARK_PURPLE}║
║{LIGHT_PURPLE}            .@@@@*.          :#{CYAN}#######{LIGHT_PURPLE}#:          .*@@@@.            {DARK_PURPLE}║
║{BRIGHT_PURPLE}              -@@@@@*:         {CYAN}########{BRIGHT_PURPLE}         :*@@@@@-              {DARK_PURPLE}║
║{BRIGHT_PURPLE}                :#@@@@#=:     {CYAN}#$#$#$#${BRIGHT_PURPLE}     :=#@@@@#:                {DARK_PURPLE}║
║{PURPLE}              .:**#@@@@@@@@@*:{CYAN}#$#$#$#${PURPLE}:*@@@@@@@@@#**:.              {DARK_PURPLE}║
║{PURPLE}            -*@@@@@@@@@@@@@@@#{CYAN}$#$#$#${PURPLE}#@@@@@@@@@@@@@@@*-            {DARK_PURPLE}║
║{PURPLE}           =@@@@@%{CYAN}*=---=*{PURPLE}%@@@@@#{CYAN}#$#$#{PURPLE}#@@@@@%{CYAN}*=---=*{PURPLE}%@@@@@=           {DARK_PURPLE}║
║{LIGHT_PURPLE}          *@@@@%{CYAN}=:     :={LIGHT_PURPLE}%@@@@#{CYAN}####{LIGHT_PURPLE}#@@@@%{CYAN}=:     :={LIGHT_PURPLE}%@@@@*          {DARK_PURPLE}║
║{LIGHT_PURPLE}          #@@@%{CYAN}-        -{LIGHT_PURPLE}%@@@@@@@@@@@@@%{CYAN}-        -{LIGHT_PURPLE}%@@@#          {DARK_PURPLE}║
║{BRIGHT_PURPLE}          *@@@%{CYAN}=.      .={BRIGHT_PURPLE}%@@@@@@@@@@@@@%{CYAN}=.      .={BRIGHT_PURPLE}%@@@*          {DARK_PURPLE}║
║{BRIGHT_PURPLE}           @@@@@%{CYAN}*====*{BRIGHT_PURPLE}%@@@@@@@@@@@@@@@@%{CYAN}*====*{BRIGHT_PURPLE}%@@@@@           {DARK_PURPLE}║
║{PURPLE}            =@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@=            {DARK_PURPLE}║
║{PURPLE}              -*@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*-              {DARK_PURPLE}║
║{DARK_PURPLE}                 .=*#@@@@@@@@@@@@@@@@@@#*=.                     ║
║{DARK_PURPLE}                       .:=*########*=:.                          ║
║{RESET}                                                                           {DARK_PURPLE}║
╠═══════════════════════════════════════════════════════════════════════════╣
║                                                                           ║
║{BRIGHT_PURPLE}    ███████╗ ██╗    ██╗ ██╗                                          {DARK_PURPLE}║
║{BRIGHT_PURPLE}   ██╔═══██╗ ██║    ██║ ██║          {BRIGHT_CYAN}  ███████╗  ██████╗ ██╗███╗  ██╗████████╗{DARK_PURPLE}║
║{PURPLE}   ██║   ██║ ██║ █╗ ██║ ██║          {CYAN} ██╔═══██╗██╔════╝ ██║████╗ ██║╚══██╔══╝{DARK_PURPLE}║
║{PURPLE}   ██║   ██║ ██║███╗██║ ██║          {CYAN} ██║   ██║╚█████╗  ██║██╔██╗██║   ██║   {DARK_PURPLE}║
║{DARK_PURPLE}   ██║   ██║ ██║╚██╔╝██║ ██║          {CYAN} ██║   ██║ ╚═══██╗ ██║██║╚████║   ██║   {DARK_PURPLE}║
║{DARK_PURPLE}   ╚██████╔╝ ╚███╔███╔╝ ███████╗      ╚██████╔╝██████╔╝ ██║██║ ╚███║   ██║   {DARK_PURPLE}║
║{DARK_PURPLE}    ╚═════╝   ╚══╝╚══╝  ╚══════╝       ╚═════╝ ╚═════╝  ╚═╝╚═╝  ╚══╝   ╚═╝   {DARK_PURPLE}║
║                                                                           ║
║{CYAN}        ┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓        {DARK_PURPLE}║
║{CYAN}        ┃   {BRIGHT_CYAN}Open Source Intelligence Framework{CYAN}           ┃        {DARK_PURPLE}║
║{BRIGHT_CYAN}        ┃   {CYAN}Advanced Reconnaissance & Analysis Suite{BRIGHT_CYAN}      ┃        {DARK_PURPLE}║
║{CYAN}        ┃   {BRIGHT_CYAN}Professional Edition v2.0 - 2026{CYAN}                ┃        {DARK_PURPLE}║
║{CYAN}        ┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛        {DARK_PURPLE}║
║                                                                           ║
║{PURPLE}     [{BRIGHT_PURPLE}$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$${PURPLE}]     {DARK_PURPLE}║
║{PURPLE}     [{BRIGHT_PURPLE}████████████████ BY ZAM DEV ████████████████████████{PURPLE}]     {DARK_PURPLE}║
║                                                                           ║
╚═══════════════════════════════════════════════════════════════════════════╝{RESET}
"""
        print(banner)
    
    def clear_screen(self):
        """Clear terminal screen"""
        os.system('clear' if os.name != 'nt' else 'cls')
    
    def print_module_header(self, title: str):
        """Print module header with purple/blue theme"""
        print("\n" + colored("=" * 70, "magenta"))
        print(colored(f"  {title}", "magenta", attrs=["bold"]))
        print(colored("=" * 70, "magenta") + "\n")
    
    def username_search(self):
        """Username hunter module interface with entity intelligence"""
        self.print_module_header("🔍 USERNAME HUNTER")
        
        username = questionary.text(
            "Enter username to search:",
            validate=lambda text: len(text) > 0 or "Username cannot be empty"
        ).ask()
        
        if not username:
            return
        
        print(colored(f"\n🔎 Hunting for '{username}' across platforms...\n", "cyan"))
        
        try:
            # Search with entity creation enabled
            results = self.username_hunter.search_username(
                username=username,
                platforms_to_check=None,  # Check all platforms
                create_entity=True  # CRITICAL: Enable entity creation
            )
            
            # Display basic results
            found = results['found_results']
            not_found_count = results['not_found_on']
            
            print(colored(f"\n✅ FOUND ON {len(found)} PLATFORMS:", "green", attrs=["bold"]))
            if found:
                table_data = []
                for r in sorted(found, key=lambda x: x['confidence'], reverse=True):
                    conf_emoji = "🟢" if r['confidence'] >= 0.85 else "🟡" if r['confidence'] >= 0.70 else "🟠"
                    table_data.append([
                        conf_emoji,
                        r['platform'],
                        f"{r['confidence']:.0%}",
                        r['method'],
                        r['url']
                    ])
                print(tabulate(table_data, 
                             headers=["", "Platform", "Confidence", "Method", "URL"], 
                             tablefmt="grid"))
            else:
                print("  No profiles found.")
            
            print(colored(f"\n❌ NOT FOUND ON {not_found_count} PLATFORMS", "white"))
            
            # Display INTELLIGENCE REPORT if entity was created
            if 'entity' in results:
                entity = results['entity']
                self._display_intelligence_report(entity, username)
                
                # Run correlation analysis
                print(colored("\n🔗 Running correlation analysis...", "cyan"))
                correlations = self.correlation_engine.analyze_entity(entity)
                
                if correlations:
                    self._display_correlations(correlations)
            
            # Generate report
            generate_report = questionary.confirm("Generate HTML report?", default=True).ask()
            if generate_report:
                report_path = self.report_gen.generate_username_report(username, results['results'])
                print(colored(f"\n📄 Report saved: {report_path}", "magenta"))
                
        except Exception as e:
            logger.error(f"Error during username search: {e}")
            print(colored(f"\n❌ An error occurred: {e}", "red"))
            import traceback
            traceback.print_exc()
        
        self.wait_for_continue()
    
    def _display_intelligence_report(self, entity, username: str):
        """Display detailed intelligence report for entity"""
        print(colored("\n" + "="*70, "magenta"))
        print(colored("  📊 INTELLIGENCE REPORT", "magenta", attrs=["bold"]))
        print(colored("="*70, "magenta"))
        
        conf_level = entity.get_confidence_level()
        conf_color = "green" if entity.confidence_score >= 0.7 else "yellow" if entity.confidence_score >= 0.5 else "red"
        
        print(colored(f"\nTarget: {username}", "cyan", attrs=["bold"]))
        print(colored(f"Confidence Score: {entity.confidence_score:.2%} [{conf_level.label}]", conf_color, attrs=["bold"]))
        print(f"Entity Type: {entity.entity_type}")
        print(f"Evidence Collected: {len(entity.evidence)} pieces")
        print(f"Evidence Types: {len(set(ev.evidence_type for ev in entity.evidence))}")
        
        # Show identifiers
        if entity.identifiers:
            print(colored("\n📋 Identifiers Found:", "cyan"))
            for id_type, values in entity.identifiers.items():
                print(f"  • {id_type}: {', '.join(values[:5])}")
                if len(values) > 5:
                    print(f"    ... and {len(values) - 5} more")
        
        # Show platforms
        if 'platforms' in entity.attributes:
            print(colored("\n🌐 Active Platforms:", "cyan"))
            platforms = entity.attributes['platforms']
            for platform, data in list(platforms.items())[:10]:
                completeness = data.get('completeness', 0)
                comp_bar = "█" * int(completeness * 10) + "░" * (10 - int(completeness * 10))
                print(f"  • {platform}: {data['confidence']:.0%} confidence | Profile: [{comp_bar}] {completeness:.0%}")
        
        # Show top evidence
        top_evidence = entity.get_top_evidence(5)
        if top_evidence:
            print(colored("\n🔍 Top Evidence:", "cyan"))
            for i, ev in enumerate(top_evidence, 1):
                print(f"  {i}. {ev.signal}")
                print(f"     Score: {ev.score():.2f} | Type: {ev.evidence_type.value} | Source: {ev.source}")
        
        # Show assessment
        print(colored("\n💡 Assessment:", "cyan"))
        if entity.confidence_score >= 0.85:
            print("  ✓ HIGH confidence - Strong evidence of same person across platforms")
        elif entity.confidence_score >= 0.70:
            print("  ⚠ MEDIUM-HIGH confidence - Likely same person, some inconsistencies")
        elif entity.confidence_score >= 0.50:
            print("  ⚠ MEDIUM confidence - Possible matches, needs verification")
        else:
            print("  ⚠ LOW confidence - Weak evidence, multiple people may use this username")
    
    def _display_correlations(self, correlations: list):
        """Display correlation findings"""
        if not correlations:
            print(colored("  No significant correlations found.", "white"))
            return
        
        print(colored("\n🔗 CORRELATIONS FOUND:", "magenta", attrs=["bold"]))
        for corr in correlations[:10]:  # Top 10
            print(f"\n  • {corr['type']}")
            
            # Use 'strength' instead of 'confidence' for correlations
            strength = corr.get('strength', 0.0)
            strength_emoji = "🟢" if strength >= 0.8 else "🟡" if strength >= 0.6 else "🟠"
            print(f"    {strength_emoji} Strength: {strength:.0%}")
            
            # Display evidence/details
            if 'evidence' in corr:
                print(f"    Evidence: {corr['evidence']}")
            elif 'details' in corr:
                print(f"    Details: {corr['details']}")
            
            # Display additional info based on type
            if corr['type'] == 'username_pattern' and 'usernames' in corr:
                print(f"    Usernames: {', '.join(corr['usernames'])}")
            elif corr['type'] == 'image_hash_match' and 'platforms' in corr:
                print(f"    Platforms: {', '.join(corr['platforms'])}")
            elif corr['type'] == 'email_domain_match' and 'domain' in corr:
                print(f"    Domain: {corr['domain']}")
            elif corr['type'] == 'consistency_check':
                status = corr.get('status', 'unknown')
                status_emoji = "✅" if status == 'consistent' else "⚠️"
                print(f"    {status_emoji} Status: {status}")

    
    def email_search(self):
        """Email OSINT module interface"""
        self.print_module_header("📧 EMAIL OSINT")
        
        email = questionary.text(
            "Enter email address to analyze:",
            validate=lambda text: '@' in text or "Invalid email format"
        ).ask()
        
        if not email:
            return
        
        print(colored(f"\n🔍 Analyzing '{email}'...\n", "cyan"))
        
        try:
            # Perform analysis
            results = self.email_osint.analyze_email(email)
            
            # Display results
            print(colored("📊 ANALYSIS RESULTS:", "cyan", attrs=["bold"]))
            print()
            
            status_icon = "✅" if results['valid_format'] else "❌"
            print(f"  {status_icon} Format Valid: {colored(str(results['valid_format']), 'green' if results['valid_format'] else 'red')}")
            
            disp_icon = "⚠️" if results['is_disposable'] else "✅"
            disp_color = "yellow" if results['is_disposable'] else "green"
            print(f"  {disp_icon} Disposable: {colored(str(results['is_disposable']), disp_color)}")
            
            if results.get('domain'):
                print(f"  🌐 Domain: {colored(results['domain'], 'cyan')}")
            
            if results.get('mx_records'):
                mx_status = results['mx_records'].get('has_mx', False)
                mx_icon = "✅" if mx_status else "❌"
                print(f"  {mx_icon} MX Records: {colored(str(mx_status), 'green' if mx_status else 'red')}")
            
            print()
            print(colored("🔒 BREACH STATUS:", "cyan", attrs=["bold"]))
            
            breach_info = results.get('breach_info', {})
            if breach_info.get('breached'):
                breach_count = breach_info.get('breach_count', 0)
                print(colored(f"  ⚠️ WARNING: Found in {breach_count} breach(es)!", "red", attrs=["bold"]))
                print(colored("  → Recommendation: Change passwords immediately!", "yellow"))
            else:
                status = breach_info.get('status', 'unknown')
                if status == 'no_api_key':
                    print(colored("  ℹ️  Breach check skipped (no API key)", "yellow"))
                else:
                    print(colored("  ✅ No breaches found", "green"))
            
            # Show confidence if entity was created
            if 'confidence' in results:
                print(colored(f"\n💯 Confidence Score: {results['confidence']:.2%}", "cyan"))
            
            # Generate report
            generate_report = questionary.confirm("\nGenerate HTML report?", default=False).ask()
            if generate_report:
                # report_path = self.report_gen.generate_email_report(email, results)
                # print(colored(f"\n📄 Report saved: {report_path}", "magenta"))
                print(colored("  Report generation for email not yet implemented", "yellow"))
        except Exception as e:
            logger.error(f"Error during email analysis: {e}")
            print(colored(f"\n❌ An error occurred: {e}", "red"))
        
        self.wait_for_continue()
    
    def image_metadata_analysis(self):
        """Image metadata extractor module interface"""
        self.print_module_header("🖼️ IMAGE METADATA ANALYZER")
        
        image_path = questionary.path(
            "Enter path to image file:"
        ).ask()
        
        if not image_path:
            return
        
        # Check if file exists
        if not Path(image_path).exists():
            print(colored("❌ File not found!", "red"))
            self.wait_for_continue()
            return
        
        print(colored(f"\n📸 Extracting metadata from '{image_path}'...\n", "cyan"))
        
        try:
            # Extract metadata
            metadata = self.image_metadata.extract_metadata(image_path)
            
            # Basic info
            print(colored("📋 BASIC INFORMATION:", "cyan", attrs=["bold"]))
            basic_info = [
                ["File", metadata['filename']],
                ["Format", metadata['format'] or 'N/A'],
                ["Size", f"{metadata['file_size']:,} bytes" if metadata['file_size'] else 'N/A'],
                ["Dimensions", metadata['dimensions'] or 'N/A']
            ]
            print(tabulate(basic_info, tablefmt="grid"))
            
            # Camera info
            if metadata.get('camera_make') or metadata.get('camera_model'):
                print(colored("\n📷 CAMERA INFORMATION:", "cyan", attrs=["bold"]))
                camera_info = []
                if metadata.get('camera_make'):
                    camera_info.append(["Make", metadata['camera_make']])
                if metadata.get('camera_model'):
                    camera_info.append(["Model", metadata['camera_model']])
                if metadata.get('timestamp_taken'):
                    camera_info.append(["Date Taken", metadata['timestamp_taken']])
                print(tabulate(camera_info, tablefmt="grid"))
            
            # GPS data
            if metadata['latitude'] and metadata['longitude']:
                print(colored("\n📍 GPS LOCATION:", "cyan", attrs=["bold"]))
                gps_info = [
                    ["Latitude", f"{metadata['latitude']:.6f}"],
                    ["Longitude", f"{metadata['longitude']:.6f}"]
                ]
                if metadata['altitude']:
                    gps_info.append(["Altitude", f"{metadata['altitude']} m"])
                print(tabulate(gps_info, tablefmt="grid"))
                
                # Offer to open in Google Maps
                open_maps = questionary.confirm("Open location in Google Maps?", default=False).ask()
                if open_maps:
                    maps_url = f"https://www.google.com/maps?q={metadata['latitude']},{metadata['longitude']}"
                    print(colored(f"\n🗺️ Map URL: {maps_url}", "magenta"))
            else:
                print(colored("\n📍 No GPS data found in image", "white"))
            
            if metadata['all_exif']:
                show_all = questionary.confirm("\nShow all EXIF data?", default=False).ask()
                if show_all:
                    print(colored("\n📋 ALL EXIF DATA:", "cyan", attrs=["bold"]))
                    # Show ALL EXIF data without any limit
                    exif_data = [[k, v] for k, v in metadata['all_exif'].items()]
                    print(tabulate(exif_data, headers=["Tag", "Value"], tablefmt="grid"))
                    print(colored(f"\n✅ Total: {len(metadata['all_exif'])} EXIF tags displayed", "magenta"))
        except Exception as e:
            logger.error(f"Error extracting metadata: {e}")
            print(colored(f"\n❌ An error occurred: {e}", "red"))
        
        self.wait_for_continue()
    
    def change_monitoring(self):
        """Change monitor module interface"""
        self.print_module_header("🔔 CHANGE MONITOR")
        
        action = questionary.select(
            "What would you like to do?",
            choices=[
                "Add new URL to monitor",
                "Check all monitored URLs now",
                "List monitored URLs",
                "Remove URL from monitoring",
                "Start continuous monitoring",
                "Back to main menu"
            ]
        ).ask()
        
        try:
            if action == "Add new URL to monitor":
                url = questionary.text(
                    "Enter URL to monitor:",
                    validate=lambda text: text.startswith('http') or "URL must start with http:// or https://"
                ).ask()
                
                if url:
                    print(colored(f"\n📡 Fetching initial content from {url}...", "cyan"))
                    success = self.change_monitor.add_url(url)
                    if success:
                        print(colored("✅ URL added to monitoring successfully!", "magenta"))
                    else:
                        print(colored("❌ Failed to add URL", "red"))
            
            elif action == "Check all monitored URLs now":
                print(colored("\n🔍 Checking all monitored URLs for changes...\n", "cyan"))
                changes = self.change_monitor.check_all()
                
                if changes:
                    print(colored(f"\n⚠️ CHANGES DETECTED in {len(changes)} URL(s):", "red", attrs=["bold"]))
                    for change in changes:
                        print(colored(f"  • {change['url']}", "yellow"))
                else:
                    print(colored("\n✅ No changes detected", "blue"))
            
            elif action == "List monitored URLs":
                urls = self.change_monitor.list_monitored_urls()
                if urls:
                    print(colored(f"\n📋 MONITORED URLs ({len(urls)}):", "cyan", attrs=["bold"]))
                    table_data = [
                        [i+1, url[1], url[2][:16] + "...", url[3], "Yes" if url[4] else "No"]
                        for i, url in enumerate(urls)
                    ]
                    print(tabulate(
                        table_data,
                        headers=["#", "URL", "Hash", "Last Check", "Changed"],
                        tablefmt="grid"
                    ))
                else:
                    print(colored("\n📋 No URLs being monitored", "white"))
            
            elif action == "Remove URL from monitoring":
                urls = self.change_monitor.list_monitored_urls()
                if not urls:
                    print(colored("\n❌ No URLs to remove", "white"))
                else:
                    choices = [url[1] for url in urls] + ["Cancel"]
                    url_to_remove = questionary.select(
                        "Select URL to remove:",
                        choices=choices
                    ).ask()
                    
                    if url_to_remove and url_to_remove != "Cancel":
                        success = self.change_monitor.remove_url(url_to_remove)
                        if success:
                            print(colored(f"✅ Removed: {url_to_remove}", "magenta"))
            
            elif action == "Start continuous monitoring":
                interval = questionary.text(
                    "Enter check interval in seconds (default: 300):",
                    default="300"
                ).ask()
                
                try:
                    interval = int(interval)
                    print(colored(f"\n🔄 Starting continuous monitoring (Ctrl+C to stop)...", "cyan"))
                    self.change_monitor.monitor_continuously(interval)
                except ValueError:
                    print(colored("❌ Invalid interval", "red"))
                except KeyboardInterrupt:
                    print(colored("\n\n✋ Monitoring stopped", "white"))
        except Exception as e:
            logger.error(f"Error in change monitoring: {e}")
            print(colored(f"\n❌ An error occurred: {e}", "red"))
        
        if action != "Back to main menu":
            self.wait_for_continue()
    
    def phone_osint_analysis(self):
        """Phone OSINT module interface"""
        self.print_module_header("📱 PHONE OSINT")
        
        phone_number = questionary.text(
            "Enter phone number (with country code, e.g., +62812345678):",
            validate=lambda text: len(text) > 0 or "Phone number cannot be empty"
        ).ask()
        
        if not phone_number:
            return
        
        print(colored(f"\n🔍 Analyzing phone number: {phone_number}...\n", "cyan"))
        
        try:
            # Get phone info
            results = self.phone_osint.get_phone_info(phone_number)
            
            if results.get('valid'):
                # Basic info
                print(colored("📋 BASIC INFORMATION:", "cyan", attrs=["bold"]))
                basic_info = [
                    ["Number", results.get('number', 'N/A')],
                    ["Valid", "✅ Yes" if results.get('valid') else "❌ No"]
                ]
                
                info = results.get('info', {})
                if isinstance(info.get('country_code'), dict):
                    basic_info.append(["Country Code", info['country_code'].get('code', 'N/A')])
                    basic_info.append(["Country", info['country_code'].get('country', 'N/A')])
                elif info.get('country_code'):
                    basic_info.append(["Country Code", info.get('country_code', 'N/A')])
                
                basic_info.append(["Number Type", info.get('number_type', 'N/A')])
                basic_info.append(["Carrier", info.get('carrier', 'N/A')])
                basic_info.append(["Location", info.get('location', 'N/A')])
                
                print(tabulate(basic_info, tablefmt="grid"))
                
                # Formatted versions
                if info.get('formatted'):
                    print(colored("\n📞 FORMATTED VERSIONS:", "cyan", attrs=["bold"]))
                    if isinstance(info['formatted'], dict):
                        formatted_info = []
                        for format_type, formatted in info['formatted'].items():
                            formatted_info.append([format_type.replace('_', ' ').title(), formatted])
                        print(tabulate(formatted_info, tablefmt="grid"))
                    else:
                        print(colored(f"  {info['formatted']}", "white"))
                
                # Timezones
                if info.get('timezones'):
                    print(colored("\n🕐 TIMEZONES:", "cyan", attrs=["bold"]))
                    for tz in info['timezones']:
                        print(colored(f"  • {tz}", "white"))
                
                # Social media links
                if results.get('social_media'):
                    print(colored("\n📱 SOCIAL MEDIA LINKS:", "cyan", attrs=["bold"]))
                    social = results['social_media']
                    
                    for platform, data in social.items():
                        if platform != 'note' and isinstance(data, dict):
                            print(colored(f"\n  {platform.upper()}:", "magenta"))
                            if data.get('url'):
                                print(colored(f"    URL: {data['url']}", "white"))
                            if data.get('check_url'):
                                print(colored(f"    Check: {data['check_url']}", "white"))
                            if data.get('note'):
                                print(colored(f"    Note: {data['note']}", "yellow"))
                
                # Advanced info
                if results.get('advanced_info'):
                    print(colored("\n🔍 ADVANCED INFO:", "cyan", attrs=["bold"]))
                    adv = results['advanced_info']
                    
                    if adv.get('spam_check'):
                        spam = adv['spam_check']
                        spam_info = [
                            ["Spam Check", "✅ Checked" if spam.get('checked') else "❌ Not checked"],
                            ["Is Spam", "🚨 Yes" if spam.get('is_spam') else "✅ No"],
                            ["Reports", str(spam.get('reports', 0))]
                        ]
                        print(tabulate(spam_info, tablefmt="grid"))
                
            else:
                print(colored(f"❌ {results.get('error', 'Invalid phone number')}", "red"))
                
        except Exception as e:
            logger.error(f"Error in phone OSINT: {e}")
            print(colored(f"\n❌ An error occurred: {e}", "red"))
        
        self.wait_for_continue()
    
    def ip_geolocation_analysis(self):
        """IP Geolocation module interface"""
        self.print_module_header("🌐 IP GEOLOCATION")
        
        action = questionary.select(
            "What would you like to do?",
            choices=[
                "Lookup specific IP address",
                "Get my public IP",
                "Bulk IP lookup",
                "Back to main menu"
            ]
        ).ask()
        
        try:
            if action == "Lookup specific IP address":
                ip_address = questionary.text(
                    "Enter IP address:",
                    validate=lambda text: len(text) > 0 or "IP address cannot be empty"
                ).ask()
                
                if ip_address:
                    print(colored(f"\n🔍 Looking up IP: {ip_address}...\n", "cyan"))
                    results = self.ip_geo.get_ip_info(ip_address)
                    
                    if results.get('valid'):
                        info = results.get('info', {})
                        
                        print(colored("📋 IP INFORMATION:", "cyan", attrs=["bold"]))
                        ip_info = [
                            ["IP Address", results.get('ip', 'N/A')],
                            ["Country", info.get('country', 'N/A')],
                            ["Region", info.get('region', 'N/A')],
                            ["City", info.get('city', 'N/A')],
                            ["ZIP Code", info.get('zip', 'N/A')],
                            ["Timezone", info.get('timezone', 'N/A')],
                            ["ISP", info.get('isp', 'N/A')],
                            ["Organization", info.get('organization', 'N/A')],
                        ]
                        print(tabulate(ip_info, tablefmt="grid"))
                        
                        # Location
                        if info.get('latitude') and info.get('longitude'):
                            print(colored("\n📍 LOCATION:", "cyan", attrs=["bold"]))
                            location_info = [
                                ["Latitude", f"{info['latitude']:.6f}"],
                                ["Longitude", f"{info['longitude']:.6f}"]
                            ]
                            print(tabulate(location_info, tablefmt="grid"))
                            
                            if info.get('maps_url'):
                                print(colored(f"\n🗺️ Google Maps: {info['maps_url']}", "magenta"))
                        
                        # Flags
                        flags = []
                        if info.get('mobile'):
                            flags.append("📱 Mobile")
                        if info.get('proxy'):
                            flags.append("🔒 Proxy")
                        if info.get('hosting'):
                            flags.append("🖥️ Hosting")
                        
                        if flags:
                            print(colored("\n⚠️ FLAGS:", "yellow", attrs=["bold"]))
                            for flag in flags:
                                print(colored(f"  {flag}", "yellow"))
                    else:
                        print(colored(f"❌ {results.get('error', 'Invalid IP address')}", "red"))
            
            elif action == "Get my public IP":
                print(colored("\n🔍 Getting your public IP address...\n", "cyan"))
                my_ip = self.ip_geo.get_my_ip()
                
                if my_ip:
                    print(colored(f"📍 Your IP: {my_ip}", "magenta", attrs=["bold"]))
                    
                    lookup = questionary.confirm("\nLookup this IP?", default=True).ask()
                    if lookup:
                        print(colored(f"\n🔍 Looking up {my_ip}...\n", "cyan"))
                        results = self.ip_geo.get_ip_info(my_ip)
                        
                        if results.get('valid'):
                            info = results.get('info', {})
                            print(colored("📋 YOUR IP INFORMATION:", "cyan", attrs=["bold"]))
                            ip_info = [
                                ["Country", info.get('country', 'N/A')],
                                ["City", info.get('city', 'N/A')],
                                ["ISP", info.get('isp', 'N/A')],
                                ["Timezone", info.get('timezone', 'N/A')],
                            ]
                            print(tabulate(ip_info, tablefmt="grid"))
                else:
                    print(colored("❌ Could not retrieve your IP address", "red"))
            
            elif action == "Bulk IP lookup":
                print(colored("\nEnter IP addresses (one per line, empty line to finish):", "cyan"))
                ip_list = []
                while True:
                    ip = input(colored("IP: ", "white")).strip()
                    if not ip:
                        break
                    ip_list.append(ip)
                
                if ip_list:
                    print(colored(f"\n🔍 Looking up {len(ip_list)} IP addresses...\n", "cyan"))
                    results = self.ip_geo.bulk_ip_lookup(ip_list)
                    
                    # Display results in table
                    table_data = []
                    for result in results:
                        if result.get('valid'):
                            info = result.get('info', {})
                            table_data.append([
                                result.get('ip'),
                                info.get('country', 'N/A'),
                                info.get('city', 'N/A'),
                                info.get('isp', 'N/A')
                            ])
                        else:
                            table_data.append([
                                result.get('ip'),
                                'Invalid',
                                '-',
                                '-'
                            ])
                    
                    print(tabulate(
                        table_data,
                        headers=["IP Address", "Country", "City", "ISP"],
                        tablefmt="grid"
                    ))
                
        except Exception as e:
            logger.error(f"Error in IP geolocation: {e}")
            print(colored(f"\n❌ An error occurred: {e}", "red"))
        
        if action != "Back to main menu":
            self.wait_for_continue()
    
    def blockchain_tracking(self):
        """Blockchain tracker module interface"""
        self.print_module_header("₿ BLOCKCHAIN TRACKER")
        
        action = questionary.select(
            "What would you like to do?",
            choices=[
                "Track cryptocurrency address",
                "Detect address type",
                "Back to main menu"
            ]
        ).ask()
        
        try:
            if action == "Track cryptocurrency address":
                address = questionary.text(
                    "Enter cryptocurrency address:",
                    validate=lambda text: len(text) > 0 or "Address cannot be empty"
                ).ask()
                
                if address:
                    print(colored(f"\n🔍 Analyzing address: {address}...\n", "cyan"))
                    
                    # Detect type first
                    crypto_type = self.blockchain.detect_address_type(address)
                    print(colored(f"🔎 Detected type: {crypto_type.upper()}", "magenta"))
                    
                    # Track the address
                    results = self.blockchain.track_address(address)
                    
                    if results.get('success'):
                        info = results.get('info', {})
                        
                        print(colored("\n💰 ADDRESS INFORMATION:", "cyan", attrs=["bold"]))
                        
                        if crypto_type == 'bitcoin':
                            address_info = [
                                ["Address", address],
                                ["Type", "Bitcoin (BTC)"],
                                ["Total Received", f"{info.get('total_received', 0):.8f} BTC"],
                                ["Total Sent", f"{info.get('total_sent', 0):.8f} BTC"],
                                ["Final Balance", f"{info.get('final_balance', 0):.8f} BTC"],
                                ["Total Transactions", str(info.get('total_transactions', 0))]
                            ]
                        elif crypto_type == 'ethereum':
                            address_info = [
                                ["Address", address],
                                ["Type", "Ethereum (ETH)"],
                                ["Balance", f"{info.get('balance', 0):.8f} ETH"],
                                ["Total Transactions", str(info.get('total_transactions', 0))]
                            ]
                        else:
                            address_info = [
                                ["Address", address],
                                ["Type", crypto_type.upper()],
                                ["Message", info.get('message', 'Direct tracking not available')]
                            ]
                        
                        print(tabulate(address_info, tablefmt="grid"))
                        
                        # Explorer links
                        if results.get('explorer_links'):
                            print(colored("\n🔗 BLOCKCHAIN EXPLORERS:", "cyan", attrs=["bold"]))
                            for name, url in results['explorer_links'].items():
                                print(colored(f"  {name.replace('_', ' ').title()}: {url}", "white"))
                        
                        # Recent transactions (if available)
                        if results.get('recent_transactions'):
                            print(colored("\n📜 RECENT TRANSACTIONS:", "cyan", attrs=["bold"]))
                            tx_count = len(results['recent_transactions'])
                            print(colored(f"  Showing {tx_count} most recent transactions:", "white"))
                            
                            for i, tx in enumerate(results['recent_transactions'][:5], 1):
                                if isinstance(tx, dict):
                                    print(colored(f"\n  Transaction {i}:", "magenta"))
                                    print(colored(f"    Hash: {tx.get('hash', 'N/A')}", "white"))
                                    if tx.get('time'):
                                        from datetime import datetime
                                        timestamp = datetime.fromtimestamp(tx['time'])
                                        print(colored(f"    Time: {timestamp}", "white"))
                    else:
                        print(colored(f"❌ {results.get('error', 'Could not track address')}", "red"))
            
            elif action == "Detect address type":
                address = questionary.text(
                    "Enter cryptocurrency address:",
                    validate=lambda text: len(text) > 0 or "Address cannot be empty"
                ).ask()
                
                if address:
                    crypto_type = self.blockchain.detect_address_type(address)
                    print(colored(f"\n🔎 Detected cryptocurrency type: {crypto_type.upper()}", "magenta", attrs=["bold"]))
                    
                    if crypto_type != 'unknown':
                        # Get explorer links
                        links = self.blockchain._get_explorer_links(address, crypto_type)
                        if links:
                            print(colored("\n🔗 Blockchain Explorers:", "cyan"))
                            for name, url in links.items():
                                print(colored(f"  {name.replace('_', ' ').title()}: {url}", "white"))
                    else:
                        print(colored("⚠️ Unable to detect cryptocurrency type", "yellow"))
        
        except Exception as e:
            logger.error(f"Error in blockchain tracking: {e}")
            print(colored(f"\n❌ An error occurred: {e}", "red"))
        
        if action != "Back to main menu":
            self.wait_for_continue()
    
    def social_media_stalking(self):
        """Social media stalker module interface"""
        self.print_module_header("👁️ SOCIAL MEDIA STALKER")
        
        action = questionary.select(
            "What would you like to do?",
            choices=[
                "Stalk TikTok profile",
                "Stalk Instagram profile",
                "Stalk across multiple platforms",
                "Compare TikTok and Instagram profiles",
                "Back to main menu"
            ]
        ).ask()
        
        try:
            if action == "Stalk TikTok profile":
                username = questionary.text(
                    "Enter TikTok username (without @):",
                    validate=lambda text: len(text) > 0 or "Username cannot be empty"
                ).ask()
                
                if username:
                    print(colored(f"\n🔍 Stalking TikTok profile: @{username}...\n", "cyan"))
                    results = self.social_stalker.stalk_tiktok(username)
                    
                    if results.get('success'):
                        summary = self.social_stalker.get_profile_summary(results)
                        print(colored(summary, "white"))
                        
                        # Generate and display intelligence report
                        print(colored("\n📊 INTELLIGENCE ANALYSIS", "magenta", attrs=["bold"]))
                        intel = self.social_stalker.generate_intelligence_report(results)
                        
                        if 'analysis' in intel:
                            # Activity analysis
                            activity = intel['analysis']['activity']
                            print(colored(f"\n🎯 Activity Level: {activity['activity_level'].upper()}", "cyan"))
                            print(f"   Score: {activity['frequency_score']:.0%}")
                            for insight in activity.get('insights', []):
                                print(f"   • {insight}")
                            
                            # Keywords
                            keywords = intel['analysis']['keywords']
                            if keywords:
                                print(colored(f"\n🔑 Bio Keywords: {', '.join(keywords)}", "cyan"))
                            
                            # Risk assessment
                            risk = intel['analysis']['risk']
                            risk_color = "red" if risk['risk_level'] == 'high' else "yellow" if risk['risk_level'] == 'medium' else "green"
                            print(colored(f"\n⚠️ Risk Level: {risk['risk_level'].upper()}", risk_color, attrs=["bold"]))
                            if risk['flags']:
                                print("   Flags:")
                                for flag in risk['flags']:
                                    print(f"   • {flag}")
                    else:
                        print(colored(f"❌ {results.get('error', 'Profile not found')}", "red"))
            
            elif action == "Stalk Instagram profile":
                username = questionary.text(
                    "Enter Instagram username (without @):",
                    validate=lambda text: len(text) > 0 or "Username cannot be empty"
                ).ask()
                
                if username:
                    print(colored(f"\n🔍 Stalking Instagram profile: @{username}...\n", "cyan"))
                    results = self.social_stalker.stalk_instagram(username)
                    
                    if results.get('success'):
                        summary = self.social_stalker.get_profile_summary(results)
                        print(colored(summary, "white"))
                        
                        # Generate and display intelligence report
                        print(colored("\n📊 INTELLIGENCE ANALYSIS", "magenta", attrs=["bold"]))
                        intel = self.social_stalker.generate_intelligence_report(results)
                        
                        if 'analysis' in intel:
                            activity = intel['analysis']['activity']
                            print(colored(f"\n🎯 Activity Level: {activity['activity_level'].upper()}", "cyan"))
                            print(f"   Score: {activity['frequency_score']:.0%}")
                            
                            keywords = intel['analysis']['keywords']
                            if keywords:
                                print(colored(f"\n🔑 Bio Keywords: {', '.join(keywords)}", "cyan"))
                            
                            risk = intel['analysis']['risk']
                            risk_color = "red" if risk['risk_level'] == 'high' else "yellow" if risk['risk_level'] == 'medium' else "green"
                            print(colored(f"\n⚠️ Risk Level: {risk['risk_level'].upper()}", risk_color, attrs=["bold"]))
                            if risk['flags']:
                                print("   Flags:")
                                for flag in risk['flags']:
                                    print(f"   • {flag}")
                    else:
                        print(colored(f"❌ {results.get('error', 'Profile not found')}", "red"))
            
            elif action == "Stalk across multiple platforms":
                username = questionary.text(
                    "Enter username to search (without @):",
                    validate=lambda text: len(text) > 0 or "Username cannot be empty"
                ).ask()
                
                if username:
                    print(colored(f"\n🔍 Searching for @{username} across platforms...\n", "cyan"))
                    results = self.social_stalker.stalk_multi_platform(username)
                    
                    print(colored(f"\n✅ Found on {results['found_on']} out of {results['total_checked']} platforms:\n", "magenta", attrs=["bold"]))
                    
                    # Display each platform result
                    for platform, data in results['platforms'].items():
                        if data.get('success'):
                            summary = self.social_stalker.get_profile_summary(data)
                            print(summary)
                        else:
                            print(colored(f"❌ {platform.upper()}: {data.get('error', 'Not found')}", "red"))
                            print()
            
            elif action == "Compare TikTok and Instagram profiles":
                tiktok_username = questionary.text(
                    "Enter TikTok username (without @):",
                    validate=lambda text: len(text) > 0 or "Username cannot be empty"
                ).ask()
                
                if tiktok_username:
                    instagram_username = questionary.text(
                        "Enter Instagram username (without @):",
                        validate=lambda text: len(text) > 0 or "Username cannot be empty"
                    ).ask()
                    
                    if instagram_username:
                        print(colored(f"\n🔍 Comparing profiles...\n", "cyan"))
                        results = self.social_stalker.compare_profiles(tiktok_username, instagram_username)
                        
                        # Display TikTok profile
                        if results['tiktok'].get('success'):
                            summary = self.social_stalker.get_profile_summary(results['tiktok'])
                            print(summary)
                        
                        # Display Instagram profile
                        if results['instagram'].get('success'):
                            summary = self.social_stalker.get_profile_summary(results['instagram'])
                            print(summary)
                        
                        # Display comparison
                        if results.get('comparison'):
                            print(colored("\n📊 COMPARISON:", "cyan", attrs=["bold"]))
                            comparison = results['comparison']
                            
                            comp_data = [
                                ["Metric", "TikTok", "Instagram", "Difference"],
                                ["Followers", 
                                 f"{comparison['total_followers']['tiktok']:,}",
                                 f"{comparison['total_followers']['instagram']:,}",
                                 f"{comparison['total_followers']['difference']:,}"],
                                ["Posts/Videos",
                                 f"{comparison['total_posts']['tiktok']:,}",
                                 f"{comparison['total_posts']['instagram']:,}",
                                 f"{comparison['total_posts']['difference']:,}"],
                                ["Verified",
                                 "✅" if comparison['verified']['tiktok'] else "❌",
                                 "✅" if comparison['verified']['instagram'] else "❌",
                                 "Both ✅" if comparison['verified']['both_verified'] else "Not both"]
                            ]
                            
                            print(tabulate(comp_data, headers="firstrow", tablefmt="grid"))
        
        except Exception as e:
            logger.error(f"Error in social media stalking: {e}")
            print(colored(f"\n❌ An error occurred: {e}", "red"))
        
        if action != "Back to main menu":
            self.wait_for_continue()
    
    def wait_for_continue(self):
        """Wait for user to press enter and clear screen"""
        input(colored("\nPress Enter to continue...", "white"))
        self.clear_screen()
    
    def main_menu(self):
        """Display main menu and handle navigation"""
        while True:
            self.clear_screen()  # Clear screen before showing menu
            self.print_banner()
            
            choice = questionary.select(
                "Select a module:",
                choices=[
                    "🔍 Username Hunter - Search username across platforms",
                    "📧 Email OSINT - Analyze email addresses",
                    "🖼️ Image Metadata - Extract EXIF data from images",
                    "🔔 Change Monitor - Monitor websites for changes",
                    "📱 Phone OSINT - Analyze phone numbers",
                    "🌐 IP Geolocation - Track IP addresses",
                    "₿ Blockchain Tracker - Track crypto addresses",
                    "👁️ Social Media Stalker - Stalk TikTok & Instagram(segera hadir)",
                    "❌ Exit"
                ]
            ).ask()
            
            if not choice or choice == "❌ Exit":
                print(colored("\n👋 Thanks for using OWL OSINT!", "cyan"))
                break
            
            try:
                if "Username Hunter" in choice:
                    self.username_search()
                elif "Email OSINT" in choice:
                    self.email_search()
                elif "Image Metadata" in choice:
                    self.image_metadata_analysis()
                elif "Change Monitor" in choice:
                    self.change_monitoring()
                elif "Phone OSINT" in choice:
                    self.phone_osint_analysis()
                elif "IP Geolocation" in choice:
                    self.ip_geolocation_analysis()
                elif "Blockchain Tracker" in choice:
                    self.blockchain_tracking()
                elif "Social Media Stalker" in choice:
                    self.social_media_stalking()
            except KeyboardInterrupt:
                print(colored("\n\n⚠️ Operation cancelled by user", "white"))
                self.wait_for_continue()
            except Exception as e:
                logger.error(f"Error: {e}")
                print(colored(f"\n❌ An error occurred: {e}", "red"))
                self.wait_for_continue()


def main():
    """Main entry point"""
    try:
        suite = OSINTSuite()
        suite.main_menu()
    except KeyboardInterrupt:
        print(colored("\n\n👋 Goodbye!", "cyan"))
        sys.exit(0)
    except Exception as e:
        logger.error(f"Fatal error: {e}")
        print(colored(f"\n❌ Fatal error: {e}", "red"))
        sys.exit(1)


if __name__ == "__main__":
    main()
