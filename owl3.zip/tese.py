#!/usr/bin/env python3
"""
Test SearchAPI dengan image URL
"""

from modules.osint_image_tools import OSINTImageTools

# Test dengan image yang sudah online
test_url = "https://upload.wikimedia.org/wikipedia/commons/thumb/8/85/Tour_Eiffel_Wikimedia_Commons_%28cropped%29.jpg/400px-Tour_Eiffel_Wikimedia_Commons_%28cropped%29.jpg"

print("Testing SearchAPI.io...")
print(f"Image URL: {test_url}\n")

osint = OSINTImageTools()

if osint.searchapi_key:
    print(f"✓ API Key loaded: {osint.searchapi_key[:15]}...\n")
    
    print("Calling SearchAPI (this may take 5-10 seconds)...")
    result = osint.search_location_by_url(test_url)
    
    print("\n" + "="*60)
    print("RESULT:")
    print("="*60)
    
    if result.get('success'):
        print(f"✓ Success!")
        print(f"Method: {result.get('method')}")
        print(f"Location: {result.get('location_name')}")
        print(f"Confidence: {result.get('confidence', 0):.0%}")
        
        if result.get('landmarks'):
            print(f"\nLandmarks found: {len(result['landmarks'])}")
            for lm in result['landmarks']:
                print(f"  - {lm['name']}")
        
        if result.get('visual_matches'):
            print(f"\nVisual matches: {len(result['visual_matches'])}")
            for vm in result['visual_matches'][:3]:
                print(f"  - {vm['title']}")
    else:
        print(f"✗ Failed")
        print(f"Error: {result.get('error')}")
else:
    print("✗ No API key found")
    print("Add SEARCHAPI_KEY to config.py")
    print("Register at: https://www.searchapi.io/")
