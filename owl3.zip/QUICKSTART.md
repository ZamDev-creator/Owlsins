# 🚀 Quick Start Guide - OWL OSINT Suite Enhanced

## Installation (3 Steps)

### Step 1: Extract Files
```bash
unzip osint_core_only.zip
cd osint_tool
```

### Step 2: Run Installation Script
```bash
chmod +x install.sh
./install.sh
```

### Step 3: Run the Tool
```bash
python3 main.py
```

## Quick Feature Test

### Test Phone OSINT
```bash
python3 main.py
# Select: 📱 Phone OSINT
# Enter: +6281234567890
# Choose: HTML Report
```

### Test IP Geolocation
```bash
python3 main.py
# Select: 🌐 IP Geolocation
# Choose: Get my public IP
```

### Test Social Media Stalking
```bash
python3 main.py
# Select: 👁️ Social Media Stalker
# Choose: Stalk TikTok profile
# Enter: tiktok (TikTok's official account)
```

### Test Blockchain Tracking
```bash
python3 main.py
# Select: ₿ Blockchain Tracker
# Enter: 1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa
# (Satoshi's Genesis address)
```

## Manual Installation (if script fails)

### Install Dependencies
```bash
pip3 install requests beautifulsoup4 pillow --break-system-packages
pip3 install termcolor questionary pyfiglet tabulate tqdm --break-system-packages
pip3 install aiohttp nest-asyncio --break-system-packages
pip3 install phonenumbers weasyprint reportlab --break-system-packages
```

### Create Directories
```bash
mkdir -p output/reports output/screenshots data
```

### Run
```bash
python3 main.py
```

## Features Quick Reference

| Feature | Menu Option | Description |
|---------|-------------|-------------|
| **Username Search** | 🔍 Username Hunter | Search 350+ platforms |
| **Email Analysis** | 📧 Email OSINT | Breach check, validation |
| **Image EXIF** | 🖼️ Image Metadata | GPS, camera info |
| **Website Monitor** | 🔔 Change Monitor | Track website changes |
| **Phone Lookup** | 📱 Phone OSINT | ✨ **NEW** - Carrier, location, spam check |
| **IP Tracking** | 🌐 IP Geolocation | ✨ **NEW** - VPN detection, maps |
| **Crypto Tracking** | ₿ Blockchain Tracker | ✨ **NEW** - Multi-crypto support |
| **Social Stalking** | 👁️ Social Media Stalker | ✨ **NEW** - TikTok & Instagram API |

## Report Formats

All enhanced modules support:
- **HTML** - Beautiful, interactive reports
- **PDF** - Professional, printable documents

Reports are saved in: `output/reports/`

## Troubleshooting

### "Module not found" Error
```bash
pip3 install <module-name> --break-system-packages
```

### PDF Generation Fails
```bash
# Install PDF dependencies
sudo apt-get install libpango-1.0-0 libpangoft2-1.0-0
pip3 install weasyprint --break-system-packages
```

### Social Media API Fails
- Check internet connection
- Verify username is correct (no @ symbol)
- Try again later (API rate limiting)

### Phone Number Parsing Issues
```bash
pip3 install phonenumbers --break-system-packages
```

## Getting Help

1. Read `README_ENHANCED.md` for full documentation
2. Run test script: `python3 test_enhanced_features.py`
3. Check module documentation in `modules/` directory

## Next Steps

1. ✅ Test each module with sample data
2. ✅ Generate sample reports
3. ✅ Customize settings in `config.py`
4. ✅ Read full documentation
5. ✅ Start your OSINT investigation!

---

**Ready to Start?**
```bash
python3 main.py
```

🦉 **OWL OSINT** - *Your Enhanced Intelligence Toolkit*
