#!/usr/bin/env python3
"""
Test script untuk SearchAPI integration
Test reverse image search dan location recognition dengan API
"""

import sys
from pathlib import Path

def test_config():
    """Test configuration dan API key"""
    print("=" * 70)
    print("TEST 1: Configuration & API Key")
    print("=" * 70)
    
    try:
        from config import SEARCHAPI_KEY
        
        if SEARCHAPI_KEY:
            masked_key = SEARCHAPI_KEY[:8] + "..." + SEARCHAPI_KEY[-4:]
            print(f"✓ SearchAPI key found: {masked_key}")
            return True
        else:
            print("✗ No SearchAPI key in config.py")
            print("\nAdd to config.py:")
            print('SEARCHAPI_KEY = "your_api_key_here"')
            print("\nGet free API key at: https://www.searchapi.io/")
            return False
    except ImportError:
        print("✗ config.py not found")
        return False
    except Exception as e:
        print(f"✗ Error: {e}")
        return False

def test_image_upload():
    """Test image upload functionality"""
    print("\n" + "=" * 70)
    print("TEST 2: Image Upload (0x0.st)")
    print("=" * 70)
    
    test_images = [
        "IMG20260129101638.jpg",
        "test_image.jpg",
        "DSCN0010.jpg"
    ]
    
    test_image = None
    for img in test_images:
        if Path(img).exists():
            test_image = img
            break
    
    if not test_image:
        print(f"✗ No test image found")
        print(f"  Looked for: {', '.join(test_images)}")
        return False
    
    print(f"Using test image: {test_image}")
    
    try:
        import requests
        
        with open(test_image, 'rb') as f:
            files = {'file': f}
            print("Uploading to 0x0.st...")
            response = requests.post('https://0x0.st', files=files, timeout=30)
            
            if response.status_code == 200:
                url = response.text.strip()
                print(f"✓ Upload successful!")
                print(f"  URL: {url}")
                return url
            else:
                print(f"✗ Upload failed: HTTP {response.status_code}")
                return False
                
    except Exception as e:
        print(f"✗ Upload error: {e}")
        return False

def test_searchapi_connection(image_url):
    """Test SearchAPI connection"""
    print("\n" + "=" * 70)
    print("TEST 3: SearchAPI Connection")
    print("=" * 70)
    
    if not image_url:
        print("⚠ Skipping (no image URL)")
        return False
    
    try:
        from config import SEARCHAPI_KEY
        import requests
        
        if not SEARCHAPI_KEY:
            print("✗ No API key")
            return False
        
        # Test with reverse image search
        base_url = "https://www.searchapi.io/api/v1/search"
        
        params = {
            "engine": "google_reverse_image",
            "image_url": image_url,
            "api_key": SEARCHAPI_KEY
        }
        
        print("Calling SearchAPI (reverse image search)...")
        response = requests.get(base_url, params=params, timeout=30)
        
        print(f"Response status: {response.status_code}")
        
        if response.status_code == 200:
            data = response.json()
            
            # Check if we got results
            visual_matches = data.get('visual_matches', [])
            print(f"✓ API call successful!")
            print(f"  Visual matches found: {len(visual_matches)}")
            
            if visual_matches:
                print(f"\n  Sample results:")
                for i, match in enumerate(visual_matches[:3], 1):
                    print(f"    {i}. {match.get('title', 'N/A')}")
            
            return True
        elif response.status_code == 401:
            print("✗ Authentication failed (invalid API key)")
            return False
        elif response.status_code == 429:
            print("✗ Rate limit exceeded")
            return False
        else:
            print(f"✗ API error: {response.status_code}")
            try:
                error_data = response.json()
                print(f"  Error: {error_data}")
            except:
                print(f"  Response: {response.text[:200]}")
            return False
            
    except Exception as e:
        print(f"✗ Error: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_reverse_search_integration():
    """Test full reverse search integration"""
    print("\n" + "=" * 70)
    print("TEST 4: Reverse Search Integration")
    print("=" * 70)
    
    test_images = [
        "IMG20260129101638.jpg",
        "test_image.jpg",
        "DSCN0010.jpg"
    ]
    
    test_image = None
    for img in test_images:
        if Path(img).exists():
            test_image = img
            break
    
    if not test_image:
        print("✗ No test image")
        return False
    
    try:
        from modules.osint_image_tools import OSINTImageTools
        
        print(f"Testing with: {test_image}")
        tool = OSINTImageTools()
        
        print("Running reverse image search (method='auto')...")
        result = tool.reverse_image_search(test_image, method='auto')
        
        print(f"\nMethod used: {result.get('method')}")
        print(f"Success: {result.get('success')}")
        
        if result.get('error'):
            print(f"Error: {result.get('error')}")
        
        if result.get('similar_images'):
            print(f"\n✓ Found {len(result['similar_images'])} similar images")
            for i, img in enumerate(result['similar_images'][:3], 1):
                print(f"  {i}. {img.get('title', 'N/A')}")
            return True
        elif result.get('method') == 'manual':
            print("⚠ Using manual method (API not available or failed)")
            return True
        else:
            print("⚠ No results found")
            return False
            
    except Exception as e:
        print(f"✗ Error: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_location_recognition():
    """Test location recognition"""
    print("\n" + "=" * 70)
    print("TEST 5: Location Recognition")
    print("=" * 70)
    
    test_images = [
        "IMG20260129101638.jpg",
        "test_image.jpg",
        "DSCN0010.jpg"
    ]
    
    test_image = None
    for img in test_images:
        if Path(img).exists():
            test_image = img
            break
    
    if not test_image:
        print("✗ No test image")
        return False
    
    try:
        from modules.osint_image_tools import OSINTImageTools
        
        print(f"Testing with: {test_image}")
        tool = OSINTImageTools()
        
        print("Running location recognition...")
        result = tool.recognize_location(test_image)
        
        print(f"\nMethod used: {result.get('method')}")
        print(f"Success: {result.get('success')}")
        
        if result.get('error'):
            print(f"Error: {result.get('error')}")
        
        if result.get('location_name'):
            print(f"\n✓ Location identified: {result['location_name']}")
            print(f"  Confidence: {result.get('confidence', 0):.0%}")
            return True
        elif result.get('method') == 'manual':
            print("⚠ Using manual method (API not available or failed)")
            print("  Upload to Google Lens manually for location")
            return True
        else:
            print("⚠ Location not identified")
            return False
            
    except Exception as e:
        print(f"✗ Error: {e}")
        import traceback
        traceback.print_exc()
        return False

def main():
    """Run all tests"""
    print("\n")
    print("╔" + "=" * 68 + "╗")
    print("║" + " " * 18 + "SEARCHAPI INTEGRATION TEST" + " " * 24 + "║")
    print("╚" + "=" * 68 + "╝")
    print()
    
    results = []
    image_url = None
    
    # Test 1: Config
    results.append(("Config & API Key", test_config()))
    
    # Test 2: Upload (get URL for next tests)
    print("\nℹ️  Testing image upload (needed for API tests)...")
    image_url = test_image_upload()
    results.append(("Image Upload", bool(image_url)))
    
    # Test 3: API Connection
    if image_url:
        results.append(("SearchAPI Connection", test_searchapi_connection(image_url)))
    else:
        print("\n⚠️  Skipping API connection test (upload failed)")
        results.append(("SearchAPI Connection", None))
    
    # Test 4: Integration
    results.append(("Reverse Search Integration", test_reverse_search_integration()))
    
    # Test 5: Location
    results.append(("Location Recognition", test_location_recognition()))
    
    # Summary
    print("\n" + "=" * 70)
    print("TEST SUMMARY")
    print("=" * 70)
    
    passed = 0
    failed = 0
    skipped = 0
    
    for test_name, result in results:
        if result is True:
            status = "✓ PASS"
            passed += 1
        elif result is False:
            status = "✗ FAIL"
            failed += 1
        else:
            status = "⊘ SKIP"
            skipped += 1
        
        print(f"{status:10} | {test_name}")
    
    print("=" * 70)
    print(f"Passed: {passed} | Failed: {failed} | Skipped: {skipped}")
    print("=" * 70)
    
    if failed == 0 and passed > 0:
        print("\n✓ SearchAPI integration is working!")
        print("  You can now use automated reverse search and location recognition.")
        return 0
    elif passed > 0:
        print("\n⚠ Some tests passed, some failed.")
        print("  Check the errors above for details.")
        return 1
    else:
        print("\n✗ Tests failed. Check your configuration and network.")
        return 1

if __name__ == "__main__":
    sys.exit(main())
