#!/usr/bin/env python3
"""
Comprehensive Test Suite for Enhanced OSINT Tool
Tests all modules to ensure 100% functionality
"""

import sys
from pathlib import Path

# Add current directory to path
sys.path.insert(0, str(Path(__file__).parent))

def test_phone_osint():
    """Test Phone OSINT module"""
    print("\n" + "="*60)
    print("Testing Phone OSINT Module")
    print("="*60)
    
    try:
        from modules.phone_osint import PhoneOSINT
        
        phone = PhoneOSINT()
        
        # Test 1: Indonesian number
        print("\n[TEST 1] Indonesian Mobile Number")
        result = phone.get_phone_info("+6281234567890")
        if result.get('valid'):
            print("✅ PASSED - Phone validation working")
            print(f"   Country: {result.get('info', {}).get('country_code', {})}")
            print(f"   Carrier: {result.get('info', {}).get('carrier', 'N/A')}")
        else:
            print("❌ FAILED - Phone validation not working")
        
        # Test 2: US number
        print("\n[TEST 2] US Number")
        result = phone.get_phone_info("+1234567890")
        if result.get('valid') or result.get('number'):
            print("✅ PASSED - International number handling working")
        else:
            print("⚠️  WARNING - International number handling needs check")
        
        # Test 3: Social media links
        print("\n[TEST 3] Social Media Integration")
        result = phone.get_phone_info("+6281234567890")
        social = result.get('social_media', {})
        if social and len(social) > 0:
            print("✅ PASSED - Social media links generated")
            print(f"   Platforms: {', '.join([k for k in social.keys() if k != 'note'])}")
        else:
            print("⚠️  WARNING - Social media links not generated")
        
        return True
    except ImportError as e:
        print(f"❌ FAILED - Import error: {e}")
        print("   Install: pip install phonenumbers --break-system-packages")
        return False
    except Exception as e:
        print(f"❌ FAILED - Error: {e}")
        return False


def test_ip_geolocation():
    """Test IP Geolocation module"""
    print("\n" + "="*60)
    print("Testing IP Geolocation Module")
    print("="*60)
    
    try:
        from modules.ip_geolocation import IPGeolocation
        
        ip_geo = IPGeolocation()
        
        # Test 1: Google DNS
        print("\n[TEST 1] IP Lookup - Google DNS (8.8.8.8)")
        result = ip_geo.get_ip_info("8.8.8.8")
        if result.get('valid') and result.get('info'):
            print("✅ PASSED - IP lookup working")
            print(f"   Country: {result['info'].get('country', 'N/A')}")
            print(f"   ISP: {result['info'].get('isp', 'N/A')}")
        else:
            print("❌ FAILED - IP lookup not working")
            print(f"   Error: {result.get('error', 'Unknown')}")
        
        # Test 2: VPN Detection
        print("\n[TEST 2] VPN/Proxy Detection")
        result = ip_geo.check_vpn_proxy("8.8.8.8")
        if 'risk_score' in result:
            print("✅ PASSED - VPN detection working")
            print(f"   Risk Score: {result.get('risk_score', 0)}")
        else:
            print("⚠️  WARNING - VPN detection may have issues")
        
        # Test 3: Get own IP
        print("\n[TEST 3] Get Public IP")
        my_ip = ip_geo.get_my_ip()
        if my_ip:
            print(f"✅ PASSED - Public IP retrieval working")
            print(f"   Your IP: {my_ip}")
        else:
            print("⚠️  WARNING - Public IP retrieval failed (may be network issue)")
        
        return True
    except Exception as e:
        print(f"❌ FAILED - Error: {e}")
        return False


def test_blockchain():
    """Test Blockchain Tracker module"""
    print("\n" + "="*60)
    print("Testing Blockchain Tracker Module")
    print("="*60)
    
    try:
        from modules.blockchain_tracker import BlockchainTracker
        
        blockchain = BlockchainTracker()
        
        # Test 1: Bitcoin address detection
        print("\n[TEST 1] Bitcoin Address Detection")
        btc_address = "1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa"  # Satoshi's address
        detected_type = blockchain.detect_address_type(btc_address)
        if detected_type == 'bitcoin':
            print("✅ PASSED - Bitcoin detection working")
        else:
            print(f"❌ FAILED - Detected as: {detected_type}")
        
        # Test 2: Ethereum address detection
        print("\n[TEST 2] Ethereum Address Detection")
        eth_address = "0x00000000219ab540356cbb839cbe05303d7705fa"
        detected_type = blockchain.detect_address_type(eth_address)
        if detected_type == 'ethereum':
            print("✅ PASSED - Ethereum detection working")
        else:
            print(f"❌ FAILED - Detected as: {detected_type}")
        
        # Test 3: Bitcoin tracking (Satoshi's address)
        print("\n[TEST 3] Bitcoin Address Tracking")
        result = blockchain.track_bitcoin_address(btc_address)
        if result.get('success'):
            print("✅ PASSED - Bitcoin tracking working")
            info = result.get('info', {})
            print(f"   Total Received: {info.get('total_received', 0)} BTC")
            print(f"   Transactions: {info.get('n_tx', 0)}")
        else:
            print("⚠️  WARNING - Bitcoin tracking failed (may be API rate limit)")
            print(f"   Error: {result.get('error', 'Unknown')}")
        
        # Test 4: Explorer links
        print("\n[TEST 4] Explorer Links Generation")
        result = blockchain.track_address(btc_address)
        if result.get('explorer_links'):
            print("✅ PASSED - Explorer links generated")
            print(f"   Links: {len(result['explorer_links'])} explorers")
        else:
            print("⚠️  WARNING - Explorer links not generated")
        
        return True
    except Exception as e:
        print(f"❌ FAILED - Error: {e}")
        return False


def test_social_stalker():
    """Test Social Media Stalker module"""
    print("\n" + "="*60)
    print("Testing Social Media Stalker Module")
    print("="*60)
    
    try:
        from modules.social_stalker import SocialMediaStalker
        
        stalker = SocialMediaStalker()
        
        # Test 1: TikTok stalking (using a known public account)
        print("\n[TEST 1] TikTok Profile Stalking")
        print("   Testing with public account...")
        result = stalker.stalk_tiktok("tiktok")  # TikTok's official account
        if result.get('success'):
            print("✅ PASSED - TikTok stalking working")
            profile = result.get('profile', {})
            print(f"   Username: @{profile.get('username', 'N/A')}")
            print(f"   Followers: {profile.get('followers', 'N/A'):,}")
        else:
            print("⚠️  WARNING - TikTok stalking failed")
            print(f"   Error: {result.get('error', 'Unknown')}")
            print("   Note: API may be rate limited or account not found")
        
        # Test 2: Instagram stalking
        print("\n[TEST 2] Instagram Profile Stalking")
        print("   Testing with public account...")
        result = stalker.stalk_instagram("instagram")  # Instagram's official account
        if result.get('success'):
            print("✅ PASSED - Instagram stalking working")
            profile = result.get('profile', {})
            print(f"   Username: @{profile.get('username', 'N/A')}")
            print(f"   Followers: {profile.get('followers', 'N/A'):,}")
        else:
            print("⚠️  WARNING - Instagram stalking failed")
            print(f"   Error: {result.get('error', 'Unknown')}")
            print("   Note: API may be rate limited or account not found")
        
        # Test 3: Multi-platform
        print("\n[TEST 3] Multi-Platform Stalking")
        result = stalker.stalk_multi_platform("test")
        if 'platforms' in result:
            print("✅ PASSED - Multi-platform stalking structure working")
            print(f"   Platforms checked: {result.get('total_checked', 0)}")
        else:
            print("⚠️  WARNING - Multi-platform stalking structure issue")
        
        return True
    except Exception as e:
        print(f"❌ FAILED - Error: {e}")
        return False


def test_report_generator():
    """Test Enhanced Report Generator"""
    print("\n" + "="*60)
    print("Testing Enhanced Report Generator")
    print("="*60)
    
    try:
        from utils.report_generator_enhanced import EnhancedReportGenerator
        
        gen = EnhancedReportGenerator()
        
        print("\n[TEST 1] Report Generator Initialization")
        print("✅ PASSED - Enhanced report generator loaded")
        
        # Test PDF support
        print("\n[TEST 2] PDF Support Check")
        try:
            from weasyprint import HTML
            print("✅ PASSED - WeasyPrint PDF support available")
        except ImportError:
            try:
                from reportlab.platypus import SimpleDocTemplate
                print("✅ PASSED - ReportLab PDF support available (fallback)")
            except ImportError:
                print("⚠️  WARNING - No PDF support installed")
                print("   Install: pip install weasyprint reportlab --break-system-packages")
        
        # Test HTML report generation
        print("\n[TEST 3] HTML Report Generation")
        test_data = {
            'valid': True,
            'number': '+6281234567890',
            'info': {
                'country_code': {'country': 'Indonesia', 'code': '+62'},
                'carrier': 'Test Carrier',
                'number_type': 'Mobile'
            }
        }
        
        try:
            report_path = gen.generate_phone_report('+6281234567890', test_data, format='html')
            if Path(report_path).exists():
                print("✅ PASSED - HTML report generation working")
                print(f"   Report: {report_path}")
            else:
                print("❌ FAILED - Report file not created")
        except Exception as e:
            print(f"⚠️  WARNING - Report generation issue: {e}")
        
        return True
    except ImportError:
        print("❌ FAILED - Enhanced report generator not found")
        print("   Make sure report_generator_enhanced.py exists")
        return False
    except Exception as e:
        print(f"❌ FAILED - Error: {e}")
        return False


def test_dependencies():
    """Test all required dependencies"""
    print("\n" + "="*60)
    print("Testing Dependencies")
    print("="*60)
    
    dependencies = {
        'requests': 'HTTP requests',
        'beautifulsoup4': 'HTML parsing',
        'pillow': 'Image processing',
        'termcolor': 'Terminal colors',
        'questionary': 'Interactive CLI',
        'tabulate': 'Table formatting',
        'pyfiglet': 'ASCII art',
        'aiohttp': 'Async HTTP',
        'phonenumbers': 'Phone number parsing (OPTIONAL)',
        'weasyprint': 'PDF generation (OPTIONAL)',
        'reportlab': 'PDF generation fallback (OPTIONAL)'
    }
    
    results = {}
    for module, description in dependencies.items():
        try:
            __import__(module)
            print(f"✅ {module:20s} - {description}")
            results[module] = True
        except ImportError:
            optional = 'OPTIONAL' in description
            symbol = "⚠️ " if optional else "❌"
            print(f"{symbol} {module:20s} - {description} - NOT INSTALLED")
            results[module] = False
    
    return all(results.values())


def main():
    """Run all tests"""
    print("\n" + "="*60)
    print("🦉 OWL OSINT SUITE - ENHANCED FEATURES TEST")
    print("="*60)
    print("\nThis script will test all enhanced modules:")
    print("  1. Phone Number OSINT")
    print("  2. IP Geolocation")
    print("  3. Blockchain Tracking")
    print("  4. Social Media Stalking")
    print("  5. Enhanced Report Generator")
    print("  6. Dependencies Check")
    
    results = {}
    
    # Run tests
    results['dependencies'] = test_dependencies()
    results['phone_osint'] = test_phone_osint()
    results['ip_geolocation'] = test_ip_geolocation()
    results['blockchain'] = test_blockchain()
    results['social_stalker'] = test_social_stalker()
    results['report_generator'] = test_report_generator()
    
    # Summary
    print("\n" + "="*60)
    print("TEST SUMMARY")
    print("="*60)
    
    for test_name, result in results.items():
        status = "✅ PASSED" if result else "⚠️  NEEDS ATTENTION"
        print(f"{test_name:25s} : {status}")
    
    passed = sum(1 for r in results.values() if r)
    total = len(results)
    
    print("\n" + "="*60)
    print(f"Overall: {passed}/{total} tests passed")
    
    if passed == total:
        print("🎉 ALL TESTS PASSED - Tool is 100% ready!")
    elif passed >= total * 0.8:
        print("✅ MOSTLY READY - Some optional features may need setup")
    else:
        print("⚠️  NEEDS SETUP - Please install missing dependencies")
    
    print("="*60)
    
    return passed == total


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
